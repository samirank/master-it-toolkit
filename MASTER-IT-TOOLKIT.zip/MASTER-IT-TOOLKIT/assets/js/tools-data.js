window.TOOLKIT_DATA = [
  {
    "id": "windows11",
    "name": "Windows 11 ISO",
    "developer": "Microsoft",
    "description": "Official installation media and Windows Recovery Environment.",
    "categories": [
      "Boot & Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "Windows installation"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 7000,
    "officialWebsite": "https://www.microsoft.com/en-us/software-download/windows11",
    "officialDownload": "https://www.microsoft.com/en-us/software-download/windows11",
    "documentation": "https://www.microsoft.com/en-us/software-download/windows11",
    "localFolder": "00_BOOT/Windows",
    "localExecutable": "",
    "inventoryPatterns": [
      "Win11*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.microsoft.com/en-us/software-download/windows11",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/software-download/windows11",
        "title": "Download Windows 11",
        "checkedAt": "2026-09-09T20:17:57.239917+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.microsoft.com/en-us/software-download/windows11",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/software-download/windows11",
        "title": "Download Windows 11",
        "checkedAt": "2026-09-09T20:17:57.239917+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "hirens",
    "name": "Hiren's BootCD PE",
    "developer": "Hiren's BootCD PE team",
    "description": "Windows PE rescue desktop; check bundled utility licenses separately.",
    "categories": [
      "Boot & Recovery"
    ],
    "tags": [
      "PC won't boot"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 3500,
    "officialWebsite": "https://www.hirensbootcd.org/download/",
    "officialDownload": "https://www.hirensbootcd.org/download/",
    "documentation": "https://www.hirensbootcd.org/download/",
    "localFolder": "00_BOOT/WinPE",
    "localExecutable": "",
    "inventoryPatterns": [
      "HBCD_PE*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.hirensbootcd.org/download/",
        "status": 200,
        "finalUrl": "https://www.hirensbootcd.org/download/",
        "title": "Download | Hiren's BootCD PE",
        "checkedAt": "2026-09-09T20:17:56.892630+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.hirensbootcd.org/download/",
        "status": 200,
        "finalUrl": "https://www.hirensbootcd.org/download/",
        "title": "Download | Hiren's BootCD PE",
        "checkedAt": "2026-09-09T20:17:56.892630+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "systemrescue",
    "name": "SystemRescue",
    "developer": "SystemRescue project",
    "description": "Linux rescue environment with storage, network and filesystem tools.",
    "categories": [
      "Boot & Recovery",
      "Homelab / Linux",
      "Data Recovery"
    ],
    "tags": [
      "Linux rescue"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1200,
    "officialWebsite": "https://www.system-rescue.org/Download/",
    "officialDownload": "https://www.system-rescue.org/Download/",
    "documentation": "https://www.system-rescue.org/Download/",
    "localFolder": "00_BOOT/Linux-Rescue",
    "localExecutable": "",
    "inventoryPatterns": [
      "systemrescue*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.system-rescue.org/Download/",
        "status": 200,
        "finalUrl": "https://www.system-rescue.org/Download/",
        "title": "SystemRescue - Download",
        "checkedAt": "2026-09-09T20:17:58.593999+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.system-rescue.org/Download/",
        "status": 200,
        "finalUrl": "https://www.system-rescue.org/Download/",
        "title": "SystemRescue - Download",
        "checkedAt": "2026-09-09T20:17:58.593999+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ]
  },
  {
    "id": "gparted",
    "name": "GParted Live",
    "developer": "GParted project",
    "description": "Offline partition editor. Resizing and formatting change disk contents.",
    "categories": [
      "Boot & Recovery",
      "Disk & Partition"
    ],
    "tags": [
      "SSD HDD partition"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 600,
    "officialWebsite": "https://gparted.org/download.php",
    "officialDownload": "https://gparted.org/download.php",
    "documentation": "https://gparted.org/download.php",
    "localFolder": "00_BOOT/Linux-Rescue",
    "localExecutable": "",
    "inventoryPatterns": [
      "gparted-live*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://gparted.org/download.php",
        "status": 200,
        "finalUrl": "https://gparted.org/download.php",
        "title": "GParted -- Download",
        "checkedAt": "2026-09-09T20:17:52.491691+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://gparted.org/download.php",
        "status": 200,
        "finalUrl": "https://gparted.org/download.php",
        "title": "GParted -- Download",
        "checkedAt": "2026-09-09T20:17:52.491691+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ]
  },
  {
    "id": "ubuntu",
    "name": "Ubuntu Live",
    "developer": "Canonical",
    "description": "Live Linux desktop for hardware checks and mounting filesystems.",
    "categories": [
      "Homelab / Linux",
      "Boot & Recovery"
    ],
    "tags": [
      "Linux rescue"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 6500,
    "officialWebsite": "https://ubuntu.com/download/desktop",
    "officialDownload": "https://ubuntu.com/download/desktop",
    "documentation": "https://ubuntu.com/download/desktop",
    "localFolder": "00_BOOT/Linux-Rescue",
    "localExecutable": "",
    "inventoryPatterns": [
      "ubuntu*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://ubuntu.com/download/desktop",
        "status": 200,
        "finalUrl": "https://ubuntu.com/download/desktop",
        "title": "Download Ubuntu Desktop | Ubuntu",
        "checkedAt": "2026-09-09T20:17:55.411012+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://ubuntu.com/download/desktop",
        "status": 200,
        "finalUrl": "https://ubuntu.com/download/desktop",
        "title": "Download Ubuntu Desktop | Ubuntu",
        "checkedAt": "2026-09-09T20:17:55.411012+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ]
  },
  {
    "id": "rescuezilla",
    "name": "Rescuezilla",
    "developer": "Rescuezilla project",
    "description": "Graphical image backup and restore for healthy drives.",
    "categories": [
      "Imaging & Cloning",
      "Boot & Recovery",
      "Backup & Sync"
    ],
    "tags": [
      "clone a drive SSD"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://rescuezilla.com/download",
    "officialDownload": "https://rescuezilla.com/download",
    "documentation": "https://rescuezilla.com/download",
    "localFolder": "00_BOOT/Imaging",
    "localExecutable": "",
    "inventoryPatterns": [
      "rescuezilla*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://rescuezilla.com/download",
        "status": 200,
        "finalUrl": "https://rescuezilla.com/download",
        "title": "Download | Rescuezilla (Clonezilla GUI)",
        "checkedAt": "2026-09-09T20:17:53.920790+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://rescuezilla.com/download",
        "status": 200,
        "finalUrl": "https://rescuezilla.com/download",
        "title": "Download | Rescuezilla (Clonezilla GUI)",
        "checkedAt": "2026-09-09T20:17:53.920790+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ]
  },
  {
    "id": "clonezilla",
    "name": "Clonezilla Live",
    "developer": "Clonezilla project",
    "description": "Partition and disk imaging for repeatable deployments; verify source and destination.",
    "categories": [
      "Imaging & Cloning",
      "Boot & Recovery",
      "Backup & Sync"
    ],
    "tags": [
      "clone a drive SSD"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Open source",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 600,
    "officialWebsite": "https://clonezilla.org/downloads.php",
    "officialDownload": "https://clonezilla.org/downloads.php",
    "documentation": "https://clonezilla.org/downloads.php",
    "localFolder": "00_BOOT/Imaging",
    "localExecutable": "",
    "inventoryPatterns": [
      "clonezilla-live*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official project listing reviewed",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://clonezilla.org/downloads.php",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:51.215242+00:00"
      },
      "download": {
        "url": "https://clonezilla.org/downloads.php",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:51.215242+00:00"
      }
    },
    "sourceReviewNotes": "Official project SourceForge release listing and Clonezilla changelog reviewed; main download page blocks automated requests. Latest version left manual.",
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ],
    "automationSupport": {
      "level": "documented",
      "source": "https://clonezilla.org/lecture-materials/019_OSC_Tokyo_Fall_2016/slides/OSC2016-Tokyo-Fall.pdf",
      "notes": "Unattended deployment support; disk identity and overwrite approval remain mandatory."
    },
    "licenseSource": "https://clonezilla.org/lecture-materials/019_OSC_Tokyo_Fall_2016/slides/OSC2016-Tokyo-Fall.pdf"
  },
  {
    "id": "kaspersky",
    "name": "Kaspersky Rescue Disk",
    "developer": "Kaspersky",
    "description": "Bootable antivirus rescue environment. Verify availability and current definitions for your region.",
    "categories": [
      "Malware & Security",
      "Boot & Recovery"
    ],
    "tags": [
      "malware rescue"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 800,
    "officialWebsite": "https://www.kaspersky.com/downloads/free-rescue-disk",
    "officialDownload": "https://www.kaspersky.com/downloads/free-rescue-disk",
    "documentation": "https://www.kaspersky.com/downloads/free-rescue-disk",
    "localFolder": "00_BOOT/Security",
    "localExecutable": "",
    "inventoryPatterns": [
      "krd*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": true,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Official rescue download remains listed. Verify current definitions, availability, regulatory restrictions and organization policy for the region of use; never assume an old ISO is current.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kaspersky.com/downloads/free-rescue-disk",
        "status": 200,
        "finalUrl": "https://www.kaspersky.com/downloads/free-rescue-disk",
        "title": "Free Rescue Disk Download | Kaspersky",
        "checkedAt": "2026-09-09T20:17:57.554921+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kaspersky.com/downloads/free-rescue-disk",
        "status": 200,
        "finalUrl": "https://www.kaspersky.com/downloads/free-rescue-disk",
        "title": "Free Rescue Disk Download | Kaspersky",
        "checkedAt": "2026-09-09T20:17:57.554921+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "memtest",
    "name": "MemTest86+",
    "developer": "MemTest86+ project",
    "description": "Standalone RAM testing outside the operating system; run multiple passes.",
    "categories": [
      "Hardware Diagnostics",
      "Boot & Recovery"
    ],
    "tags": [
      "test RAM memory"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://memtest.org/",
    "officialDownload": "https://memtest.org/",
    "documentation": "https://memtest.org/",
    "localFolder": "00_BOOT/Diagnostics",
    "localExecutable": "",
    "inventoryPatterns": [
      "memtest86plus*.iso",
      "mt86plus*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://memtest.org/",
        "status": 200,
        "finalUrl": "https://memtest.org/",
        "title": "Memtest86+ | The Open-Source Memory Testing Tool",
        "checkedAt": "2026-09-09T20:17:54.521547+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://memtest.org/",
        "status": 200,
        "finalUrl": "https://memtest.org/",
        "title": "Memtest86+ | The Open-Source Memory Testing Tool",
        "checkedAt": "2026-09-09T20:17:54.521547+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "passmark",
    "name": "PassMark MemTest86",
    "developer": "PassMark",
    "description": "UEFI memory diagnostics; edition features and technician rights differ.",
    "categories": [
      "Hardware Diagnostics",
      "Boot & Recovery"
    ],
    "tags": [
      "RAM UEFI"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.memtest86.com/download.htm",
    "officialDownload": "https://www.memtest86.com/download.htm",
    "documentation": "https://www.memtest86.com/download.htm",
    "localFolder": "00_BOOT/Diagnostics/PassMark",
    "localExecutable": "",
    "inventoryPatterns": [
      "memtest86*.img"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.memtest86.com/download.htm",
        "status": 200,
        "finalUrl": "https://www.memtest86.com/download.htm",
        "title": "MemTest86 - Download now!",
        "checkedAt": "2026-09-09T20:17:56.356922+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.memtest86.com/download.htm",
        "status": 200,
        "finalUrl": "https://www.memtest86.com/download.htm",
        "title": "MemTest86 - Download now!",
        "checkedAt": "2026-09-09T20:17:56.356922+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "winaero",
    "name": "Winaero Tweaker",
    "developer": "Winaero",
    "description": "Windows interface and behavior customization with reversible options.",
    "categories": [
      "Windows Tweaks"
    ],
    "tags": [
      "customization",
      "OneDrive startup",
      "Windows Backup prompts",
      "Microsoft account prompts"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://winaero.com/winaero-tweaker/",
    "officialDownload": "https://winaero.com/winaero-tweaker/",
    "documentation": "https://winaero.com/winaero-tweaker/",
    "localFolder": "10_WINDOWS_TOOLBOX/03_Windows-Tweaks/Winaero",
    "localExecutable": "10_WINDOWS_TOOLBOX/03_Windows-Tweaks/Winaero/WinaeroTweaker.exe",
    "inventoryPatterns": [
      "WinaeroTweaker.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://winaero.com/winaero-tweaker/",
        "status": 200,
        "finalUrl": "https://winaero.com/winaero-tweaker/",
        "title": "Winaero Tweaker",
        "checkedAt": "2026-09-09T20:17:55.010055+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://winaero.com/winaero-tweaker/",
        "status": 200,
        "finalUrl": "https://winaero.com/winaero-tweaker/",
        "title": "Winaero Tweaker",
        "checkedAt": "2026-09-09T20:17:55.010055+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Open Winaero Tweaker using the package for your operating system.",
      "Use it for: Windows interface and behavior customization with reversible options.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "shutup",
    "name": "O&O ShutUp10++",
    "developer": "O&O Software",
    "description": "Review privacy, telemetry and Windows feature settings with recommendations.",
    "categories": [
      "Windows Privacy",
      "Windows AI Controls"
    ],
    "tags": [
      "telemetry advertising OneDrive Copilot AI",
      "ShutUp10++",
      "OneDrive startup",
      "Windows Backup prompts",
      "Microsoft account prompts"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 3,
    "officialWebsite": "https://www.oo-software.com/en/shutup10",
    "officialDownload": "https://www.oo-software.com/en/shutup10",
    "documentation": "https://www.oo-software.com/en/shutup10",
    "localFolder": "10_WINDOWS_TOOLBOX/02_Privacy-Telemetry/ShutUp10",
    "localExecutable": "10_WINDOWS_TOOLBOX/02_Privacy-Telemetry/ShutUp10/OOSU10.exe",
    "inventoryPatterns": [
      "OOSU10.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "The current official page brands this O&O ShutUp10, with free and Premium choices. The catalog retains the familiar ShutUp10++ name for search.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.oo-software.com/en/shutup10",
        "status": 200,
        "finalUrl": "https://www.oo-software.com/en/shutup10",
        "title": "O&O ShutUp10 - O&O Software GmbH",
        "checkedAt": "2026-09-09T20:18:02.619848+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.oo-software.com/en/shutup10",
        "status": 200,
        "finalUrl": "https://www.oo-software.com/en/shutup10",
        "title": "O&O ShutUp10 - O&O Software GmbH",
        "checkedAt": "2026-09-09T20:18:02.619848+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Record the current configuration and choose individual changes.",
      "Review the consequences of each selected setting before applying it.",
      "Test the affected features and keep a rollback record."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "win11debloat",
    "name": "Win11Debloat",
    "developer": "Raphire",
    "description": "Selective app removal and controls for telemetry, Copilot, Recall, Click to Do and app AI features.",
    "categories": [
      "Windows Debloat",
      "Windows Privacy",
      "Windows AI Controls",
      "Account & OOBE"
    ],
    "tags": [
      "AI Windows AI Edge AI Paint AI Notepad AI OneDrive Bing suggestions consumer features",
      "OneDrive startup",
      "Windows Backup prompts",
      "Microsoft account prompts"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://github.com/Raphire/Win11Debloat",
    "officialDownload": "https://github.com/Raphire/Win11Debloat/releases",
    "documentation": "https://github.com/Raphire/Win11Debloat",
    "localFolder": "10_WINDOWS_TOOLBOX/04_App-Debloat/Win11Debloat",
    "localExecutable": "10_WINDOWS_TOOLBOX/04_App-Debloat/Win11Debloat/Win11Debloat.ps1",
    "inventoryPatterns": [
      "Win11Debloat.ps1"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "githubRepo": "Raphire/Win11Debloat",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/Raphire/Win11Debloat",
        "status": 200,
        "finalUrl": "https://github.com/Raphire/Win11Debloat",
        "title": "GitHub - Raphire/Win11Debloat: A simple, lightweight PowerShell script that allows you to remove pre-installed apps, disable telemetry, as well as perform various other changes to declutter and customize your Windows experience. Win11Debloat works for both Windows 10 and Windows 11. · GitHub",
        "checkedAt": "2026-09-09T20:17:52.179886+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/Raphire/Win11Debloat/releases",
        "status": 200,
        "finalUrl": "https://github.com/Raphire/Win11Debloat/releases",
        "title": "Releases · Raphire/Win11Debloat · GitHub",
        "checkedAt": "2026-09-09T20:17:52.555819+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Record the current configuration and choose individual changes.",
      "Review the consequences of each selected setting before applying it.",
      "Test the affected features and keep a rollback record."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "winutil",
    "name": "Chris Titus Tech WinUtil",
    "developer": "Chris Titus Tech",
    "description": "Interactive Windows tweaks, repair, update settings and software management; some functions need internet.",
    "categories": [
      "Windows Tweaks",
      "Windows Repair",
      "Windows Debloat",
      "Windows AI Controls",
      "Software Installers"
    ],
    "tags": [
      "debloat AI Copilot Windows repair updates"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://github.com/ChrisTitusTech/winutil",
    "officialDownload": "https://github.com/ChrisTitusTech/winutil/releases",
    "documentation": "https://github.com/ChrisTitusTech/winutil",
    "localFolder": "10_WINDOWS_TOOLBOX/03_Windows-Tweaks/WinUtil",
    "localExecutable": "10_WINDOWS_TOOLBOX/03_Windows-Tweaks/WinUtil/winutil.ps1",
    "inventoryPatterns": [
      "winutil*.ps1"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "Downloaded PowerShell script. Review the source before running; downloading does not execute it.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "githubRepo": "ChrisTitusTech/winutil",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/ChrisTitusTech/winutil",
        "status": 200,
        "finalUrl": "https://github.com/ChrisTitusTech/winutil",
        "title": "GitHub - ChrisTitusTech/winutil: Chris Titus Tech's Windows Utility - Install Programs, Tweaks, Fixes, and Updates · GitHub",
        "checkedAt": "2026-09-09T20:17:52.084613+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/ChrisTitusTech/winutil/releases",
        "status": 200,
        "finalUrl": "https://github.com/ChrisTitusTech/winutil/releases",
        "title": "Releases · ChrisTitusTech/winutil · GitHub",
        "checkedAt": "2026-09-09T20:17:52.851087+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Open Chris Titus Tech WinUtil using the package for your operating system.",
      "Use it for: Interactive Windows tweaks, repair, update settings and software management; some functions need internet.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz",
      "winutil*.ps1"
    ]
  },
  {
    "id": "appbuster",
    "name": "O&O AppBuster",
    "developer": "O&O Software",
    "description": "Remove optional Windows apps; restoration may require Store access or source packages.",
    "categories": [
      "Windows Debloat"
    ],
    "tags": [
      "built-in apps restore"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://www.oo-software.com/en/ooappbuster",
    "officialDownload": "https://www.oo-software.com/en/ooappbuster",
    "documentation": "https://www.oo-software.com/en/ooappbuster",
    "localFolder": "10_WINDOWS_TOOLBOX/04_App-Debloat/AppBuster",
    "localExecutable": "10_WINDOWS_TOOLBOX/04_App-Debloat/AppBuster/OOAPB.exe",
    "inventoryPatterns": [
      "OOAPB.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.oo-software.com/en/ooappbuster",
        "status": 200,
        "finalUrl": "https://www.oo-software.com/en/ooappbuster",
        "title": "O&O AppBuster - O&O Software GmbH",
        "checkedAt": "2026-09-09T20:17:58.180100+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.oo-software.com/en/ooappbuster",
        "status": 200,
        "finalUrl": "https://www.oo-software.com/en/ooappbuster",
        "title": "O&O AppBuster - O&O Software GmbH",
        "checkedAt": "2026-09-09T20:17:58.180100+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Open O&O AppBuster using the package for your operating system.",
      "Use it for: Remove optional Windows apps; restoration may require Store access or source packages.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "optimizernxt",
    "name": "OptimizerNXT",
    "developer": "hellzerg",
    "description": "Specialty YAML-driven configuration CLI. Review every operation; never apply a broad tweak bundle blindly.",
    "categories": [
      "Windows Privacy"
    ],
    "tags": [
      "privacy registry services"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://github.com/hellzerg/optimizerNXT",
    "officialDownload": "https://github.com/hellzerg/optimizerNXT/releases",
    "documentation": "https://github.com/hellzerg/optimizerNXT",
    "localFolder": "10_WINDOWS_TOOLBOX/02_Privacy-Telemetry/OptimizerNXT",
    "localExecutable": "10_WINDOWS_TOOLBOX/02_Privacy-Telemetry/OptimizerNXT/optimizerNXT.exe",
    "inventoryPatterns": [
      "optimizerNXT.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "githubRepo": "hellzerg/optimizerNXT",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/hellzerg/optimizerNXT",
        "status": 200,
        "finalUrl": "https://github.com/hellzerg/optimizerNXT",
        "title": "GitHub - hellzerg/optimizerNXT: The finest Windows Optimizer CLI · GitHub",
        "checkedAt": "2026-09-09T20:17:52.354293+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/hellzerg/optimizerNXT/releases",
        "status": 200,
        "finalUrl": "https://github.com/hellzerg/optimizerNXT/releases",
        "title": "Releases · hellzerg/optimizerNXT · GitHub",
        "checkedAt": "2026-09-09T20:17:52.423548+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Record the current configuration and choose individual changes.",
      "Review the consequences of each selected setting before applying it.",
      "Test the affected features and keep a rollback record."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "revo",
    "name": "Revo Uninstaller Pro Portable",
    "developer": "VS Revo Group",
    "description": "Licensed portable uninstaller with monitored uninstall and leftover review.",
    "categories": [
      "Uninstallers",
      "Licensed Tools"
    ],
    "tags": [
      "stubborn software"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Portable licensing is per user rather than per computer. Obtain the paid portable package from your account and verify the current license scope for client service.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 80,
    "officialWebsite": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
    "officialDownload": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
    "documentation": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
    "localFolder": "80_LICENSED_TOOLS/Revo",
    "localExecutable": "80_LICENSED_TOOLS/Revo/RevoUPPort.exe",
    "inventoryPatterns": [
      "RevoUPPort.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "5.5.2",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
        "status": 200,
        "finalUrl": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
        "title": "Download Revo Uninstaller Freeware - Free and Full Download",
        "checkedAt": "2026-09-09T20:17:58.355650+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
        "status": 200,
        "finalUrl": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
        "title": "Download Revo Uninstaller Freeware - Free and Full Download",
        "checkedAt": "2026-09-09T20:17:58.355650+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Review the installed application list and choose only approved removals.",
      "Create a restore or backup option and inspect the uninstall plan.",
      "Review leftovers manually and test required applications afterward."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "bcu",
    "name": "Bulk Crap Uninstaller",
    "developer": "Klocman",
    "description": "Open-source batch uninstaller; preview selected programs and leftovers.",
    "categories": [
      "Uninstallers"
    ],
    "tags": [
      "BCU BCUninstaller stubborn software"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Open source",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.bcuninstaller.com/",
    "officialDownload": "https://github.com/Klocman/Bulk-Crap-Uninstaller/releases",
    "documentation": "https://www.bcuninstaller.com/",
    "localFolder": "10_WINDOWS_TOOLBOX/01_Uninstallers/BCUninstaller",
    "localExecutable": "10_WINDOWS_TOOLBOX/01_Uninstallers/BCUninstaller/BCUninstaller.exe",
    "inventoryPatterns": [
      "BCUninstaller.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.bcuninstaller.com/",
        "status": 200,
        "finalUrl": "https://www.bcuninstaller.com/",
        "title": "Bulk Crap Uninstaller - Remove large amounts of unwanted applications",
        "checkedAt": "2026-09-09T20:17:54.857733+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.bcuninstaller.com/",
        "status": 200,
        "finalUrl": "https://www.bcuninstaller.com/",
        "title": "Bulk Crap Uninstaller - Remove large amounts of unwanted applications",
        "checkedAt": "2026-09-09T20:17:54.857733+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "packagePatterns": [
      "BCUninstaller*.zip",
      "BCUninstaller*setup*.exe",
      "BCUninstaller*installer*.exe"
    ],
    "quickStart": [
      "Extract the portable ZIP or install the setup package.",
      "Launch BCUninstaller and review the detected applications; select only approved removals.",
      "Review the uninstall plan and leftover list, then verify that required applications still work."
    ],
    "packageVersionPattern": "BCUninstaller[_-](\\d+(?:\\.\\d+)+)",
    "automationSupport": {
      "level": "documented",
      "source": "https://www.bcuninstaller.com/",
      "notes": "Batch uninstall automation; review application uninstallers and removal choices."
    },
    "licenseSource": "https://www.bcuninstaller.com/"
  },
  {
    "id": "geek",
    "name": "Geek Uninstaller",
    "developer": "Thomas Koen",
    "description": "Small single-app uninstaller; free edition is personal-use only.",
    "categories": [
      "Uninstallers"
    ],
    "tags": [
      "uninstall"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 6,
    "officialWebsite": "https://geekuninstaller.com/download",
    "officialDownload": "https://geekuninstaller.com/download",
    "documentation": "https://geekuninstaller.com/download",
    "localFolder": "10_WINDOWS_TOOLBOX/01_Uninstallers/Geek",
    "localExecutable": "10_WINDOWS_TOOLBOX/01_Uninstallers/Geek/geek.exe",
    "inventoryPatterns": [
      "geek.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "1.5.4.180",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://geekuninstaller.com/download",
        "status": 200,
        "finalUrl": "https://geekuninstaller.com/download",
        "title": "Geek Uninstaller - Download",
        "checkedAt": "2026-09-09T20:17:51.438751+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://geekuninstaller.com/download",
        "status": 200,
        "finalUrl": "https://geekuninstaller.com/download",
        "title": "Geek Uninstaller - Download",
        "checkedAt": "2026-09-09T20:17:51.438751+00:00",
        "contentType": "text/html"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Review the installed application list and choose only approved removals.",
      "Create a restore or backup option and inspect the uninstall plan.",
      "Review leftovers manually and test required applications afterward."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "hibit",
    "name": "HiBit Uninstaller",
    "developer": "HiBitSoft",
    "description": "Alternative uninstaller. Use uninstall functions only; skip registry cleaning and speed claims.",
    "categories": [
      "Uninstallers"
    ],
    "tags": [
      "uninstall"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.hibitsoft.ir/Uninstaller.html",
    "officialDownload": "https://www.hibitsoft.ir/Uninstaller.html",
    "documentation": "https://www.hibitsoft.ir/Uninstaller.html",
    "localFolder": "10_WINDOWS_TOOLBOX/01_Uninstallers/HiBit",
    "localExecutable": "",
    "inventoryPatterns": [
      "HiBitUninstaller*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "4.0.10",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.hibitsoft.ir/Uninstaller.html",
        "status": 200,
        "finalUrl": "https://www.hibitsoft.ir/Uninstaller.html",
        "title": "HiBit Uninstaller",
        "checkedAt": "2026-09-09T20:17:56.941318+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.hibitsoft.ir/Uninstaller.html",
        "status": 200,
        "finalUrl": "https://www.hibitsoft.ir/Uninstaller.html",
        "title": "HiBit Uninstaller",
        "checkedAt": "2026-09-09T20:17:56.941318+00:00",
        "contentType": "text/html"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Review the installed application list and choose only approved removals.",
      "Create a restore or backup option and inspect the uninstall plan.",
      "Review leftovers manually and test required applications afterward."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "rufus",
    "name": "Rufus Portable",
    "developer": "Akeo",
    "description": "Create Windows installation USB media; supported setup choices vary by Windows release.",
    "categories": [
      "USB Tools",
      "Account & OOBE"
    ],
    "tags": [
      "OOBE local account Windows install"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 3,
    "officialWebsite": "https://rufus.ie/",
    "officialDownload": "https://rufus.ie/",
    "documentation": "https://rufus.ie/",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/Rufus",
    "localExecutable": "",
    "inventoryPatterns": [
      "rufus*p.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://rufus.ie/",
        "status": 200,
        "finalUrl": "https://rufus.ie/",
        "title": "Rufus - The Official Website (Download, New Releases)",
        "checkedAt": "2026-09-09T20:17:53.976953+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://rufus.ie/",
        "status": 200,
        "finalUrl": "https://rufus.ie/",
        "title": "Rufus - The Official Website (Download, New Releases)",
        "checkedAt": "2026-09-09T20:17:53.976953+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Rufus Portable using the package for your operating system.",
      "Use it for: Create Windows installation USB media; supported setup choices vary by Windows release.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "ntlite",
    "name": "NTLite",
    "developer": "Nlitesoft",
    "description": "Customize Windows images and unattended setup; removing components can break updates.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "unattended setup local account"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.ntlite.com/download/",
    "officialDownload": "https://www.ntlite.com/download/",
    "documentation": "https://www.ntlite.com/download/",
    "localFolder": "10_WINDOWS_TOOLBOX/06_Account-OOBE/NTLite",
    "localExecutable": "",
    "inventoryPatterns": [
      "NTLite*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ntlite.com/download/",
        "status": 200,
        "finalUrl": "https://ntlite.com/download/",
        "title": "Download | NTLite",
        "checkedAt": "2026-09-09T20:17:57.138313+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.ntlite.com/download/",
        "status": 200,
        "finalUrl": "https://ntlite.com/download/",
        "title": "Download | NTLite",
        "checkedAt": "2026-09-09T20:17:57.138313+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open NTLite using the package for your operating system.",
      "Use it for: Customize Windows images and unattended setup; removing components can break updates.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "easeus",
    "name": "EaseUS Partition Master",
    "developer": "EaseUS",
    "description": "Licensed partition and migration option; keep your authorized installer and license separately.",
    "categories": [
      "Disk & Partition",
      "Licensed Tools"
    ],
    "tags": [
      "SSD partition"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://www.easeus.com/partition-manager/",
    "officialDownload": "https://www.easeus.com/partition-manager/",
    "documentation": "https://www.easeus.com/partition-manager/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.easeus.com/partition-manager/",
        "status": 200,
        "finalUrl": "https://www.easeus.com/partition-manager/",
        "title": "EaseUS Partition Master | Best Partition Software for All Windows Users.",
        "checkedAt": "2026-09-09T20:17:55.255165+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.easeus.com/partition-manager/",
        "status": 200,
        "finalUrl": "https://www.easeus.com/partition-manager/",
        "title": "EaseUS Partition Master | Best Partition Software for All Windows Users.",
        "checkedAt": "2026-09-09T20:17:55.255165+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open EaseUS Partition Master using the package for your operating system.",
      "Use it for: Licensed partition and migration option; keep your authorized installer and license separately.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "diskgenius",
    "name": "DiskGenius",
    "developer": "Eassos",
    "description": "Partition, file recovery and cloning tools with edition-specific capabilities.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "SSD clone recover files"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://www.diskgenius.com/download.php",
    "officialDownload": "https://www.diskgenius.com/download.php",
    "documentation": "https://www.diskgenius.com/download.php",
    "localFolder": "10_WINDOWS_TOOLBOX/14_Specialty/DiskGenius",
    "localExecutable": "10_WINDOWS_TOOLBOX/14_Specialty/DiskGenius/DiskGenius.exe",
    "inventoryPatterns": [
      "DiskGenius.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.diskgenius.com/download.php",
        "status": 200,
        "finalUrl": "https://www.diskgenius.com/download.php",
        "title": "DiskGenius Download Center | Free Download DiskGenius",
        "checkedAt": "2026-09-09T20:17:55.224607+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.diskgenius.com/download.php",
        "status": 200,
        "finalUrl": "https://www.diskgenius.com/download.php",
        "title": "DiskGenius Download Center | Free Download DiskGenius",
        "checkedAt": "2026-09-09T20:17:55.224607+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open DiskGenius using the package for your operating system.",
      "Use it for: Partition, file recovery and cloning tools with edition-specific capabilities.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "minitool",
    "name": "MiniTool Partition Wizard",
    "developer": "MiniTool",
    "description": "Optional partition manager; confirm whether your edition permits commercial service.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "partition SSD"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.partitionwizard.com/download.html",
    "officialDownload": "https://www.partitionwizard.com/download.html",
    "documentation": "https://www.partitionwizard.com/download.html",
    "localFolder": "10_WINDOWS_TOOLBOX/14_Specialty/MiniTool",
    "localExecutable": "",
    "inventoryPatterns": [
      "pw*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.partitionwizard.com/download.html",
        "status": 200,
        "finalUrl": "https://www.partitionwizard.com/download.html",
        "title": "Free Download MiniTool Partition Wizard for Windows PC and Server",
        "checkedAt": "2026-09-09T20:17:57.371045+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.partitionwizard.com/download.html",
        "status": 200,
        "finalUrl": "https://www.partitionwizard.com/download.html",
        "title": "Free Download MiniTool Partition Wizard for Windows PC and Server",
        "checkedAt": "2026-09-09T20:17:57.371045+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open MiniTool Partition Wizard using the package for your operating system.",
      "Use it for: Optional partition manager; confirm whether your edition permits commercial service.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "aomei",
    "name": "AOMEI Partition Assistant",
    "developer": "AOMEI",
    "description": "Optional partition suite with separate paid technician editions.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "partition SSD"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.diskpart.com/download.html",
    "officialDownload": "https://www.diskpart.com/download.html",
    "documentation": "https://www.diskpart.com/download.html",
    "localFolder": "10_WINDOWS_TOOLBOX/14_Specialty/AOMEI",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.diskpart.com/download.html",
        "status": 200,
        "finalUrl": "https://www.diskpart.com/download.html",
        "title": "Free Download Hard Disk Partition Manager Software | AOMEI Partition Assistant Download",
        "checkedAt": "2026-09-09T20:17:55.544811+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.diskpart.com/download.html",
        "status": 200,
        "finalUrl": "https://www.diskpart.com/download.html",
        "title": "Free Download Hard Disk Partition Manager Software | AOMEI Partition Assistant Download",
        "checkedAt": "2026-09-09T20:17:55.544811+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open AOMEI Partition Assistant using the package for your operating system.",
      "Use it for: Optional partition suite with separate paid technician editions.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "macrium",
    "name": "Macrium Reflect",
    "developer": "Macrium Software",
    "description": "Paid Windows image backup and restore; select a current authorized edition.",
    "categories": [
      "Imaging & Cloning",
      "Licensed Tools",
      "Backup & Sync"
    ],
    "tags": [
      "SSD clone backup"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 500,
    "officialWebsite": "https://www.macrium.com/products/home",
    "officialDownload": "https://www.macrium.com/products/home",
    "documentation": "https://www.macrium.com/products/home",
    "localFolder": "80_LICENSED_TOOLS/Other/Macrium",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.macrium.com/products/home",
        "status": 200,
        "finalUrl": "https://www.macrium.com/products/home",
        "title": "Macrium Reflect Home | The complete backup solution for personal use.",
        "checkedAt": "2026-09-09T20:17:56.841494+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.macrium.com/products/home",
        "status": 200,
        "finalUrl": "https://www.macrium.com/products/home",
        "title": "Macrium Reflect Home | The complete backup solution for personal use.",
        "checkedAt": "2026-09-09T20:17:56.841494+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Macrium Reflect using the package for your operating system.",
      "Use it for: Paid Windows image backup and restore; select a current authorized edition.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "veeam",
    "name": "Veeam Agent for Microsoft Windows",
    "developer": "Veeam",
    "description": "Windows endpoint backup and recovery; installation and recovery media preparation required.",
    "categories": [
      "Imaging & Cloning",
      "Backup & Sync"
    ],
    "tags": [
      "backup image",
      "veeam",
      "veam",
      "backup",
      "nas"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 800,
    "officialWebsite": "https://www.veeam.com/products/free/microsoft-windows.html",
    "officialDownload": "https://www.veeam.com/products/free/microsoft-windows.html",
    "documentation": "https://www.veeam.com/products/free/microsoft-windows.html",
    "localFolder": "40_INSTALLERS/Utilities/Veeam",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.veeam.com/products/free/microsoft-windows.html",
        "status": 200,
        "finalUrl": "https://www.veeam.com/products/free/microsoft-windows.html",
        "title": "Free Windows Backup Solution for PCs and Endpoints",
        "checkedAt": "2026-09-09T20:17:59.197256+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.veeam.com/products/free/microsoft-windows.html",
        "status": 200,
        "finalUrl": "https://www.veeam.com/products/free/microsoft-windows.html",
        "title": "Free Windows Backup Solution for PCs and Endpoints",
        "checkedAt": "2026-09-09T20:17:59.197256+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Install the appropriate Veeam Agent edition from the publisher.",
      "Create recovery media, then choose your system, volumes or folders and a separate backup destination.",
      "Run a backup and test recovery media and a sample file restore; verify edition limits before business deployment."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "testdisk",
    "name": "TestDisk",
    "developer": "CGSecurity",
    "description": "Recover lost partitions and inspect filesystems; analyze an image before writing changes.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "recover files partition"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 40,
    "officialWebsite": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "officialDownload": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "documentation": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "localFolder": "20_PORTABLE_APPS/Misc/TestDisk",
    "localExecutable": "20_PORTABLE_APPS/Misc/TestDisk/testdisk_win.exe",
    "inventoryPatterns": [
      "testdisk_win.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "status": 200,
        "finalUrl": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "title": "TestDisk Download - CGSecurity",
        "checkedAt": "2026-09-09T20:17:55.726221+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "status": 200,
        "finalUrl": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "title": "TestDisk Download - CGSecurity",
        "checkedAt": "2026-09-09T20:17:55.726221+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Stop writing to the affected drive and preserve an image where possible.",
      "Select the source and begin a read-only scan or preview.",
      "Recover files to separate healthy storage, then validate a sample."
    ]
  },
  {
    "id": "photorec",
    "name": "PhotoRec",
    "developer": "CGSecurity",
    "description": "Signature-based file recovery when directory structures are damaged; filenames may be lost.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "recover files photos"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 40,
    "officialWebsite": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "officialDownload": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "documentation": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "localFolder": "20_PORTABLE_APPS/Misc/TestDisk",
    "localExecutable": "20_PORTABLE_APPS/Misc/TestDisk/photorec_win.exe",
    "inventoryPatterns": [
      "photorec_win.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "status": 200,
        "finalUrl": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "title": "TestDisk Download - CGSecurity",
        "checkedAt": "2026-09-09T20:17:55.726221+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "status": 200,
        "finalUrl": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "title": "TestDisk Download - CGSecurity",
        "checkedAt": "2026-09-09T20:17:55.726221+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Stop writing to the affected drive and preserve an image where possible.",
      "Select the source and begin a read-only scan or preview.",
      "Recover files to separate healthy storage, then validate a sample."
    ]
  },
  {
    "id": "dmde",
    "name": "DMDE",
    "developer": "DMDE Software",
    "description": "Inspect disks, recover files and work with images; free edition has recovery limits.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "recover files failing disk SSD"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://dmde.com/download.html",
    "officialDownload": "https://dmde.com/download.html",
    "documentation": "https://dmde.com/download.html",
    "localFolder": "20_PORTABLE_APPS/Misc/DMDE",
    "localExecutable": "20_PORTABLE_APPS/Misc/DMDE/dmde.exe",
    "inventoryPatterns": [
      "dmde.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://dmde.com/download.html",
        "status": 200,
        "finalUrl": "https://dmde.com/download.html",
        "title": "Download DMDE - All Versions (DM Disk Editor and Data Recovery Software)",
        "checkedAt": "2026-09-09T20:17:51.136549+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://dmde.com/download.html",
        "status": 200,
        "finalUrl": "https://dmde.com/download.html",
        "title": "Download DMDE - All Versions (DM Disk Editor and Data Recovery Software)",
        "checkedAt": "2026-09-09T20:17:51.136549+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Stop writing to the affected drive and preserve an image where possible.",
      "Select the source and begin a read-only scan or preview.",
      "Recover files to separate healthy storage, then validate a sample."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "recuva",
    "name": "Recuva",
    "developer": "Piriform / CCleaner",
    "description": "Simple deleted-file recovery for healthy media; do not install onto the source drive.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "undelete"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.ccleaner.com/recuva/download",
    "officialDownload": "https://www.ccleaner.com/recuva/download",
    "documentation": "https://www.ccleaner.com/recuva/download",
    "localFolder": "40_INSTALLERS/Utilities/Recuva",
    "localExecutable": "",
    "inventoryPatterns": [
      "rcsetup*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ccleaner.com/recuva/download",
        "status": 200,
        "finalUrl": "https://www.ccleaner.com/recuva/download",
        "title": "Recuva - Free Download",
        "checkedAt": "2026-09-09T20:17:54.969444+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.ccleaner.com/recuva/download",
        "status": 200,
        "finalUrl": "https://www.ccleaner.com/recuva/download",
        "title": "Recuva - Free Download",
        "checkedAt": "2026-09-09T20:17:54.969444+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Stop writing to the affected drive and preserve an image where possible.",
      "Select the source and begin a read-only scan or preview.",
      "Recover files to separate healthy storage, then validate a sample."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "rstudio",
    "name": "R-Studio",
    "developer": "R-Tools Technology",
    "description": "Commercial recovery suite with filesystem and RAID reconstruction tools.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "RAID recover files"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://www.r-studio.com/data-recovery-software/",
    "officialDownload": "https://www.r-studio.com/data-recovery-software/",
    "documentation": "https://www.r-studio.com/data-recovery-software/",
    "localFolder": "80_LICENSED_TOOLS/Other/R-Studio",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.r-studio.com/data-recovery-software/",
        "status": 200,
        "finalUrl": "https://www.r-studio.com/data-recovery-software/",
        "title": "R-STUDIO Data Recovery Software",
        "checkedAt": "2026-09-09T20:17:57.802833+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.r-studio.com/data-recovery-software/",
        "status": 200,
        "finalUrl": "https://www.r-studio.com/data-recovery-software/",
        "title": "R-STUDIO Data Recovery Software",
        "checkedAt": "2026-09-09T20:17:57.802833+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Stop writing to the affected drive and preserve an image where possible.",
      "Select the source and begin a read-only scan or preview.",
      "Recover files to separate healthy storage, then validate a sample."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "ufs",
    "name": "UFS Explorer",
    "developer": "SysDev Laboratories",
    "description": "Specialty commercial recovery for complex filesystems, NAS and RAID.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "NAS RAID recovery"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://www.ufsexplorer.com/",
    "officialDownload": "https://www.ufsexplorer.com/",
    "documentation": "https://www.ufsexplorer.com/",
    "localFolder": "80_LICENSED_TOOLS/Other/UFS-Explorer",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ufsexplorer.com/",
        "status": 200,
        "finalUrl": "https://www.ufsexplorer.com/",
        "title": "Tried and trusted data recovery software solutions",
        "checkedAt": "2026-09-09T20:17:59.017604+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.ufsexplorer.com/",
        "status": 200,
        "finalUrl": "https://www.ufsexplorer.com/",
        "title": "Tried and trusted data recovery software solutions",
        "checkedAt": "2026-09-09T20:17:59.017604+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Stop writing to the affected drive and preserve an image where possible.",
      "Select the source and begin a read-only scan or preview.",
      "Recover files to separate healthy storage, then validate a sample."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "cdi",
    "name": "CrystalDiskInfo",
    "developer": "Crystal Dew World",
    "description": "Read SMART attributes, temperature and drive health indicators; USB bridges may hide SMART.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD HDD SMART health failing disk"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://crystalmark.info/en/software/crystaldiskinfo/",
    "officialDownload": "https://crystalmark.info/en/software/crystaldiskinfo/",
    "documentation": "https://crystalmark.info/en/software/crystaldiskinfo/",
    "localFolder": "20_PORTABLE_APPS/Misc/CrystalDiskInfo",
    "localExecutable": "20_PORTABLE_APPS/Misc/CrystalDiskInfo/DiskInfo64.exe",
    "inventoryPatterns": [
      "DiskInfo64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://crystalmark.info/en/software/crystaldiskinfo/",
        "status": 200,
        "finalUrl": "https://crystalmark.info/en/software/crystaldiskinfo/",
        "title": "CrystalDiskInfo – Crystal Dew World",
        "checkedAt": "2026-09-09T20:17:51.769542+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://crystalmark.info/en/software/crystaldiskinfo/",
        "status": 200,
        "finalUrl": "https://crystalmark.info/en/software/crystaldiskinfo/",
        "title": "CrystalDiskInfo – Crystal Dew World",
        "checkedAt": "2026-09-09T20:17:51.769542+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "cdm",
    "name": "CrystalDiskMark",
    "developer": "Crystal Dew World",
    "description": "Storage throughput benchmark; writes test data and is unsuitable for failing drives.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD HDD benchmark"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://crystalmark.info/en/software/crystaldiskmark/",
    "officialDownload": "https://crystalmark.info/en/software/crystaldiskmark/",
    "documentation": "https://crystalmark.info/en/software/crystaldiskmark/",
    "localFolder": "20_PORTABLE_APPS/Misc/CrystalDiskMark",
    "localExecutable": "20_PORTABLE_APPS/Misc/CrystalDiskMark/DiskMark64.exe",
    "inventoryPatterns": [
      "DiskMark64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://crystalmark.info/en/software/crystaldiskmark/",
        "status": 200,
        "finalUrl": "https://crystalmark.info/en/software/crystaldiskmark/",
        "title": "CrystalDiskMark – Crystal Dew World",
        "checkedAt": "2026-09-09T20:17:52.329734+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://crystalmark.info/en/software/crystaldiskmark/",
        "status": 200,
        "finalUrl": "https://crystalmark.info/en/software/crystaldiskmark/",
        "title": "CrystalDiskMark – Crystal Dew World",
        "checkedAt": "2026-09-09T20:17:52.329734+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "gsmart",
    "name": "GSmartControl",
    "developer": "GSmartControl project",
    "description": "Graphical SMART viewer and drive self-test controller.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD HDD SMART"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://gsmartcontrol.shaduri.dev/downloads",
    "officialDownload": "https://gsmartcontrol.shaduri.dev/downloads",
    "documentation": "https://gsmartcontrol.shaduri.dev/downloads",
    "localFolder": "20_PORTABLE_APPS/Misc/GSmartControl",
    "localExecutable": "20_PORTABLE_APPS/Misc/GSmartControl/gsmartcontrol.exe",
    "inventoryPatterns": [
      "gsmartcontrol.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://gsmartcontrol.shaduri.dev/downloads",
        "status": 200,
        "finalUrl": "https://gsmartcontrol.shaduri.dev/downloads",
        "title": "Downloads · GSmartControl",
        "checkedAt": "2026-09-09T20:17:52.491691+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://gsmartcontrol.shaduri.dev/downloads",
        "status": 200,
        "finalUrl": "https://gsmartcontrol.shaduri.dev/downloads",
        "title": "Downloads · GSmartControl",
        "checkedAt": "2026-09-09T20:17:52.491691+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "smartmontools",
    "name": "smartmontools",
    "developer": "smartmontools project",
    "description": "Read drive SMART and NVMe health; extended tests add load to damaged media.",
    "categories": [
      "Storage Diagnostics",
      "Homelab / Linux"
    ],
    "tags": [
      "SSD HDD SMART smartctl failing disk"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.smartmontools.org/",
    "officialDownload": "https://www.smartmontools.org/",
    "documentation": "https://www.smartmontools.org/",
    "localFolder": "20_PORTABLE_APPS/Misc/smartmontools",
    "localExecutable": "20_PORTABLE_APPS/Misc/smartmontools/smartctl.exe",
    "inventoryPatterns": [
      "smartctl.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official project listing reviewed",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.smartmontools.org/",
        "status": 200,
        "finalUrl": "https://www.smartmontools.org/",
        "title": "Making sure you're not a bot!",
        "checkedAt": "2026-09-09T20:17:58.508673+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.smartmontools.org/",
        "status": 200,
        "finalUrl": "https://www.smartmontools.org/",
        "title": "Making sure you're not a bot!",
        "checkedAt": "2026-09-09T20:17:58.508673+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Project GitHub releases reviewed; primary domain presents bot challenge. Version remains manual.",
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "hddscan",
    "name": "HDDScan",
    "developer": "HDDScan project",
    "description": "Specialty storage diagnostics. Avoid write/erase tests and confirm current hardware support.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "HDD surface"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://hddscan.com/",
    "officialDownload": "https://hddscan.com/",
    "documentation": "https://hddscan.com/",
    "localFolder": "20_PORTABLE_APPS/Misc/HDDScan",
    "localExecutable": "20_PORTABLE_APPS/Misc/HDDScan/HDDScan.exe",
    "inventoryPatterns": [
      "HDDScan.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "The official site still offers 4.1; recent development could not be established. Kept P4 for legacy/specialty diagnosis, not a default modern SSD recommendation.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://hddscan.com/",
        "status": 200,
        "finalUrl": "https://hddscan.com/",
        "title": "HDDScan - FREE HDD and SSD Test Diagnostics Software with RAID and USB Flash support",
        "checkedAt": "2026-09-09T20:17:52.958872+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://hddscan.com/",
        "status": 200,
        "finalUrl": "https://hddscan.com/",
        "title": "HDDScan - FREE HDD and SSD Test Diagnostics Software with RAID and USB Flash support",
        "checkedAt": "2026-09-09T20:17:52.958872+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "samsung",
    "name": "Samsung Magician",
    "developer": "Samsung",
    "description": "Supported Samsung SSD health, maintenance and firmware; features depend on model.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD firmware Samsung"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://semiconductor.samsung.com/consumer-storage/magician/",
    "officialDownload": "https://semiconductor.samsung.com/consumer-storage/magician/",
    "documentation": "https://semiconductor.samsung.com/consumer-storage/magician/",
    "localFolder": "50_FIRMWARE/SSD/Samsung",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://semiconductor.samsung.com/consumer-storage/magician/",
        "status": 200,
        "finalUrl": "https://semiconductor.samsung.com/consumer-storage/magician/",
        "title": "Samsung Magician Software Download | Consumer Storage | Samsung Semiconductor Global",
        "checkedAt": "2026-09-09T20:17:54.198156+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://semiconductor.samsung.com/consumer-storage/magician/",
        "status": 200,
        "finalUrl": "https://semiconductor.samsung.com/consumer-storage/magician/",
        "title": "Samsung Magician Software Download | Consumer Storage | Samsung Semiconductor Global",
        "checkedAt": "2026-09-09T20:17:54.198156+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "wd",
    "name": "Western Digital / SanDisk support",
    "developer": "Western Digital",
    "description": "Select the exact drive model to locate its current utility and firmware; older Dashboard packages may be retired.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "SSD HDD Western Digital SanDisk"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://support-en.wd.com/",
    "officialDownload": "https://support-en.wd.com/",
    "documentation": "https://support-en.wd.com/",
    "localFolder": "50_FIRMWARE/SSD/WD",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://support-en.wd.com/",
        "status": 200,
        "finalUrl": "https://www.westerndigital.com/support",
        "title": "",
        "checkedAt": "2026-09-09T20:17:55.052759+00:00",
        "contentType": "text/html;charset=utf-8"
      },
      "download": {
        "url": "https://support-en.wd.com/",
        "status": 200,
        "finalUrl": "https://www.westerndigital.com/support",
        "title": "",
        "checkedAt": "2026-09-09T20:17:55.052759+00:00",
        "contentType": "text/html;charset=utf-8"
      }
    },
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "seatools",
    "name": "SeaTools",
    "developer": "Seagate",
    "description": "Manufacturer drive diagnostics; distinguish read tests from erase and repair functions.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD HDD Seagate"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://www.seagate.com/support/downloads/seatools/",
    "officialDownload": "https://www.seagate.com/support/downloads/seatools/",
    "documentation": "https://www.seagate.com/support/downloads/seatools/",
    "localFolder": "50_FIRMWARE/SSD/Seagate",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.seagate.com/support/downloads/seatools/",
        "status": 200,
        "finalUrl": "https://www.seagate.com/support/downloads/seatools/",
        "title": "SeaTools | Seagate US",
        "checkedAt": "2026-09-09T20:17:57.871611+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.seagate.com/support/downloads/seatools/",
        "status": 200,
        "finalUrl": "https://www.seagate.com/support/downloads/seatools/",
        "title": "SeaTools | Seagate US",
        "checkedAt": "2026-09-09T20:17:57.871611+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "crucial",
    "name": "Crucial Storage Executive",
    "developer": "Micron / Crucial",
    "description": "Supported Crucial SSD monitoring and firmware tools; check model support first.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD Crucial firmware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 250,
    "officialWebsite": "https://www.crucial.com/support/storage-executive",
    "officialDownload": "https://www.crucial.com/support/storage-executive",
    "documentation": "https://www.crucial.com/support/storage-executive",
    "localFolder": "50_FIRMWARE/SSD/Crucial",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": " Official page rejects both direct and web retrieval in this audit. Confirm current utility and model support before downloading.",
    "sourceStatus": "Manual source check needed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.crucial.com/support/storage-executive",
        "status": 200,
        "finalUrl": "https://www.crucial.com/support/storage-executive",
        "title": "Request Rejected",
        "checkedAt": "2026-09-09T20:17:55.089341+00:00",
        "contentType": "text/plain"
      },
      "download": {
        "url": "https://www.crucial.com/support/storage-executive",
        "status": 200,
        "finalUrl": "https://www.crucial.com/support/storage-executive",
        "title": "Request Rejected",
        "checkedAt": "2026-09-09T20:17:55.089341+00:00",
        "contentType": "text/plain"
      }
    },
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "solidigm",
    "name": "Solidigm Storage Tool",
    "developer": "Solidigm",
    "description": "Model-specific SSD management and firmware resources.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD firmware Solidigm"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.solidigm.com/support-page/drivers-downloads.html",
    "officialDownload": "https://www.solidigm.com/support-page/drivers-downloads.html",
    "documentation": "https://www.solidigm.com/support-page/drivers-downloads.html",
    "localFolder": "50_FIRMWARE/SSD/Solidigm",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.solidigm.com/support-page/drivers-downloads.html",
        "status": 200,
        "finalUrl": "https://www.solidigm.com/support/drivers-downloads.html",
        "title": "Drivers & Downloads",
        "checkedAt": "2026-09-09T20:17:58.600002+00:00",
        "contentType": "text/html;charset=utf-8"
      },
      "download": {
        "url": "https://www.solidigm.com/support-page/drivers-downloads.html",
        "status": 200,
        "finalUrl": "https://www.solidigm.com/support/drivers-downloads.html",
        "title": "Drivers & Downloads",
        "checkedAt": "2026-09-09T20:17:58.600002+00:00",
        "contentType": "text/html;charset=utf-8"
      }
    },
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "kingston",
    "name": "Kingston SSD Manager",
    "developer": "Kingston",
    "description": "Supported Kingston SSD health and firmware maintenance.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD Kingston firmware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 60,
    "officialWebsite": "https://www.kingston.com/en/support/technical/ssdmanager",
    "officialDownload": "https://www.kingston.com/en/support/technical/ssdmanager",
    "documentation": "https://www.kingston.com/en/support/technical/ssdmanager",
    "localFolder": "50_FIRMWARE/SSD/Kingston",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kingston.com/en/support/technical/ssdmanager",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:55.823954+00:00"
      },
      "download": {
        "url": "https://www.kingston.com/en/support/technical/ssdmanager",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:55.823954+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Select the intended drive by model and serial number.",
      "Read health information before initiating any extended test.",
      "Save the report; prioritize backup if the drive shows errors."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "hwinfo",
    "name": "HWiNFO",
    "developer": "REALiX",
    "description": "Detailed hardware inventory, sensors and logging for thermal and stability diagnosis.",
    "categories": [
      "Hardware Diagnostics",
      "Gaming"
    ],
    "tags": [
      "GPU CPU temperatures crash"
    ],
    "useCases": [
      "GPU troubleshooting",
      "GPU crash"
    ],
    "priority": "P1",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 25,
    "officialWebsite": "https://www.hwinfo.com/download/",
    "officialDownload": "https://www.hwinfo.com/download/",
    "documentation": "https://www.hwinfo.com/download/",
    "localFolder": "20_PORTABLE_APPS/Misc/HWiNFO",
    "localExecutable": "20_PORTABLE_APPS/Misc/HWiNFO/HWiNFO64.exe",
    "inventoryPatterns": [
      "HWiNFO64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.hwinfo.com/download/",
        "status": 200,
        "finalUrl": "https://www.hwinfo.com/download/",
        "title": "Free Download HWiNFO Sofware | Installer & Portable for Windows, DOS",
        "checkedAt": "2026-09-09T20:17:56.156087+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.hwinfo.com/download/",
        "status": 200,
        "finalUrl": "https://www.hwinfo.com/download/",
        "title": "Free Download HWiNFO Sofware | Installer & Portable for Windows, DOS",
        "checkedAt": "2026-09-09T20:17:56.156087+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open HWiNFO using the package for your operating system.",
      "Use it for: Detailed hardware inventory, sensors and logging for thermal and stability diagnosis.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "cpuz",
    "name": "CPU-Z",
    "developer": "CPUID",
    "description": "Identify CPU, mainboard and RAM timings; compare configured memory speed.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "CPU RAM motherboard"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.cpuid.com/softwares/cpu-z.html",
    "officialDownload": "https://www.cpuid.com/softwares/cpu-z.html",
    "documentation": "https://www.cpuid.com/softwares/cpu-z.html",
    "localFolder": "20_PORTABLE_APPS/Misc/CPU-Z",
    "localExecutable": "20_PORTABLE_APPS/Misc/CPU-Z/cpuz_x64.exe",
    "inventoryPatterns": [
      "cpuz_x64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.cpuid.com/softwares/cpu-z.html",
        "status": 200,
        "finalUrl": "https://www.cpuid.com/softwares/cpu-z.html",
        "title": "CPU-Z | Softwares | CPUID",
        "checkedAt": "2026-09-09T20:17:56.159097+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.cpuid.com/softwares/cpu-z.html",
        "status": 200,
        "finalUrl": "https://www.cpuid.com/softwares/cpu-z.html",
        "title": "CPU-Z | Softwares | CPUID",
        "checkedAt": "2026-09-09T20:17:56.159097+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open CPU-Z using the package for your operating system.",
      "Use it for: Identify CPU, mainboard and RAM timings; compare configured memory speed.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "gpuz",
    "name": "GPU-Z",
    "developer": "TechPowerUp",
    "description": "Identify GPU, video BIOS and sensors; log behavior during crashes.",
    "categories": [
      "Hardware Diagnostics",
      "Gaming"
    ],
    "tags": [
      "GPU crash graphics"
    ],
    "useCases": [
      "GPU troubleshooting",
      "GPU crash"
    ],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.techpowerup.com/gpuz/",
    "officialDownload": "https://www.techpowerup.com/gpuz/",
    "documentation": "https://www.techpowerup.com/gpuz/",
    "localFolder": "20_PORTABLE_APPS/Misc/GPU-Z",
    "localExecutable": "",
    "inventoryPatterns": [
      "GPU-Z*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.techpowerup.com/gpuz/",
        "status": 200,
        "finalUrl": "https://www.techpowerup.com/gpuz/",
        "title": "GPU-Z Graphics Card GPU Information Utility",
        "checkedAt": "2026-09-09T20:17:58.901035+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.techpowerup.com/gpuz/",
        "status": 200,
        "finalUrl": "https://www.techpowerup.com/gpuz/",
        "title": "GPU-Z Graphics Card GPU Information Utility",
        "checkedAt": "2026-09-09T20:17:58.901035+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open GPU-Z using the package for your operating system.",
      "Use it for: Identify GPU, video BIOS and sensors; log behavior during crashes.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "occt",
    "name": "OCCT",
    "developer": "OCBASE",
    "description": "CPU, GPU, memory and power stability tests; choose one subsystem at a time.",
    "categories": [
      "Hardware Diagnostics",
      "Gaming"
    ],
    "tags": [
      "GPU CPU stress temperatures"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 250,
    "officialWebsite": "https://www.ocbase.com/download",
    "officialDownload": "https://www.ocbase.com/download",
    "documentation": "https://www.ocbase.com/download",
    "localFolder": "20_PORTABLE_APPS/Misc/OCCT",
    "localExecutable": "",
    "inventoryPatterns": [
      "OCCT*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ocbase.com/download",
        "status": 200,
        "finalUrl": "https://www.ocbase.com/download-personal",
        "title": "OCCT Personal Download - OCBASE/OCCT",
        "checkedAt": "2026-09-09T20:17:58.907065+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.ocbase.com/download",
        "status": 200,
        "finalUrl": "https://www.ocbase.com/download-personal",
        "title": "OCCT Personal Download - OCBASE/OCCT",
        "checkedAt": "2026-09-09T20:17:58.907065+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open OCCT using the package for your operating system.",
      "Use it for: CPU, GPU, memory and power stability tests; choose one subsystem at a time.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "prime95",
    "name": "Prime95",
    "developer": "GIMPS",
    "description": "CPU and memory stress testing with different FFT workloads; stop on errors or overheating.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "CPU RAM stress"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.mersenne.org/download/",
    "officialDownload": "https://www.mersenne.org/download/",
    "documentation": "https://www.mersenne.org/download/",
    "localFolder": "20_PORTABLE_APPS/Misc/Prime95",
    "localExecutable": "20_PORTABLE_APPS/Misc/Prime95/prime95.exe",
    "inventoryPatterns": [
      "prime95.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.mersenne.org/download/",
        "status": 200,
        "finalUrl": "https://www.mersenne.org/download/",
        "title": "GIMPS - Free Prime95 software downloads - PrimeNet",
        "checkedAt": "2026-09-09T20:17:56.078654+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.mersenne.org/download/",
        "status": 200,
        "finalUrl": "https://www.mersenne.org/download/",
        "title": "GIMPS - Free Prime95 software downloads - PrimeNet",
        "checkedAt": "2026-09-09T20:17:56.078654+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Prime95 using the package for your operating system.",
      "Use it for: CPU and memory stress testing with different FFT workloads; stop on errors or overheating.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "furmark",
    "name": "FurMark",
    "developer": "Geeks3D",
    "description": "Heavy graphics stress workload to expose cooling and stability issues.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "GPU stress"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://geeks3d.com/furmark/",
    "officialDownload": "https://geeks3d.com/furmark/",
    "documentation": "https://geeks3d.com/furmark/",
    "localFolder": "20_PORTABLE_APPS/Misc/FurMark",
    "localExecutable": "",
    "inventoryPatterns": [
      "FurMark*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://geeks3d.com/furmark/",
        "status": 200,
        "finalUrl": "https://geeks3d.com/furmark/",
        "title": "FurMark Homepage",
        "checkedAt": "2026-09-09T20:17:51.805662+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://geeks3d.com/furmark/",
        "status": 200,
        "finalUrl": "https://geeks3d.com/furmark/",
        "title": "FurMark Homepage",
        "checkedAt": "2026-09-09T20:17:51.805662+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open FurMark using the package for your operating system.",
      "Use it for: Heavy graphics stress workload to expose cooling and stability issues.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "cinebench",
    "name": "Cinebench",
    "developer": "Maxon",
    "description": "Repeatable rendering benchmark for CPU performance and thermal comparison.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "CPU benchmark stress"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.maxon.net/en/cinebench",
    "officialDownload": "https://www.maxon.net/en/cinebench",
    "documentation": "https://www.maxon.net/en/cinebench",
    "localFolder": "40_INSTALLERS/Utilities/Cinebench",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.maxon.net/en/cinebench",
        "status": 200,
        "finalUrl": "https://www.maxon.net/en/cinebench",
        "title": "Evaluate your computer's hardware capabilities | Cinebench from Maxon",
        "checkedAt": "2026-09-09T20:17:57.374569+00:00",
        "contentType": "text/html;charset=utf-8"
      },
      "download": {
        "url": "https://www.maxon.net/en/cinebench",
        "status": 200,
        "finalUrl": "https://www.maxon.net/en/cinebench",
        "title": "Evaluate your computer's hardware capabilities | Cinebench from Maxon",
        "checkedAt": "2026-09-09T20:17:57.374569+00:00",
        "contentType": "text/html;charset=utf-8"
      }
    },
    "quickStart": [
      "Open Cinebench using the package for your operating system.",
      "Use it for: Repeatable rendering benchmark for CPU performance and thermal comparison.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "hwmonitor",
    "name": "HWMonitor",
    "developer": "CPUID",
    "description": "Simple voltage, fan and temperature overview as an alternative sensor view.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "temperature"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.cpuid.com/softwares/hwmonitor.html",
    "officialDownload": "https://www.cpuid.com/softwares/hwmonitor.html",
    "documentation": "https://www.cpuid.com/softwares/hwmonitor.html",
    "localFolder": "20_PORTABLE_APPS/Misc/HWMonitor",
    "localExecutable": "20_PORTABLE_APPS/Misc/HWMonitor/HWMonitor_x64.exe",
    "inventoryPatterns": [
      "HWMonitor_x64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.cpuid.com/softwares/hwmonitor.html",
        "status": 200,
        "finalUrl": "https://www.cpuid.com/softwares/hwmonitor.html",
        "title": "HWMONITOR | Softwares | CPUID",
        "checkedAt": "2026-09-09T20:17:55.941695+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.cpuid.com/softwares/hwmonitor.html",
        "status": 200,
        "finalUrl": "https://www.cpuid.com/softwares/hwmonitor.html",
        "title": "HWMONITOR | Softwares | CPUID",
        "checkedAt": "2026-09-09T20:17:55.941695+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open HWMonitor using the package for your operating system.",
      "Use it for: Simple voltage, fan and temperature overview as an alternative sensor view.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "coretemp",
    "name": "Core Temp",
    "developer": "ALCPU",
    "description": "Per-core CPU temperature monitoring; review installer options carefully.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "CPU temperature"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.alcpu.com/CoreTemp/",
    "officialDownload": "https://www.alcpu.com/CoreTemp/",
    "documentation": "https://www.alcpu.com/CoreTemp/",
    "localFolder": "20_PORTABLE_APPS/Misc/CoreTemp",
    "localExecutable": "20_PORTABLE_APPS/Misc/CoreTemp/Core Temp.exe",
    "inventoryPatterns": [
      "Core Temp.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.alcpu.com/CoreTemp/",
        "status": 200,
        "finalUrl": "https://www.alcpu.com/CoreTemp/",
        "title": "Core Temp",
        "checkedAt": "2026-09-09T20:17:55.011561+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.alcpu.com/CoreTemp/",
        "status": 200,
        "finalUrl": "https://www.alcpu.com/CoreTemp/",
        "title": "Core Temp",
        "checkedAt": "2026-09-09T20:17:55.011561+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Core Temp using the package for your operating system.",
      "Use it for: Per-core CPU temperature monitoring; review installer options carefully.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "latencymon",
    "name": "LatencyMon",
    "developer": "Resplendence",
    "description": "Analyze DPC/ISR latency associated with audio dropouts and driver issues.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "audio driver latency"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.resplendence.com/latencymon",
    "officialDownload": "https://www.resplendence.com/latencymon",
    "documentation": "https://www.resplendence.com/latencymon",
    "localFolder": "40_INSTALLERS/Utilities/LatencyMon",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.resplendence.com/latencymon",
        "status": 200,
        "finalUrl": "https://www.resplendence.com/latencymon",
        "title": "Resplendence Software - LatencyMon: suitability checker for real-time audio and other tasks",
        "checkedAt": "2026-09-09T20:17:58.319466+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.resplendence.com/latencymon",
        "status": 200,
        "finalUrl": "https://www.resplendence.com/latencymon",
        "title": "Resplendence Software - LatencyMon: suitability checker for real-time audio and other tasks",
        "checkedAt": "2026-09-09T20:17:58.319466+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open LatencyMon using the package for your operating system.",
      "Use it for: Analyze DPC/ISR latency associated with audio dropouts and driver issues.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "ddu",
    "name": "Display Driver Uninstaller",
    "developer": "Wagnardsoft",
    "description": "Remove graphics driver remnants, preferably in Safe Mode; stage replacement drivers first.",
    "categories": [
      "Drivers",
      "Gaming"
    ],
    "tags": [
      "GPU crash NVIDIA AMD Intel"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
    "officialDownload": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
    "documentation": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
    "localFolder": "10_WINDOWS_TOOLBOX/14_Specialty/DDU",
    "localExecutable": "10_WINDOWS_TOOLBOX/14_Specialty/DDU/Display Driver Uninstaller.exe",
    "inventoryPatterns": [
      "Display Driver Uninstaller.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
        "status": 200,
        "finalUrl": "https://www.wagnardsoft.com/display-driver-uninstaller-ddu",
        "title": "Download Display Driver Uninstaller (DDU) Official Latest Version | Wagnardsoft",
        "checkedAt": "2026-09-09T20:17:59.273487+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
        "status": 200,
        "finalUrl": "https://www.wagnardsoft.com/display-driver-uninstaller-ddu",
        "title": "Download Display Driver Uninstaller (DDU) Official Latest Version | Wagnardsoft",
        "checkedAt": "2026-09-09T20:17:59.273487+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "sdio",
    "name": "Snappy Driver Installer Origin",
    "developer": "SDIO project",
    "description": "Offline driver pack library; stage network packs first and verify hardware IDs before installation.",
    "categories": [
      "Drivers",
      "Hardware Diagnostics"
    ],
    "tags": [
      "no Wi-Fi no network offline drivers"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 80000,
    "officialWebsite": "https://www.snappy-driver-installer.org/",
    "officialDownload": "https://www.snappy-driver-installer.org/",
    "documentation": "https://www.snappy-driver-installer.org/",
    "localFolder": "30_DRIVERS/SDIO",
    "localExecutable": "",
    "inventoryPatterns": [
      "SDIO_x64*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Executable detection does not prove the full offline pack library exists. Preserve indexes and driver packs; inspect package coverage within SDIO before visiting a disconnected PC.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.snappy-driver-installer.org/",
        "status": 200,
        "finalUrl": "https://www.snappy-driver-installer.org/",
        "title": "Snappy Driver Installer Origin – The original driver installation tool for Windows.",
        "checkedAt": "2026-09-09T20:17:58.510676+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.snappy-driver-installer.org/",
        "status": 200,
        "finalUrl": "https://www.snappy-driver-installer.org/",
        "title": "Snappy Driver Installer Origin – The original driver installation tool for Windows.",
        "checkedAt": "2026-09-09T20:17:58.510676+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "wireshark",
    "name": "Wireshark",
    "developer": "Wireshark Foundation",
    "description": "Packet capture and protocol analysis. Live capture on Windows requires a capture driver.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "packet loss DNS DHCP",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.wireshark.org/download.html",
    "officialDownload": "https://www.wireshark.org/download.html",
    "documentation": "https://www.wireshark.org/download.html",
    "localFolder": "20_PORTABLE_APPS/Misc/Wireshark",
    "localExecutable": "20_PORTABLE_APPS/Misc/Wireshark/Wireshark.exe",
    "inventoryPatterns": [
      "Wireshark.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.wireshark.org/download.html",
        "status": 200,
        "finalUrl": "https://www.wireshark.org/download.html",
        "title": "Wireshark • Go Deep | Download",
        "checkedAt": "2026-09-09T20:17:58.801670+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.wireshark.org/download.html",
        "status": 200,
        "finalUrl": "https://www.wireshark.org/download.html",
        "title": "Wireshark • Go Deep | Download",
        "checkedAt": "2026-09-09T20:17:58.801670+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Wireshark using the package for your operating system.",
      "Use it for: Packet capture and protocol analysis. Live capture on Windows requires a capture driver.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "nmap",
    "name": "Nmap",
    "developer": "Nmap project",
    "description": "Authorized host discovery and service checks; review Npcap and commercial redistribution terms.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "LAN discovery port scan",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://nmap.org/download.html",
    "officialDownload": "https://nmap.org/download.html",
    "documentation": "https://nmap.org/download.html",
    "localFolder": "40_INSTALLERS/Utilities/Nmap",
    "localExecutable": "",
    "inventoryPatterns": [
      "nmap*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://nmap.org/download.html",
        "status": 200,
        "finalUrl": "https://nmap.org/download.html",
        "title": "Download the Free Nmap Security Scanner for Linux/Mac/Windows",
        "checkedAt": "2026-09-09T20:17:53.835079+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://nmap.org/download.html",
        "status": 200,
        "finalUrl": "https://nmap.org/download.html",
        "title": "Download the Free Nmap Security Scanner for Linux/Mac/Windows",
        "checkedAt": "2026-09-09T20:17:53.835079+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Nmap using the package for your operating system.",
      "Use it for: Authorized host discovery and service checks; review Npcap and commercial redistribution terms.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "angryip",
    "name": "Angry IP Scanner",
    "developer": "Angry IP Scanner project",
    "description": "Quick authorized LAN host discovery; Java runtime may be required.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "LAN discovery",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://angryip.org/download/",
    "officialDownload": "https://angryip.org/download/",
    "documentation": "https://angryip.org/download/",
    "localFolder": "20_PORTABLE_APPS/Misc/AngryIP",
    "localExecutable": "",
    "inventoryPatterns": [
      "ipscan*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://angryip.org/download/",
        "status": 200,
        "finalUrl": "https://angryip.org/download/",
        "title": "Angry IP Scanner - Download for Windows, Mac or Linux",
        "checkedAt": "2026-09-09T20:17:51.192186+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://angryip.org/download/",
        "status": 200,
        "finalUrl": "https://angryip.org/download/",
        "title": "Angry IP Scanner - Download for Windows, Mac or Linux",
        "checkedAt": "2026-09-09T20:17:51.192186+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Angry IP Scanner using the package for your operating system.",
      "Use it for: Quick authorized LAN host discovery; Java runtime may be required.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "advancedip",
    "name": "Advanced IP Scanner",
    "developer": "Famatech",
    "description": "Optional Windows LAN discovery interface; scan only networks you administer.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "LAN discovery",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://www.advanced-ip-scanner.com/",
    "officialDownload": "https://www.advanced-ip-scanner.com/",
    "documentation": "https://www.advanced-ip-scanner.com/",
    "localFolder": "40_INSTALLERS/Utilities/AdvancedIP",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.advanced-ip-scanner.com/",
        "status": 200,
        "finalUrl": "https://www.advanced-ip-scanner.com/",
        "title": "Advanced IP Scanner - Download Free Network Scanner",
        "checkedAt": "2026-09-09T20:17:55.647042+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.advanced-ip-scanner.com/",
        "status": 200,
        "finalUrl": "https://www.advanced-ip-scanner.com/",
        "title": "Advanced IP Scanner - Download Free Network Scanner",
        "checkedAt": "2026-09-09T20:17:55.647042+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Advanced IP Scanner using the package for your operating system.",
      "Use it for: Optional Windows LAN discovery interface; scan only networks you administer.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "iperf3",
    "name": "iperf3",
    "developer": "ESnet",
    "description": "Measure LAN throughput between two endpoints. Upstream supports Unix; Windows builds are not supplied here.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "slow Ethernet slow Wi-Fi throughput",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://software.es.net/iperf/obtaining.html",
    "officialDownload": "https://software.es.net/iperf/obtaining.html",
    "documentation": "https://software.es.net/iperf/obtaining.html",
    "localFolder": "20_PORTABLE_APPS/Misc/iperf3",
    "localExecutable": "20_PORTABLE_APPS/Misc/iperf3/iperf3",
    "inventoryPatterns": [
      "iperf3"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://software.es.net/iperf/obtaining.html",
        "status": 200,
        "finalUrl": "https://software.es.net/iperf/obtaining.html",
        "title": "Obtaining iperf3 — iperf3 3.21 documentation",
        "checkedAt": "2026-09-09T20:17:54.093349+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://software.es.net/iperf/obtaining.html",
        "status": 200,
        "finalUrl": "https://software.es.net/iperf/obtaining.html",
        "title": "Obtaining iperf3 — iperf3 3.21 documentation",
        "checkedAt": "2026-09-09T20:17:54.093349+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open iperf3 using the package for your operating system.",
      "Use it for: Measure LAN throughput between two endpoints. Upstream supports Unix; Windows builds are not supplied here.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "putty",
    "name": "PuTTY",
    "developer": "Simon Tatham",
    "description": "SSH and serial terminal for authorized servers and network equipment.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "SSH serial homelab",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
    "officialDownload": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
    "documentation": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
    "localFolder": "20_PORTABLE_APPS/Misc/PuTTY",
    "localExecutable": "20_PORTABLE_APPS/Misc/PuTTY/putty.exe",
    "inventoryPatterns": [
      "putty.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "0.85",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
        "status": 200,
        "finalUrl": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
        "title": "Download PuTTY: latest release (0.85)",
        "checkedAt": "2026-09-09T20:17:55.519250+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
        "status": 200,
        "finalUrl": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
        "title": "Download PuTTY: latest release (0.85)",
        "checkedAt": "2026-09-09T20:17:55.519250+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open PuTTY using the package for your operating system.",
      "Use it for: SSH and serial terminal for authorized servers and network equipment.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "winscp",
    "name": "WinSCP",
    "developer": "WinSCP project",
    "description": "SFTP/SCP file transfer; validate host keys and avoid saving customer credentials.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "SFTP SSH",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 25,
    "officialWebsite": "https://winscp.net/eng/downloads.php",
    "officialDownload": "https://winscp.net/eng/downloads.php",
    "documentation": "https://winscp.net/eng/downloads.php",
    "localFolder": "20_PORTABLE_APPS/Misc/WinSCP",
    "localExecutable": "20_PORTABLE_APPS/Misc/WinSCP/WinSCP.exe",
    "inventoryPatterns": [
      "WinSCP.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://winscp.net/eng/downloads.php",
        "status": 200,
        "finalUrl": "https://winscp.net/eng/downloads.php",
        "title": "All Downloads :: WinSCP",
        "checkedAt": "2026-09-09T20:17:55.315799+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://winscp.net/eng/downloads.php",
        "status": 200,
        "finalUrl": "https://winscp.net/eng/downloads.php",
        "title": "All Downloads :: WinSCP",
        "checkedAt": "2026-09-09T20:17:55.315799+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open WinSCP using the package for your operating system.",
      "Use it for: SFTP/SCP file transfer; validate host keys and avoid saving customer credentials.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "rustdesk",
    "name": "RustDesk",
    "developer": "RustDesk project",
    "description": "Attended portable remote support; service installation enables different access behavior.",
    "categories": [
      "Remote Support"
    ],
    "tags": [
      "remote attended"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://rustdesk.com/",
    "officialDownload": "https://rustdesk.com/",
    "documentation": "https://rustdesk.com/docs/en/",
    "localFolder": "40_INSTALLERS/Remote-Support/RustDesk",
    "localExecutable": "",
    "inventoryPatterns": [
      "rustdesk*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Attended access only by default. Unattended service installation and enrollment must be separately authorized. Portable behavior depends on the downloaded build; do not install the service or enable unattended access automatically.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://rustdesk.com/",
        "status": 200,
        "finalUrl": "https://rustdesk.com/",
        "title": "RustDesk: Open-Source Remote Desktop with Self-Hosted Server Solutions",
        "checkedAt": "2026-09-09T20:17:54.164054+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://rustdesk.com/",
        "status": 200,
        "finalUrl": "https://rustdesk.com/",
        "title": "RustDesk: Open-Source Remote Desktop with Self-Hosted Server Solutions",
        "checkedAt": "2026-09-09T20:17:54.164054+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Install or open the appropriate client on the authorized devices.",
      "Verify the remote user/device identity and approve only the required session permissions.",
      "Test connectivity, complete the support task, then disconnect and remove temporary access."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "anydesk",
    "name": "AnyDesk",
    "developer": "AnyDesk Software",
    "description": "Attended remote client; commercial support requires appropriate licensing.",
    "categories": [
      "Remote Support"
    ],
    "tags": [
      "remote attended"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://anydesk.com/en/downloads/windows",
    "officialDownload": "https://anydesk.com/en/downloads/windows",
    "documentation": "https://support.anydesk.com/docs/how-do-i-install-and-set-up-anydesk",
    "localFolder": "40_INSTALLERS/Remote-Support/AnyDesk",
    "localExecutable": "40_INSTALLERS/Remote-Support/AnyDesk/AnyDesk.exe",
    "inventoryPatterns": [
      "AnyDesk.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "9.7.15",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Attended access only by default. Unattended service installation and enrollment must be separately authorized.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://anydesk.com/en/downloads/windows",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:51.239282+00:00"
      },
      "download": {
        "url": "https://anydesk.com/en/downloads/windows",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:51.239282+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Install or open the appropriate client on the authorized devices.",
      "Verify the remote user/device identity and approve only the required session permissions.",
      "Test connectivity, complete the support task, then disconnect and remove temporary access."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "tailscale",
    "name": "Tailscale",
    "developer": "Tailscale",
    "description": "Installed private-network agent; enrollment and access policies are separate from remote desktop.",
    "categories": [
      "Remote Support"
    ],
    "tags": [
      "VPN homelab agent"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 60,
    "officialWebsite": "https://tailscale.com/download/windows",
    "officialDownload": "https://tailscale.com/download/windows",
    "documentation": "https://tailscale.com/docs/install",
    "localFolder": "40_INSTALLERS/Remote-Support/Tailscale",
    "localExecutable": "",
    "inventoryPatterns": [
      "tailscale*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Attended access only by default. Unattended service installation and enrollment must be separately authorized.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://tailscale.com/download/windows",
        "status": 200,
        "finalUrl": "https://tailscale.com/download/windows",
        "title": "Download | Tailscale",
        "checkedAt": "2026-09-09T20:17:54.547609+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://tailscale.com/download/windows",
        "status": 200,
        "finalUrl": "https://tailscale.com/download/windows",
        "title": "Download | Tailscale",
        "checkedAt": "2026-09-09T20:17:54.547609+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Install Tailscale on the devices and sign in to the approved tailnet.",
      "Approve the devices and restrict access with the organization policy.",
      "Test connectivity by Tailscale address; use a separate remote desktop client for screen control."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "safetyscanner",
    "name": "Microsoft Safety Scanner",
    "developer": "Microsoft",
    "description": "On-demand defensive malware scan. DOWNLOAD FRESH COPY; expires 10 days after download.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "malware scan"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
    "officialDownload": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
    "documentation": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
    "localFolder": "20_PORTABLE_APPS/Misc/SafetyScanner",
    "localExecutable": "20_PORTABLE_APPS/Misc/SafetyScanner/msert.exe",
    "inventoryPatterns": [
      "msert.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": true,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
        "title": "Microsoft Safety Scanner Download - Microsoft Defender for Endpoint | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.653572+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
        "title": "Microsoft Safety Scanner Download - Microsoft Defender for Endpoint | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.653572+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Microsoft Safety Scanner using the package for your operating system.",
      "Use it for: On-demand defensive malware scan. DOWNLOAD FRESH COPY; expires 10 days after download.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "eek",
    "name": "Emsisoft Emergency Kit",
    "developer": "Emsisoft",
    "description": "Portable second-opinion scanner; refresh definitions and check technician licensing.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "malware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 500,
    "officialWebsite": "https://www.emsisoft.com/en/emergency-kit/",
    "officialDownload": "https://www.emsisoft.com/en/emergency-kit/",
    "documentation": "https://www.emsisoft.com/en/emergency-kit/",
    "localFolder": "20_PORTABLE_APPS/Misc/Emsisoft",
    "localExecutable": "20_PORTABLE_APPS/Misc/Emsisoft/Start Emergency Kit Scanner.exe",
    "inventoryPatterns": [
      "Start Emergency Kit Scanner.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": true,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.emsisoft.com/en/emergency-kit/",
        "status": 200,
        "finalUrl": "https://www.emsisoft.com/en/emergency-kit/",
        "title": "Emsisoft Emergency Kit: Free Portable Malware & Virus Scanner",
        "checkedAt": "2026-09-09T20:17:56.602708+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.emsisoft.com/en/emergency-kit/",
        "status": 200,
        "finalUrl": "https://www.emsisoft.com/en/emergency-kit/",
        "title": "Emsisoft Emergency Kit: Free Portable Malware & Virus Scanner",
        "checkedAt": "2026-09-09T20:17:56.602708+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open Emsisoft Emergency Kit using the package for your operating system.",
      "Use it for: Portable second-opinion scanner; refresh definitions and check technician licensing.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "malwarebytes",
    "name": "Malwarebytes",
    "developer": "Malwarebytes",
    "description": "Installed second-opinion scanner; service work and business use need suitable terms.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "malware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.malwarebytes.com/mwb-download",
    "officialDownload": "https://www.malwarebytes.com/mwb-download",
    "documentation": "https://www.malwarebytes.com/mwb-download",
    "localFolder": "40_INSTALLERS/Utilities/Malwarebytes",
    "localExecutable": "",
    "inventoryPatterns": [
      "MBSetup*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.malwarebytes.com/mwb-download",
        "status": 200,
        "finalUrl": "https://www.malwarebytes.com/mwb-download",
        "title": "Malwarebytes Free: Free Antivirus 2026 | 100% Free & Easy Install",
        "checkedAt": "2026-09-09T20:17:55.969749+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.malwarebytes.com/mwb-download",
        "status": 200,
        "finalUrl": "https://www.malwarebytes.com/mwb-download",
        "title": "Malwarebytes Free: Free Antivirus 2026 | 100% Free & Easy Install",
        "checkedAt": "2026-09-09T20:17:55.969749+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open Malwarebytes using the package for your operating system.",
      "Use it for: Installed second-opinion scanner; service work and business use need suitable terms.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "adwcleaner",
    "name": "AdwCleaner",
    "developer": "Malwarebytes",
    "description": "Portable adware and potentially unwanted program scanner.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "adware malware browser"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.malwarebytes.com/adwcleaner",
    "officialDownload": "https://www.malwarebytes.com/adwcleaner",
    "documentation": "https://www.malwarebytes.com/adwcleaner",
    "localFolder": "20_PORTABLE_APPS/Misc/AdwCleaner",
    "localExecutable": "",
    "inventoryPatterns": [
      "adwcleaner*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": true,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.malwarebytes.com/adwcleaner",
        "status": 200,
        "finalUrl": "https://www.malwarebytes.com/adwcleaner",
        "title": "AdwCleaner: Free Adware Removal & Cleaner Tool",
        "checkedAt": "2026-09-09T20:17:55.915145+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.malwarebytes.com/adwcleaner",
        "status": 200,
        "finalUrl": "https://www.malwarebytes.com/adwcleaner",
        "title": "AdwCleaner: Free Adware Removal & Cleaner Tool",
        "checkedAt": "2026-09-09T20:17:55.915145+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open AdwCleaner using the package for your operating system.",
      "Use it for: Portable adware and potentially unwanted program scanner.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firefox",
    "name": "Firefox Portable",
    "developer": "Mozilla / PortableApps.com",
    "description": "Portable browser package published by PortableApps.com; web browsing needs connectivity.",
    "categories": [
      "Portable Apps",
      "Browsers"
    ],
    "tags": [
      "browser"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 250,
    "officialWebsite": "https://portableapps.com/apps/internet/firefox_portable",
    "officialDownload": "https://portableapps.com/apps/internet/firefox_portable",
    "documentation": "https://portableapps.com/apps/internet/firefox_portable",
    "localFolder": "20_PORTABLE_APPS/Browsers/Firefox",
    "localExecutable": "20_PORTABLE_APPS/Browsers/Firefox/FirefoxPortable.exe",
    "inventoryPatterns": [
      "FirefoxPortable.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://portableapps.com/apps/internet/firefox_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/internet/firefox_portable",
        "title": "Mozilla Firefox, Portable Edition | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.640842+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://portableapps.com/apps/internet/firefox_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/internet/firefox_portable",
        "title": "Mozilla Firefox, Portable Edition | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.640842+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Firefox Portable using the package for your operating system.",
      "Use it for: Portable browser package published by PortableApps.com; web browsing needs connectivity.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "chrome",
    "name": "Google Chrome installer",
    "developer": "Google",
    "description": "Official browser installer; choose an offline enterprise package when needed.",
    "categories": [
      "Software Installers",
      "Browsers"
    ],
    "tags": [
      "browser"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://chromeenterprise.google/download/",
    "officialDownload": "https://chromeenterprise.google/download/",
    "documentation": "https://chromeenterprise.google/download/",
    "localFolder": "40_INSTALLERS/Browsers/Chrome",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.msi"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://chromeenterprise.google/download/",
        "status": 200,
        "finalUrl": "https://chromeenterprise.google/download/",
        "title": "Enterprise Browser Download for Windows & Mac - Chrome Enterprise",
        "checkedAt": "2026-09-09T20:17:51.389132+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://chromeenterprise.google/download/",
        "status": 200,
        "finalUrl": "https://chromeenterprise.google/download/",
        "title": "Enterprise Browser Download for Windows & Mac - Chrome Enterprise",
        "checkedAt": "2026-09-09T20:17:51.389132+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Google Chrome installer using the package for your operating system.",
      "Use it for: Official browser installer; choose an offline enterprise package when needed.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "edge",
    "name": "Microsoft Edge installer",
    "developer": "Microsoft",
    "description": "Official Edge for Business offline installer selection.",
    "categories": [
      "Software Installers",
      "Browsers"
    ],
    "tags": [
      "browser"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 180,
    "officialWebsite": "https://www.microsoft.com/en-us/edge/business/download",
    "officialDownload": "https://www.microsoft.com/en-us/edge/business/download",
    "documentation": "https://www.microsoft.com/en-us/edge/business/download",
    "localFolder": "40_INSTALLERS/Browsers/Edge",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.msi"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.microsoft.com/en-us/edge/business/download",
        "status": 200,
        "finalUrl": "https://explore.microsoft.com/en-us/edge/business/download?form=MA13FJ",
        "title": "Download and Deploy Microsoft Edge for Business",
        "checkedAt": "2026-09-09T20:18:00.132104+00:00",
        "contentType": "text/html;charset=utf-8"
      },
      "download": {
        "url": "https://www.microsoft.com/en-us/edge/business/download",
        "status": 200,
        "finalUrl": "https://explore.microsoft.com/en-us/edge/business/download?form=MA13FJ",
        "title": "Download and Deploy Microsoft Edge for Business",
        "checkedAt": "2026-09-09T20:18:00.132104+00:00",
        "contentType": "text/html;charset=utf-8"
      }
    },
    "quickStart": [
      "Open Microsoft Edge installer using the package for your operating system.",
      "Use it for: Official Edge for Business offline installer selection.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "7zip",
    "name": "7-Zip",
    "developer": "Igor Pavlov",
    "description": "Archive extraction and creation; official standalone console packages are also available.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "zip archive"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Open source",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.7-zip.org/download.html",
    "officialDownload": "https://www.7-zip.org/download.html",
    "documentation": "https://www.7-zip.org/download.html",
    "localFolder": "20_PORTABLE_APPS/Archive/7-Zip",
    "localExecutable": "",
    "inventoryPatterns": [
      "7z.exe",
      "7za.exe",
      "7zFM.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "For the full GUI, install/extract the official package appropriately. The standalone 7-Zip Extra console package contains 7za.exe; both console names are recognized.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.7-zip.org/download.html",
        "status": 200,
        "finalUrl": "https://www.7-zip.org/download.html",
        "title": "Download",
        "checkedAt": "2026-09-09T20:17:55.295770+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.7-zip.org/download.html",
        "status": 200,
        "finalUrl": "https://www.7-zip.org/download.html",
        "title": "Download",
        "checkedAt": "2026-09-09T20:17:55.295770+00:00",
        "contentType": "text/html"
      }
    },
    "packagePatterns": [
      "7z[0-9]*.exe",
      "7z[0-9]*.msi",
      "7z[0-9]*.7z",
      "7z[0-9]*.tar.xz",
      "7zr.exe"
    ],
    "quickStart": [
      "Choose the correct OS/CPU package; the Windows EXE is an installer, while Linux/macOS builds are command-line packages.",
      "Install the Windows GUI on the target PC or extract the appropriate standalone package.",
      "Open the archive and extract into a new folder; verify the extracted files before using them."
    ],
    "packageVersionPattern": "^7z(\\d{2})(\\d{2})",
    "automationSupport": {
      "level": "documented",
      "source": "https://www.7-zip.org/",
      "notes": "Command-line archive operations; select explicit input and output paths."
    },
    "licenseSource": "https://www.7-zip.org/"
  },
  {
    "id": "nanazip",
    "name": "NanaZip",
    "developer": "M2-Team",
    "description": "Modern Windows archive integration; MSIX installation is required.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "archive"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://github.com/M2Team/NanaZip",
    "officialDownload": "https://github.com/M2Team/NanaZip/releases",
    "documentation": "https://github.com/M2Team/NanaZip",
    "localFolder": "40_INSTALLERS/Utilities/NanaZip",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.msixbundle"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "githubRepo": "M2Team/NanaZip",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/M2Team/NanaZip",
        "status": 200,
        "finalUrl": "https://github.com/M2Team/NanaZip",
        "title": "GitHub - M2Team/NanaZip: The 7-Zip derivative intended for the modern Windows experience · GitHub",
        "checkedAt": "2026-09-09T20:17:52.356294+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/M2Team/NanaZip/releases",
        "status": 200,
        "finalUrl": "https://github.com/M2Team/NanaZip/releases",
        "title": "Releases · M2Team/NanaZip · GitHub",
        "checkedAt": "2026-09-09T20:17:52.448588+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open NanaZip using the package for your operating system.",
      "Use it for: Modern Windows archive integration; MSIX installation is required.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "notepad",
    "name": "Notepad++",
    "developer": "Notepad++ project",
    "description": "Lightweight portable editor for logs, configuration and scripts.",
    "categories": [
      "Developer Tools",
      "Portable Apps"
    ],
    "tags": [
      "text editor"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://notepad-plus-plus.org/downloads/",
    "officialDownload": "https://notepad-plus-plus.org/downloads/",
    "documentation": "https://notepad-plus-plus.org/downloads/",
    "localFolder": "20_PORTABLE_APPS/Text-Editors/Notepad++",
    "localExecutable": "20_PORTABLE_APPS/Text-Editors/Notepad++/notepad++.exe",
    "inventoryPatterns": [
      "notepad++.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://notepad-plus-plus.org/downloads/",
        "status": 200,
        "finalUrl": "https://notepad-plus-plus.org/downloads/",
        "title": "Downloads | Notepad++",
        "checkedAt": "2026-09-09T20:17:54.579181+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://notepad-plus-plus.org/downloads/",
        "status": 200,
        "finalUrl": "https://notepad-plus-plus.org/downloads/",
        "title": "Downloads | Notepad++",
        "checkedAt": "2026-09-09T20:17:54.579181+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Notepad++ using the package for your operating system.",
      "Use it for: Lightweight portable editor for logs, configuration and scripts.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "vscode",
    "name": "Visual Studio Code (VS Code / portable)",
    "developer": "Microsoft",
    "description": "Extract the ZIP and create a data folder beside Code.exe to enable portable mode.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "code editor",
      "vs code",
      "vscode"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 500,
    "officialWebsite": "https://code.visualstudio.com/docs/setup/portable",
    "officialDownload": "https://code.visualstudio.com/docs/setup/portable",
    "documentation": "https://code.visualstudio.com/docs/setup/portable",
    "localFolder": "20_PORTABLE_APPS/Text-Editors/VSCode",
    "localExecutable": "20_PORTABLE_APPS/Text-Editors/VSCode/Code.exe",
    "inventoryPatterns": [
      "Code.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://code.visualstudio.com/docs/setup/portable",
        "status": 200,
        "finalUrl": "https://code.visualstudio.com/docs/setup/portable",
        "title": "Portable mode",
        "checkedAt": "2026-09-09T20:17:51.490880+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://code.visualstudio.com/docs/setup/portable",
        "status": 200,
        "finalUrl": "https://code.visualstudio.com/docs/setup/portable",
        "title": "Portable mode",
        "checkedAt": "2026-09-09T20:17:51.490880+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Visual Studio Code Portable using the package for your operating system.",
      "Use it for: Extract the ZIP and create a data folder beside Code.exe to enable portable mode.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "winmerge",
    "name": "WinMerge",
    "developer": "WinMerge project",
    "description": "Compare text files and directories; inspect differences before merging.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "diff compare"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://winmerge.org/downloads/",
    "officialDownload": "https://winmerge.org/downloads/",
    "documentation": "https://winmerge.org/downloads/",
    "localFolder": "20_PORTABLE_APPS/Text-Editors/WinMerge",
    "localExecutable": "20_PORTABLE_APPS/Text-Editors/WinMerge/WinMergeU.exe",
    "inventoryPatterns": [
      "WinMergeU.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://winmerge.org/downloads/",
        "status": 200,
        "finalUrl": "https://winmerge.org/downloads/",
        "title": "Download WinMerge - WinMerge",
        "checkedAt": "2026-09-09T20:17:54.856733+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://winmerge.org/downloads/",
        "status": 200,
        "finalUrl": "https://winmerge.org/downloads/",
        "title": "Download WinMerge - WinMerge",
        "checkedAt": "2026-09-09T20:17:54.856733+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open WinMerge using the package for your operating system.",
      "Use it for: Compare text files and directories; inspect differences before merging.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "everything",
    "name": "Everything",
    "developer": "voidtools",
    "description": "Fast NTFS filename search; indexing may require elevation or its service.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "search files"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.voidtools.com/downloads/",
    "officialDownload": "https://www.voidtools.com/downloads/",
    "documentation": "https://www.voidtools.com/downloads/",
    "localFolder": "20_PORTABLE_APPS/Misc/Everything",
    "localExecutable": "20_PORTABLE_APPS/Misc/Everything/Everything.exe",
    "inventoryPatterns": [
      "Everything.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.voidtools.com/downloads/",
        "status": 200,
        "finalUrl": "https://www.voidtools.com/downloads/",
        "title": "Downloads - voidtools",
        "checkedAt": "2026-09-09T20:17:59.070885+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.voidtools.com/downloads/",
        "status": 200,
        "finalUrl": "https://www.voidtools.com/downloads/",
        "title": "Downloads - voidtools",
        "checkedAt": "2026-09-09T20:17:59.070885+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Everything using the package for your operating system.",
      "Use it for: Fast NTFS filename search; indexing may require elevation or its service.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "wiztree",
    "name": "WizTree",
    "developer": "Antibody Software",
    "description": "Fast disk usage mapping to locate space consumers; commercial use requires a license.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "disk space Windows slow"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://diskanalyzer.com/download",
    "officialDownload": "https://diskanalyzer.com/download",
    "documentation": "https://diskanalyzer.com/download",
    "localFolder": "20_PORTABLE_APPS/Misc/WizTree",
    "localExecutable": "20_PORTABLE_APPS/Misc/WizTree/WizTree64.exe",
    "inventoryPatterns": [
      "WizTree64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://diskanalyzer.com/download",
        "status": 200,
        "finalUrl": "https://diskanalyzer.com/download",
        "title": "Download WizTree",
        "checkedAt": "2026-09-09T20:17:51.543019+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://diskanalyzer.com/download",
        "status": 200,
        "finalUrl": "https://diskanalyzer.com/download",
        "title": "Download WizTree",
        "checkedAt": "2026-09-09T20:17:51.543019+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open WizTree using the package for your operating system.",
      "Use it for: Fast disk usage mapping to locate space consumers; commercial use requires a license.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "treesize",
    "name": "TreeSize Free",
    "developer": "JAM Software",
    "description": "Alternative directory size view; check allowed use and supported features.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "disk space"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.jam-software.com/treesize_free",
    "officialDownload": "https://www.jam-software.com/treesize_free",
    "documentation": "https://www.jam-software.com/treesize_free",
    "localFolder": "20_PORTABLE_APPS/Misc/TreeSize",
    "localExecutable": "20_PORTABLE_APPS/Misc/TreeSize/TreeSizeFree.exe",
    "inventoryPatterns": [
      "TreeSizeFree.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.jam-software.com/treesize_free",
        "status": 200,
        "finalUrl": "https://www.jam-software.com/treesize",
        "title": "TreeSize – Official Free Download",
        "checkedAt": "2026-09-09T20:17:58.315469+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.jam-software.com/treesize_free",
        "status": 200,
        "finalUrl": "https://www.jam-software.com/treesize",
        "title": "TreeSize – Official Free Download",
        "checkedAt": "2026-09-09T20:17:58.315469+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open TreeSize Free using the package for your operating system.",
      "Use it for: Alternative directory size view; check allowed use and supported features.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "fastcopy",
    "name": "FastCopy",
    "developer": "FastCopy Lab",
    "description": "High-throughput copy with verification options; sync/delete modes can remove files.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "copy migration"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://fastcopy.jp/",
    "officialDownload": "https://fastcopy.jp/",
    "documentation": "https://fastcopy.jp/",
    "localFolder": "20_PORTABLE_APPS/Misc/FastCopy",
    "localExecutable": "20_PORTABLE_APPS/Misc/FastCopy/FastCopy.exe",
    "inventoryPatterns": [
      "FastCopy.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://fastcopy.jp/",
        "status": 200,
        "finalUrl": "https://fastcopy.jp/",
        "title": "FastCopy",
        "checkedAt": "2026-09-09T20:17:51.736451+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://fastcopy.jp/",
        "status": 200,
        "finalUrl": "https://fastcopy.jp/",
        "title": "FastCopy",
        "checkedAt": "2026-09-09T20:17:51.736451+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open FastCopy using the package for your operating system.",
      "Use it for: High-throughput copy with verification options; sync/delete modes can remove files.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "freefilesync",
    "name": "FreeFileSync",
    "developer": "FreeFileSync project",
    "description": "Compare and synchronize folders; preview deletion directions before syncing.",
    "categories": [
      "Portable Apps",
      "Backup & Sync"
    ],
    "tags": [
      "backup sync migration"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://freefilesync.org/download.php",
    "officialDownload": "https://freefilesync.org/download.php",
    "documentation": "https://freefilesync.org/download.php",
    "localFolder": "20_PORTABLE_APPS/Misc/FreeFileSync",
    "localExecutable": "20_PORTABLE_APPS/Misc/FreeFileSync/FreeFileSync.exe",
    "inventoryPatterns": [
      "FreeFileSync.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Standard edition is installed. Portable deployment availability depends on the selected edition; check vendor terms.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://freefilesync.org/download.php",
        "status": 200,
        "finalUrl": "https://freefilesync.org/download.php",
        "title": "Download the Latest Version - FreeFileSync",
        "checkedAt": "2026-09-09T20:17:51.617205+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://freefilesync.org/download.php",
        "status": 200,
        "finalUrl": "https://freefilesync.org/download.php",
        "title": "Download the Latest Version - FreeFileSync",
        "checkedAt": "2026-09-09T20:17:51.617205+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open FreeFileSync using the package for your operating system.",
      "Use it for: Compare and synchronize folders; preview deletion directions before syncing.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ],
    "automationSupport": {
      "level": "documented",
      "source": "https://freefilesync.org/manual.php?topic=command-line",
      "notes": "Saved batch jobs; check edition and commercial-use licensing before choosing this over free alternatives."
    }
  },
  {
    "id": "sumatra",
    "name": "SumatraPDF",
    "developer": "Krzysztof Kowalczyk",
    "description": "Compact portable PDF and ebook reader for field documentation.",
    "categories": [
      "Office & PDF",
      "Portable Apps"
    ],
    "tags": [
      "PDF"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
    "officialDownload": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
    "documentation": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
    "localFolder": "20_PORTABLE_APPS/PDF/SumatraPDF",
    "localExecutable": "",
    "inventoryPatterns": [
      "SumatraPDF*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
        "status": 200,
        "finalUrl": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
        "title": "Sumatra PDF reader download page",
        "checkedAt": "2026-09-09T20:17:58.659324+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
        "status": 200,
        "finalUrl": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
        "title": "Sumatra PDF reader download page",
        "checkedAt": "2026-09-09T20:17:58.659324+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open a copy of the document or create a new workspace.",
      "Perform the required edit and check formatting or account settings.",
      "Save a separate copy and verify it in the intended destination application."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "pdfarranger",
    "name": "PDF Arranger",
    "developer": "PDF Arranger project",
    "description": "Reorder, merge and split PDF pages locally.",
    "categories": [
      "Office & PDF"
    ],
    "tags": [
      "PDF"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://github.com/pdfarranger/pdfarranger",
    "officialDownload": "https://github.com/pdfarranger/pdfarranger/releases",
    "documentation": "https://github.com/pdfarranger/pdfarranger",
    "localFolder": "20_PORTABLE_APPS/PDF/PDF-Arranger",
    "localExecutable": "20_PORTABLE_APPS/PDF/PDF-Arranger/pdfarranger.exe",
    "inventoryPatterns": [
      "pdfarranger.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "githubRepo": "pdfarranger/pdfarranger",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/pdfarranger/pdfarranger",
        "status": 200,
        "finalUrl": "https://github.com/pdfarranger/pdfarranger",
        "title": "GitHub - pdfarranger/pdfarranger: Small python-gtk application, which helps the user to merge or split PDF documents and rotate, crop and rearrange their pages using an interactive and intuitive graphical interface. · GitHub",
        "checkedAt": "2026-09-09T20:17:52.922293+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/pdfarranger/pdfarranger/releases",
        "status": 200,
        "finalUrl": "https://github.com/pdfarranger/pdfarranger/releases",
        "title": "Releases · pdfarranger/pdfarranger · GitHub",
        "checkedAt": "2026-09-09T20:17:52.751312+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open a copy of the document or create a new workspace.",
      "Perform the required edit and check formatting or account settings.",
      "Save a separate copy and verify it in the intended destination application."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "libreoffice",
    "name": "LibreOffice Portable",
    "developer": "The Document Foundation / PortableApps.com",
    "description": "Offline document, spreadsheet and presentation suite packaged by PortableApps.com.",
    "categories": [
      "Office & PDF",
      "Portable Apps"
    ],
    "tags": [
      "office documents"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1200,
    "officialWebsite": "https://portableapps.com/apps/office/libreoffice_portable",
    "officialDownload": "https://portableapps.com/apps/office/libreoffice_portable",
    "documentation": "https://portableapps.com/apps/office/libreoffice_portable",
    "localFolder": "20_PORTABLE_APPS/Office/LibreOffice",
    "localExecutable": "20_PORTABLE_APPS/Office/LibreOffice/LibreOfficePortable.exe",
    "inventoryPatterns": [
      "LibreOfficePortable.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://portableapps.com/apps/office/libreoffice_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/office/libreoffice_portable",
        "title": "LibreOffice Portable Stable | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.405224+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://portableapps.com/apps/office/libreoffice_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/office/libreoffice_portable",
        "title": "LibreOffice Portable Stable | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.405224+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open a copy of the document or create a new workspace.",
      "Perform the required edit and check formatting or account settings.",
      "Save a separate copy and verify it in the intended destination application."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "onlyoffice",
    "name": "ONLYOFFICE Desktop Editors",
    "developer": "Ascensio System",
    "description": "Optional installed offline office suite with OOXML-focused editing.",
    "categories": [
      "Office & PDF"
    ],
    "tags": [
      "office"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 800,
    "officialWebsite": "https://www.onlyoffice.com/download-desktop.aspx",
    "officialDownload": "https://www.onlyoffice.com/download-desktop.aspx",
    "documentation": "https://www.onlyoffice.com/download-desktop.aspx",
    "localFolder": "40_INSTALLERS/Office/ONLYOFFICE",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.onlyoffice.com/download-desktop.aspx",
        "status": 200,
        "finalUrl": "https://www.onlyoffice.com/download-desktop",
        "title": "ONLYOFFICE desktop and mobile apps | ONLYOFFICE",
        "checkedAt": "2026-09-09T20:17:57.071511+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.onlyoffice.com/download-desktop.aspx",
        "status": 200,
        "finalUrl": "https://www.onlyoffice.com/download-desktop",
        "title": "ONLYOFFICE desktop and mobile apps | ONLYOFFICE",
        "checkedAt": "2026-09-09T20:17:57.071511+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open a copy of the document or create a new workspace.",
      "Perform the required edit and check formatting or account settings.",
      "Save a separate copy and verify it in the intended destination application."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "vlc",
    "name": "VLC Portable",
    "developer": "VideoLAN / PortableApps.com",
    "description": "Offline media playback in a portable package.",
    "categories": [
      "Media",
      "Portable Apps"
    ],
    "tags": [
      "video audio"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://portableapps.com/apps/music_video/vlc_portable",
    "officialDownload": "https://portableapps.com/apps/music_video/vlc_portable",
    "documentation": "https://portableapps.com/apps/music_video/vlc_portable",
    "localFolder": "20_PORTABLE_APPS/Media/VLC",
    "localExecutable": "20_PORTABLE_APPS/Media/VLC/VLCPortable.exe",
    "inventoryPatterns": [
      "VLCPortable.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://portableapps.com/apps/music_video/vlc_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/music_video/vlc_portable",
        "title": "VLC Media Player Portable | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.305933+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://portableapps.com/apps/music_video/vlc_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/music_video/vlc_portable",
        "title": "VLC Media Player Portable | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.305933+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open a copy of your source media in the application.",
      "Choose the intended edit, conversion or playback settings and test a short sample.",
      "Save/export to a new file and verify the result before replacing originals."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "mediainfo",
    "name": "MediaInfo",
    "developer": "MediaArea",
    "description": "Inspect audio/video codecs, metadata and container details.",
    "categories": [
      "Media"
    ],
    "tags": [
      "codec"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://mediaarea.net/en/MediaInfo/Download/Windows",
    "officialDownload": "https://mediaarea.net/en/MediaInfo/Download/Windows",
    "documentation": "https://mediaarea.net/en/MediaInfo/Download/Windows",
    "localFolder": "20_PORTABLE_APPS/Media/MediaInfo",
    "localExecutable": "20_PORTABLE_APPS/Media/MediaInfo/MediaInfo.exe",
    "inventoryPatterns": [
      "MediaInfo.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://mediaarea.net/en/MediaInfo/Download/Windows",
        "status": 200,
        "finalUrl": "https://mediaarea.net/en/MediaInfo/Download/Windows",
        "title": "MediaInfo - Download MediaInfo for Microsoft Windows",
        "checkedAt": "2026-09-09T20:17:53.885220+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://mediaarea.net/en/MediaInfo/Download/Windows",
        "status": 200,
        "finalUrl": "https://mediaarea.net/en/MediaInfo/Download/Windows",
        "title": "MediaInfo - Download MediaInfo for Microsoft Windows",
        "checkedAt": "2026-09-09T20:17:53.885220+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open a copy of your source media in the application.",
      "Choose the intended edit, conversion or playback settings and test a short sample.",
      "Save/export to a new file and verify the result before replacing originals."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "handbrake",
    "name": "HandBrake",
    "developer": "HandBrake team",
    "description": "Offline video transcoding; sustained encodes can heavily load the CPU/GPU.",
    "categories": [
      "Media"
    ],
    "tags": [
      "video encode"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://handbrake.fr/downloads.php",
    "officialDownload": "https://handbrake.fr/downloads.php",
    "documentation": "https://handbrake.fr/downloads.php",
    "localFolder": "40_INSTALLERS/Media/HandBrake",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://handbrake.fr/downloads.php",
        "status": 200,
        "finalUrl": "https://handbrake.fr/downloads.php",
        "title": "HandBrake: Downloads",
        "checkedAt": "2026-09-09T20:17:53.151057+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://handbrake.fr/downloads.php",
        "status": 200,
        "finalUrl": "https://handbrake.fr/downloads.php",
        "title": "HandBrake: Downloads",
        "checkedAt": "2026-09-09T20:17:53.151057+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open a copy of your source media in the application.",
      "Choose the intended edit, conversion or playback settings and test a short sample.",
      "Save/export to a new file and verify the result before replacing originals."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "audacity",
    "name": "Audacity",
    "developer": "Audacity team",
    "description": "Offline audio recording and editing for device checks and simple repairs.",
    "categories": [
      "Media"
    ],
    "tags": [
      "audio"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://www.audacityteam.org/download/windows/",
    "officialDownload": "https://www.audacityteam.org/download/windows/",
    "documentation": "https://www.audacityteam.org/download/windows/",
    "localFolder": "20_PORTABLE_APPS/Media/Audacity",
    "localExecutable": "20_PORTABLE_APPS/Media/Audacity/Audacity.exe",
    "inventoryPatterns": [
      "Audacity.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.audacityteam.org/download/windows/",
        "status": 200,
        "finalUrl": "https://www.audacityteam.org/download/windows/",
        "title": "Audacity ® | Download for Windows",
        "checkedAt": "2026-09-09T20:17:54.948400+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.audacityteam.org/download/windows/",
        "status": 200,
        "finalUrl": "https://www.audacityteam.org/download/windows/",
        "title": "Audacity ® | Download for Windows",
        "checkedAt": "2026-09-09T20:17:54.948400+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open a copy of your source media in the application.",
      "Choose the intended edit, conversion or playback settings and test a short sample.",
      "Save/export to a new file and verify the result before replacing originals."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "irfanview",
    "name": "IrfanView",
    "developer": "Irfan Skiljan",
    "description": "Fast image viewer; commercial use requires registration.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "graphics images"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://www.irfanview.com/",
    "officialDownload": "https://www.irfanview.com/",
    "documentation": "https://www.irfanview.com/",
    "localFolder": "20_PORTABLE_APPS/Graphics/IrfanView",
    "localExecutable": "20_PORTABLE_APPS/Graphics/IrfanView/i_view64.exe",
    "inventoryPatterns": [
      "i_view64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.irfanview.com/",
        "status": 200,
        "finalUrl": "https://www.irfanview.com/",
        "title": "IrfanView - Official Homepage - One of the Most Popular Viewers Worldwide",
        "checkedAt": "2026-09-09T20:17:56.239772+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.irfanview.com/",
        "status": 200,
        "finalUrl": "https://www.irfanview.com/",
        "title": "IrfanView - Official Homepage - One of the Most Popular Viewers Worldwide",
        "checkedAt": "2026-09-09T20:17:56.239772+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open IrfanView using the package for your operating system.",
      "Use it for: Fast image viewer; commercial use requires registration.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "gimp",
    "name": "GIMP",
    "developer": "GIMP project",
    "description": "Offline image editing for screenshots and service documentation.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "graphics"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 500,
    "officialWebsite": "https://www.gimp.org/downloads/",
    "officialDownload": "https://www.gimp.org/downloads/",
    "documentation": "https://www.gimp.org/downloads/",
    "localFolder": "40_INSTALLERS/Utilities/GIMP",
    "localExecutable": "",
    "inventoryPatterns": [
      "gimp*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.gimp.org/downloads/",
        "status": 200,
        "finalUrl": "https://www.gimp.org/downloads/",
        "title": "GIMP - Downloads",
        "checkedAt": "2026-09-09T20:17:55.363412+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.gimp.org/downloads/",
        "status": 200,
        "finalUrl": "https://www.gimp.org/downloads/",
        "title": "GIMP - Downloads",
        "checkedAt": "2026-09-09T20:17:55.363412+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open GIMP using the package for your operating system.",
      "Use it for: Offline image editing for screenshots and service documentation.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "powershell",
    "name": "PowerShell 7",
    "developer": "Microsoft",
    "description": "Current cross-platform shell; ZIP edition can be staged without installation.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "scripts shell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://github.com/PowerShell/PowerShell",
    "officialDownload": "https://github.com/PowerShell/PowerShell/releases",
    "documentation": "https://github.com/PowerShell/PowerShell",
    "localFolder": "20_PORTABLE_APPS/Misc/PowerShell",
    "localExecutable": "20_PORTABLE_APPS/Misc/PowerShell/pwsh.exe",
    "inventoryPatterns": [
      "pwsh.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "githubRepo": "PowerShell/PowerShell",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/PowerShell/PowerShell",
        "status": 200,
        "finalUrl": "https://github.com/PowerShell/PowerShell",
        "title": "GitHub - PowerShell/PowerShell: PowerShell for every system! · GitHub",
        "checkedAt": "2026-09-09T20:17:52.298158+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/PowerShell/PowerShell/releases",
        "status": 200,
        "finalUrl": "https://github.com/PowerShell/PowerShell/releases",
        "title": "Releases · PowerShell/PowerShell · GitHub",
        "checkedAt": "2026-09-09T20:17:52.579368+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open PowerShell 7 using the package for your operating system.",
      "Use it for: Current cross-platform shell; ZIP edition can be staged without installation.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "git",
    "name": "Git Portable",
    "developer": "Git for Windows",
    "description": "Portable Git and shell tools for configuration history and source work.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "version control"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 350,
    "officialWebsite": "https://git-scm.com/downloads/win",
    "officialDownload": "https://git-scm.com/downloads/win",
    "documentation": "https://git-scm.com/downloads/win",
    "localFolder": "20_PORTABLE_APPS/Misc/Git",
    "localExecutable": "20_PORTABLE_APPS/Misc/Git/git.exe",
    "inventoryPatterns": [
      "git.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://git-scm.com/downloads/win",
        "status": 200,
        "finalUrl": "https://git-scm.com/downloads/win",
        "title": "Redirecting…",
        "checkedAt": "2026-09-09T20:17:51.413700+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://git-scm.com/downloads/win",
        "status": 200,
        "finalUrl": "https://git-scm.com/downloads/win",
        "title": "Redirecting…",
        "checkedAt": "2026-09-09T20:17:51.413700+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Git Portable using the package for your operating system.",
      "Use it for: Portable Git and shell tools for configuration history and source work.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "python",
    "name": "Python embeddable package",
    "developer": "Python Software Foundation",
    "description": "Minimal Windows embedded runtime; not a normal pip-enabled development installation.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "runtime"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.python.org/downloads/windows/",
    "officialDownload": "https://www.python.org/downloads/windows/",
    "documentation": "https://www.python.org/downloads/windows/",
    "localFolder": "20_PORTABLE_APPS/Misc/Python",
    "localExecutable": "20_PORTABLE_APPS/Misc/Python/python.exe",
    "inventoryPatterns": [
      "python.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.python.org/downloads/windows/",
        "status": 200,
        "finalUrl": "https://www.python.org/downloads/windows/",
        "title": "",
        "checkedAt": "2026-09-09T20:17:57.550894+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.python.org/downloads/windows/",
        "status": 200,
        "finalUrl": "https://www.python.org/downloads/windows/",
        "title": "",
        "checkedAt": "2026-09-09T20:17:57.550894+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Python embeddable package using the package for your operating system.",
      "Use it for: Minimal Windows embedded runtime; not a normal pip-enabled development installation.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "curl",
    "name": "curl",
    "developer": "curl project",
    "description": "Transfer URLs and inspect HTTP/TLS; avoid placing secrets in command histories.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "HTTP wget download"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://curl.se/windows/",
    "officialDownload": "https://curl.se/windows/",
    "documentation": "https://curl.se/windows/",
    "localFolder": "20_PORTABLE_APPS/Misc/curl",
    "localExecutable": "20_PORTABLE_APPS/Misc/curl/curl.exe",
    "inventoryPatterns": [
      "curl.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://curl.se/windows/",
        "status": 200,
        "finalUrl": "https://curl.se/windows/",
        "title": "curl for Windows",
        "checkedAt": "2026-09-09T20:17:51.314966+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://curl.se/windows/",
        "status": 200,
        "finalUrl": "https://curl.se/windows/",
        "title": "curl for Windows",
        "checkedAt": "2026-09-09T20:17:51.314966+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open curl using the package for your operating system.",
      "Use it for: Transfer URLs and inspect HTTP/TLS; avoid placing secrets in command histories.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "jq",
    "name": "jq",
    "developer": "jqlang project",
    "description": "Command-line JSON inspection and transformation.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "JSON"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://jqlang.org/download/",
    "officialDownload": "https://jqlang.org/download/",
    "documentation": "https://jqlang.org/download/",
    "localFolder": "20_PORTABLE_APPS/Misc/jq",
    "localExecutable": "",
    "inventoryPatterns": [
      "jq*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://jqlang.org/download/",
        "status": 200,
        "finalUrl": "https://jqlang.org/download/",
        "title": "Download jq",
        "checkedAt": "2026-09-09T20:17:52.685670+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://jqlang.org/download/",
        "status": 200,
        "finalUrl": "https://jqlang.org/download/",
        "title": "Download jq",
        "checkedAt": "2026-09-09T20:17:52.685670+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open jq using the package for your operating system.",
      "Use it for: Command-line JSON inspection and transformation.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "sqlite",
    "name": "SQLite tools",
    "developer": "SQLite project",
    "description": "Inspect local SQLite databases; work on a copy of application databases.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "database"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://sqlite.org/download.html",
    "officialDownload": "https://sqlite.org/download.html",
    "documentation": "https://sqlite.org/download.html",
    "localFolder": "20_PORTABLE_APPS/Misc/SQLite",
    "localExecutable": "20_PORTABLE_APPS/Misc/SQLite/sqlite3.exe",
    "inventoryPatterns": [
      "sqlite3.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://sqlite.org/download.html",
        "status": 200,
        "finalUrl": "https://sqlite.org/download.html",
        "title": "SQLite Download Page",
        "checkedAt": "2026-09-09T20:17:54.462399+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://sqlite.org/download.html",
        "status": 200,
        "finalUrl": "https://sqlite.org/download.html",
        "title": "SQLite Download Page",
        "checkedAt": "2026-09-09T20:17:54.462399+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open SQLite tools using the package for your operating system.",
      "Use it for: Inspect local SQLite databases; work on a copy of application databases.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "ventoy",
    "name": "Ventoy installer",
    "developer": "Ventoy project",
    "description": "Prepare or update multiboot media. Initial installation repartitions the selected drive.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "boot ISO USB"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 35,
    "officialWebsite": "https://www.ventoy.net/en/download.html",
    "officialDownload": "https://www.ventoy.net/en/download.html",
    "documentation": "https://www.ventoy.net/en/download.html",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/Ventoy",
    "localExecutable": "10_WINDOWS_TOOLBOX/13_USB/Ventoy/Ventoy2Disk.exe",
    "inventoryPatterns": [
      "Ventoy2Disk.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ventoy.net/en/download.html",
        "status": 200,
        "finalUrl": "https://www.ventoy.net/en/download.html",
        "title": "Download . Ventoy",
        "checkedAt": "2026-09-09T20:17:59.597408+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.ventoy.net/en/download.html",
        "status": 200,
        "finalUrl": "https://www.ventoy.net/en/download.html",
        "title": "Download . Ventoy",
        "checkedAt": "2026-09-09T20:17:59.597408+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Ventoy installer using the package for your operating system.",
      "Use it for: Prepare or update multiboot media. Initial installation repartitions the selected drive.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "usbtree",
    "name": "USB Device Tree Viewer",
    "developer": "Uwe Sieber",
    "description": "Inspect USB topology, negotiated speed and device descriptors.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "USB speed adapter"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://www.uwe-sieber.de/usbtreeview_e.html",
    "officialDownload": "https://www.uwe-sieber.de/usbtreeview_e.html",
    "documentation": "https://www.uwe-sieber.de/usbtreeview_e.html",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/USBTreeView",
    "localExecutable": "10_WINDOWS_TOOLBOX/13_USB/USBTreeView/UsbTreeView.exe",
    "inventoryPatterns": [
      "UsbTreeView.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.uwe-sieber.de/usbtreeview_e.html",
        "status": 200,
        "finalUrl": "https://www.uwe-sieber.de/usbtreeview_e.html",
        "title": "USB Device Tree Viewer",
        "checkedAt": "2026-09-09T20:17:59.267967+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.uwe-sieber.de/usbtreeview_e.html",
        "status": 200,
        "finalUrl": "https://www.uwe-sieber.de/usbtreeview_e.html",
        "title": "USB Device Tree Viewer",
        "checkedAt": "2026-09-09T20:17:59.267967+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open USB Device Tree Viewer using the package for your operating system.",
      "Use it for: Inspect USB topology, negotiated speed and device descriptors.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "usbdeview",
    "name": "USBDeview",
    "developer": "NirSoft",
    "description": "Inspect USB device history; disabling or removing devices changes configuration.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "USB history"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 2,
    "officialWebsite": "https://www.nirsoft.net/utils/usb_devices_view.html",
    "officialDownload": "https://www.nirsoft.net/utils/usb_devices_view.html",
    "documentation": "https://www.nirsoft.net/utils/usb_devices_view.html",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/USBDeview",
    "localExecutable": "10_WINDOWS_TOOLBOX/13_USB/USBDeview/USBDeview.exe",
    "inventoryPatterns": [
      "USBDeview.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.nirsoft.net/utils/usb_devices_view.html",
        "status": 200,
        "finalUrl": "https://www.nirsoft.net/utils/usb_devices_view.html",
        "title": "View any installed/connected USB device on your system",
        "checkedAt": "2026-09-09T20:17:57.376581+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.nirsoft.net/utils/usb_devices_view.html",
        "status": 200,
        "finalUrl": "https://www.nirsoft.net/utils/usb_devices_view.html",
        "title": "View any installed/connected USB device on your system",
        "checkedAt": "2026-09-09T20:17:57.376581+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open USBDeview using the package for your operating system.",
      "Use it for: Inspect USB device history; disabling or removing devices changes configuration.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "mct",
    "name": "Windows Media Creation Tool",
    "developer": "Microsoft",
    "description": "Download and create Windows installation media; requires internet.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "Windows install"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://www.microsoft.com/en-us/software-download/windows11",
    "officialDownload": "https://www.microsoft.com/en-us/software-download/windows11",
    "documentation": "https://www.microsoft.com/en-us/software-download/windows11",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/MediaCreation",
    "localExecutable": "",
    "inventoryPatterns": [
      "MediaCreationTool*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.microsoft.com/en-us/software-download/windows11",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/software-download/windows11",
        "title": "Download Windows 11",
        "checkedAt": "2026-09-09T20:17:57.239917+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.microsoft.com/en-us/software-download/windows11",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/software-download/windows11",
        "title": "Download Windows 11",
        "checkedAt": "2026-09-09T20:17:57.239917+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Windows Media Creation Tool using the package for your operating system.",
      "Use it for: Download and create Windows installation media; requires internet.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "etcher",
    "name": "balenaEtcher",
    "developer": "balena",
    "description": "Optional image-to-USB writer; overwrites the selected destination.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "USB image"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://etcher.balena.io/",
    "officialDownload": "https://etcher.balena.io/",
    "documentation": "https://etcher.balena.io/",
    "localFolder": "40_INSTALLERS/Utilities/Etcher",
    "localExecutable": "",
    "inventoryPatterns": [
      "balenaEtcher*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://etcher.balena.io/",
        "status": 200,
        "finalUrl": "https://etcher.balena.io/",
        "title": "balenaEtcher - Flash OS images to SD cards & USB drives",
        "checkedAt": "2026-09-09T20:17:51.464317+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://etcher.balena.io/",
        "status": 200,
        "finalUrl": "https://etcher.balena.io/",
        "title": "balenaEtcher - Flash OS images to SD cards & USB drives",
        "checkedAt": "2026-09-09T20:17:51.464317+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open balenaEtcher using the package for your operating system.",
      "Use it for: Optional image-to-USB writer; overwrites the selected destination.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "unigetui",
    "name": "UniGetUI",
    "developer": "Marti Climent / Devolutions",
    "description": "Graphical frontend for package managers; package actions generally need internet.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget chocolatey scoop software"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://github.com/Devolutions/UniGetUI",
    "officialDownload": "https://github.com/Devolutions/UniGetUI/releases",
    "documentation": "https://github.com/Devolutions/UniGetUI",
    "localFolder": "10_WINDOWS_TOOLBOX/09_Package-Managers/UniGetUI",
    "localExecutable": "",
    "inventoryPatterns": [
      "UniGetUI*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Project ownership now resolves to Devolutions/UniGetUI.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "githubRepo": "Devolutions/UniGetUI",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/Devolutions/UniGetUI",
        "status": 200,
        "finalUrl": "https://github.com/Devolutions/UniGetUI",
        "title": "GitHub - Devolutions/UniGetUI: UniGetUI: The Graphical Interface for your package managers. Could be terribly described as a package manager manager to manage your package managers · GitHub",
        "checkedAt": "2026-09-09T20:17:52.380847+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/Devolutions/UniGetUI/releases",
        "status": 200,
        "finalUrl": "https://github.com/Devolutions/UniGetUI/releases",
        "title": "Releases · Devolutions/UniGetUI · GitHub",
        "checkedAt": "2026-09-09T20:17:52.490186+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open UniGetUI using the package for your operating system.",
      "Use it for: Graphical frontend for package managers; package actions generally need internet.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "chocolatey",
    "name": "Chocolatey",
    "developer": "Chocolatey Software",
    "description": "Windows package manager; audit package sources and scripts before installing.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "packages"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://chocolatey.org/install",
    "officialDownload": "https://chocolatey.org/install",
    "documentation": "https://chocolatey.org/install",
    "localFolder": "10_WINDOWS_TOOLBOX/09_Package-Managers/Chocolatey",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Online",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://chocolatey.org/install",
        "status": 200,
        "finalUrl": "https://chocolatey.org/install",
        "title": "Chocolatey Software | Installing Chocolatey",
        "checkedAt": "2026-09-09T20:17:51.290904+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://chocolatey.org/install",
        "status": 200,
        "finalUrl": "https://chocolatey.org/install",
        "title": "Chocolatey Software | Installing Chocolatey",
        "checkedAt": "2026-09-09T20:17:51.290904+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Chocolatey using the package for your operating system.",
      "Use it for: Windows package manager; audit package sources and scripts before installing.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "scoop",
    "name": "Scoop",
    "developer": "ScoopInstaller project",
    "description": "User-level package manager; inspect buckets and manifests.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "packages"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://scoop.sh/",
    "officialDownload": "https://scoop.sh/",
    "documentation": "https://scoop.sh/",
    "localFolder": "10_WINDOWS_TOOLBOX/09_Package-Managers/Scoop",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Online",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://scoop.sh/",
        "status": 200,
        "finalUrl": "https://scoop.sh/",
        "title": "",
        "checkedAt": "2026-09-09T20:17:54.126937+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://scoop.sh/",
        "status": 200,
        "finalUrl": "https://scoop.sh/",
        "title": "",
        "checkedAt": "2026-09-09T20:17:54.126937+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Scoop using the package for your operating system.",
      "Use it for: User-level package manager; inspect buckets and manifests.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "proxmox",
    "name": "Proxmox VE ISO",
    "developer": "Proxmox",
    "description": "Homelab hypervisor installer and rescue entry points; installer overwrites target storage.",
    "categories": [
      "Homelab / Linux",
      "Boot & Recovery"
    ],
    "tags": [
      "server virtualization"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1600,
    "officialWebsite": "https://www.proxmox.com/en/downloads",
    "officialDownload": "https://www.proxmox.com/en/downloads",
    "documentation": "https://www.proxmox.com/en/downloads",
    "localFolder": "00_BOOT/Linux-Rescue/Proxmox",
    "localExecutable": "",
    "inventoryPatterns": [
      "proxmox-ve*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.proxmox.com/en/downloads",
        "status": 200,
        "finalUrl": "https://www.proxmox.com/en/downloads",
        "title": "Download Proxmox software, datasheets, agreements",
        "checkedAt": "2026-09-09T20:17:58.243917+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.proxmox.com/en/downloads",
        "status": 200,
        "finalUrl": "https://www.proxmox.com/en/downloads",
        "title": "Download Proxmox software, datasheets, agreements",
        "checkedAt": "2026-09-09T20:17:58.243917+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "debian",
    "name": "Debian Live",
    "developer": "Debian project",
    "description": "General-purpose Linux rescue and compatibility environment.",
    "categories": [
      "Homelab / Linux",
      "Boot & Recovery"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 3500,
    "officialWebsite": "https://www.debian.org/CD/live/",
    "officialDownload": "https://www.debian.org/CD/live/",
    "documentation": "https://www.debian.org/CD/live/",
    "localFolder": "00_BOOT/Linux-Rescue/Debian",
    "localExecutable": "",
    "inventoryPatterns": [
      "debian-live*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.debian.org/CD/live/",
        "status": 200,
        "finalUrl": "https://www.debian.org/CD/live/",
        "title": "Debian -- Live install images",
        "checkedAt": "2026-09-09T20:17:55.169491+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.debian.org/CD/live/",
        "status": 200,
        "finalUrl": "https://www.debian.org/CD/live/",
        "title": "Debian -- Live install images",
        "checkedAt": "2026-09-09T20:17:55.169491+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Select the rescue ISO that matches your hardware and task.",
      "Place the ISO in its toolkit boot folder and boot it through your chosen multiboot setup.",
      "Confirm the running environment and target disk before any repair."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "vcredist",
    "name": "Microsoft Visual C++ Redistributables",
    "developer": "Microsoft",
    "description": "Stage supported x64 and x86 packages for games and desktop applications.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "runtime DLL"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
    "officialDownload": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
    "documentation": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
    "localFolder": "40_INSTALLERS/Runtimes/Visual-Cpp",
    "localExecutable": "",
    "inventoryPatterns": [
      "vc_redist*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170",
        "title": "Latest Supported Visual C++ Redistributable Downloads | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.985979+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170",
        "title": "Latest Supported Visual C++ Redistributable Downloads | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.985979+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Microsoft Visual C++ Redistributables using the package for your operating system.",
      "Use it for: Stage supported x64 and x86 packages for games and desktop applications.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "dotnet",
    "name": ".NET Desktop Runtime",
    "developer": "Microsoft",
    "description": "Install the runtime major version and architecture required by the application.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "runtime"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://dotnet.microsoft.com/en-us/download/dotnet",
    "officialDownload": "https://dotnet.microsoft.com/en-us/download/dotnet",
    "documentation": "https://dotnet.microsoft.com/en-us/download/dotnet",
    "localFolder": "40_INSTALLERS/Runtimes/DotNet",
    "localExecutable": "",
    "inventoryPatterns": [
      "windowsdesktop-runtime*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://dotnet.microsoft.com/en-us/download/dotnet",
        "status": 200,
        "finalUrl": "https://dotnet.microsoft.com/en-us/download/dotnet",
        "title": "Browse all .NET versions to download | .NET",
        "checkedAt": "2026-09-09T20:17:51.241788+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://dotnet.microsoft.com/en-us/download/dotnet",
        "status": 200,
        "finalUrl": "https://dotnet.microsoft.com/en-us/download/dotnet",
        "title": "Browse all .NET versions to download | .NET",
        "checkedAt": "2026-09-09T20:17:51.241788+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open .NET Desktop Runtime using the package for your operating system.",
      "Use it for: Install the runtime major version and architecture required by the application.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "directx",
    "name": "DirectX End-User Runtimes",
    "developer": "Microsoft",
    "description": "Legacy side-by-side D3DX/XAudio libraries for older games; not a replacement for modern DirectX.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "legacy runtime"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
    "officialDownload": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
    "documentation": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
    "localFolder": "40_INSTALLERS/Runtimes/DirectX",
    "localExecutable": "",
    "inventoryPatterns": [
      "directx*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
        "title": "Download DirectX End-User Runtimes (June 2010) from Official Microsoft Download Center",
        "checkedAt": "2026-09-09T20:18:06.625398+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
        "title": "Download DirectX End-User Runtimes (June 2010) from Official Microsoft Download Center",
        "checkedAt": "2026-09-09T20:18:06.625398+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open DirectX End-User Runtimes using the package for your operating system.",
      "Use it for: Legacy side-by-side D3DX/XAudio libraries for older games; not a replacement for modern DirectX.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "steam",
    "name": "Steam",
    "developer": "Valve",
    "description": "Optional gaming client; account login and game downloads require internet.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "launcher"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://store.steampowered.com/about/",
    "officialDownload": "https://store.steampowered.com/about/",
    "documentation": "https://store.steampowered.com/about/",
    "localFolder": "40_INSTALLERS/Gaming/Steam",
    "localExecutable": "40_INSTALLERS/Gaming/Steam/SteamSetup.exe",
    "inventoryPatterns": [
      "SteamSetup.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://store.steampowered.com/about/",
        "status": 200,
        "finalUrl": "https://store.steampowered.com/about/",
        "title": "Steam, The Ultimate Online Game Platform",
        "checkedAt": "2026-09-09T20:17:54.372627+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://store.steampowered.com/about/",
        "status": 200,
        "finalUrl": "https://store.steampowered.com/about/",
        "title": "Steam, The Ultimate Online Game Platform",
        "checkedAt": "2026-09-09T20:17:54.372627+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Open Steam using the package for your operating system.",
      "Use it for: Optional gaming client; account login and game downloads require internet.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "epic",
    "name": "Epic Games Launcher",
    "developer": "Epic Games",
    "description": "Optional gaming installer; do not retain customer credentials.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "launcher"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 180,
    "officialWebsite": "https://store.epicgames.com/en-US/download",
    "officialDownload": "https://store.epicgames.com/en-US/download",
    "documentation": "https://store.epicgames.com/en-US/download",
    "localFolder": "40_INSTALLERS/Gaming/Epic",
    "localExecutable": "",
    "inventoryPatterns": [
      "EpicInstaller*.msi"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://store.epicgames.com/en-US/download",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.065202+00:00"
      },
      "download": {
        "url": "https://store.epicgames.com/en-US/download",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.065202+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Open Epic Games Launcher using the package for your operating system.",
      "Use it for: Optional gaming installer; do not retain customer credentials.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "battlenet",
    "name": "Battle.net",
    "developer": "Blizzard",
    "description": "Optional gaming client with internet and account requirements.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "launcher"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://download.battle.net/",
    "officialDownload": "https://download.battle.net/",
    "documentation": "https://download.battle.net/",
    "localFolder": "40_INSTALLERS/Gaming/BattleNet",
    "localExecutable": "",
    "inventoryPatterns": [
      "Battle.net*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://download.battle.net/",
        "status": 200,
        "finalUrl": "https://download.battle.net/en-us/",
        "title": "Download Battle.net | Battle.net",
        "checkedAt": "2026-09-09T20:17:52.421533+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://download.battle.net/",
        "status": 200,
        "finalUrl": "https://download.battle.net/en-us/",
        "title": "Download Battle.net | Battle.net",
        "checkedAt": "2026-09-09T20:17:52.421533+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Open Battle.net using the package for your operating system.",
      "Use it for: Optional gaming client with internet and account requirements.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "intel-network",
    "name": "Intel Ethernet / Wi-Fi / Bluetooth",
    "developer": "Intel",
    "description": "Stage Ethernet, Wi-Fi and Bluetooth packages matched to hardware IDs.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "officialDownload": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "documentation": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "localFolder": "30_DRIVERS/Intel/Network",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      },
      "download": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "intel-chipset",
    "name": "Intel Chipset Device Software",
    "developer": "Intel",
    "description": "Chipset identification packages; prefer the PC vendor for OEM platforms.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "officialDownload": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "documentation": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "localFolder": "30_DRIVERS/Intel/Chipset",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      },
      "download": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "intel-gpu",
    "name": "Intel Graphics / Arc drivers",
    "developer": "Intel",
    "description": "Graphics driver packages matched to GPU generation and OS.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "officialDownload": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "documentation": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "localFolder": "30_DRIVERS/Intel/Graphics",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      },
      "download": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "amd-chipset",
    "name": "AMD chipset drivers",
    "developer": "AMD",
    "description": "Platform chipset support; distinguish desktop and mobile OEM systems.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.amd.com/en/support/download/drivers.html",
    "officialDownload": "https://www.amd.com/en/support/download/drivers.html",
    "documentation": "https://www.amd.com/en/support/download/drivers.html",
    "localFolder": "30_DRIVERS/AMD/Chipset",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "amd-gpu",
    "name": "AMD Software: Adrenalin Edition",
    "developer": "AMD",
    "description": "Radeon GPU driver library; select the correct supported GPU.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.amd.com/en/support/download/drivers.html",
    "officialDownload": "https://www.amd.com/en/support/download/drivers.html",
    "documentation": "https://www.amd.com/en/support/download/drivers.html",
    "localFolder": "30_DRIVERS/AMD/Graphics",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "nvidia",
    "name": "NVIDIA graphics drivers",
    "developer": "NVIDIA",
    "description": "Game Ready or Studio driver matched to GPU and OS.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.nvidia.com/en-us/drivers/",
    "officialDownload": "https://www.nvidia.com/en-us/drivers/",
    "documentation": "https://www.nvidia.com/en-us/drivers/",
    "localFolder": "30_DRIVERS/NVIDIA",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.nvidia.com/en-us/drivers/",
        "status": 200,
        "finalUrl": "https://www.nvidia.com/en-us/drivers/",
        "title": "Download The Official NVIDIA Drivers | NVIDIA",
        "checkedAt": "2026-09-09T20:17:56.868563+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.nvidia.com/en-us/drivers/",
        "status": 200,
        "finalUrl": "https://www.nvidia.com/en-us/drivers/",
        "title": "Download The Official NVIDIA Drivers | NVIDIA",
        "checkedAt": "2026-09-09T20:17:56.868563+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "realtek",
    "name": "Realtek network / audio drivers",
    "developer": "Realtek",
    "description": "Prefer OEM audio customizations; stage matching Ethernet and Wi-Fi packages.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.realtek.com/Download/List",
    "officialDownload": "https://www.realtek.com/Download/List",
    "documentation": "https://www.realtek.com/Download/List",
    "localFolder": "30_DRIVERS/Realtek",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.realtek.com/Download/List",
        "status": 200,
        "finalUrl": "https://www.realtek.com/Download/List",
        "title": "Realtek",
        "checkedAt": "2026-09-09T20:17:58.334569+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.realtek.com/Download/List",
        "status": 200,
        "finalUrl": "https://www.realtek.com/Download/List",
        "title": "Realtek",
        "checkedAt": "2026-09-09T20:17:58.334569+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "hpia",
    "name": "HP Image Assistant",
    "developer": "HP",
    "description": "Commercial HP platform driver analysis; stage supported SoftPaqs for offline work.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
    "officialDownload": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
    "documentation": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
    "localFolder": "30_DRIVERS/HP",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
        "status": 200,
        "finalUrl": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
        "title": "HP Image Assistant | HP Client Management Solutions",
        "checkedAt": "2026-09-09T20:17:51.363576+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
        "status": 200,
        "finalUrl": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
        "title": "HP Image Assistant | HP Client Management Solutions",
        "checkedAt": "2026-09-09T20:17:51.363576+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "dell",
    "name": "Dell Command Update",
    "developer": "Dell",
    "description": "Installed Dell commercial platform updater; requires supported model and source access.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
    "officialDownload": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
    "documentation": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
    "localFolder": "30_DRIVERS/Dell",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
        "status": 200,
        "finalUrl": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
        "title": "Dell Command | Update | Dell US",
        "checkedAt": "2026-09-09T20:17:55.569855+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
        "status": 200,
        "finalUrl": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
        "title": "Dell Command | Update | Dell US",
        "checkedAt": "2026-09-09T20:17:55.569855+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "lenovo",
    "name": "Lenovo System Update",
    "developer": "Lenovo",
    "description": "Supported Lenovo model driver updates; store downloaded model packages.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://support.lenovo.com/us/en/solutions/ht003029",
    "officialDownload": "https://support.lenovo.com/us/en/solutions/ht003029",
    "documentation": "https://support.lenovo.com/us/en/solutions/ht003029",
    "localFolder": "30_DRIVERS/Lenovo",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://support.lenovo.com/us/en/solutions/ht003029",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.269819+00:00"
      },
      "download": {
        "url": "https://support.lenovo.com/us/en/solutions/ht003029",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.269819+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "surface",
    "name": "Microsoft Surface driver / firmware packs",
    "developer": "Microsoft",
    "description": "MSI bundles must match the Surface model and supported Windows build.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
    "officialDownload": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
    "documentation": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
    "localFolder": "30_DRIVERS/Microsoft-Surface",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
        "title": "Manage & deploy Surface driver & firmware updates - Surface | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.716237+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
        "title": "Manage & deploy Surface driver & firmware updates - Surface | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.716237+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Identify the exact hardware model and current driver version.",
      "Select the matching OS/architecture package and create a recovery option.",
      "Install the approved driver, reboot if required, and retest the device."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-hp",
    "name": "HP firmware / BIOS support",
    "developer": "HP",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "HP BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://support.hp.com/us-en/drivers",
    "officialDownload": "https://support.hp.com/us-en/drivers",
    "documentation": "https://support.hp.com/us-en/drivers",
    "localFolder": "50_FIRMWARE/HP",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://support.hp.com/us-en/drivers",
        "status": 200,
        "finalUrl": "https://support.hp.com/us-en/drivers",
        "title": "",
        "checkedAt": "2026-09-09T20:17:54.407221+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://support.hp.com/us-en/drivers",
        "status": 200,
        "finalUrl": "https://support.hp.com/us-en/drivers",
        "title": "",
        "checkedAt": "2026-09-09T20:17:54.407221+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-dell",
    "name": "Dell firmware / BIOS support",
    "developer": "Dell",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Dell BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.dell.com/support/home/en-us?app=drivers",
    "officialDownload": "https://www.dell.com/support/home/en-us?app=drivers",
    "documentation": "https://www.dell.com/support/home/en-us?app=drivers",
    "localFolder": "50_FIRMWARE/Dell",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.dell.com/support/home/en-us?app=drivers",
        "status": 200,
        "finalUrl": "https://www.dell.com/support/home/en-us?app=drivers",
        "title": "Drivers & Downloads | Dell US",
        "checkedAt": "2026-09-09T20:17:55.452614+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.dell.com/support/home/en-us?app=drivers",
        "status": 200,
        "finalUrl": "https://www.dell.com/support/home/en-us?app=drivers",
        "title": "Drivers & Downloads | Dell US",
        "checkedAt": "2026-09-09T20:17:55.452614+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-lenovo",
    "name": "Lenovo firmware / BIOS support",
    "developer": "Lenovo",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Lenovo BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://support.lenovo.com/",
    "officialDownload": "https://support.lenovo.com/",
    "documentation": "https://support.lenovo.com/",
    "localFolder": "50_FIRMWARE/Lenovo",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://support.lenovo.com/",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.303938+00:00"
      },
      "download": {
        "url": "https://support.lenovo.com/",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.303938+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-asus",
    "name": "ASUS firmware / BIOS support",
    "developer": "ASUS",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "ASUS BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.asus.com/support/download-center/",
    "officialDownload": "https://www.asus.com/support/download-center/",
    "documentation": "https://www.asus.com/support/download-center/",
    "localFolder": "50_FIRMWARE/BIOS/ASUS",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.asus.com/support/download-center/",
        "status": 200,
        "finalUrl": "https://www.asus.com/support/download-center/",
        "title": "Download Center | Official Support | ASUS Global",
        "checkedAt": "2026-09-09T20:17:54.835696+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.asus.com/support/download-center/",
        "status": 200,
        "finalUrl": "https://www.asus.com/support/download-center/",
        "title": "Download Center | Official Support | ASUS Global",
        "checkedAt": "2026-09-09T20:17:54.835696+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-acer",
    "name": "Acer firmware / BIOS support",
    "developer": "Acer",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Acer BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.acer.com/us-en/support/drivers-and-manuals",
    "officialDownload": "https://www.acer.com/us-en/support/drivers-and-manuals",
    "documentation": "https://www.acer.com/us-en/support/drivers-and-manuals",
    "localFolder": "50_FIRMWARE/BIOS/Acer",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.acer.com/us-en/support/drivers-and-manuals",
        "status": "unconfirmed",
        "error": "The read operation timed out",
        "checkedAt": "2026-09-09T20:18:19.720693+00:00"
      },
      "download": {
        "url": "https://www.acer.com/us-en/support/drivers-and-manuals",
        "status": "unconfirmed",
        "error": "The read operation timed out",
        "checkedAt": "2026-09-09T20:18:19.720693+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-msi",
    "name": "MSI firmware / BIOS support",
    "developer": "MSI",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "MSI BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.msi.com/support/download",
    "officialDownload": "https://www.msi.com/support/download",
    "documentation": "https://www.msi.com/support/download",
    "localFolder": "50_FIRMWARE/BIOS/MSI",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.msi.com/support/download",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:56.489148+00:00"
      },
      "download": {
        "url": "https://www.msi.com/support/download",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:56.489148+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-gigabyte",
    "name": "Gigabyte firmware / BIOS support",
    "developer": "Gigabyte",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Gigabyte BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.gigabyte.com/Support",
    "officialDownload": "https://www.gigabyte.com/Support",
    "documentation": "https://www.gigabyte.com/Support",
    "localFolder": "50_FIRMWARE/BIOS/Gigabyte",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.gigabyte.com/Support",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:55.362405+00:00"
      },
      "download": {
        "url": "https://www.gigabyte.com/Support",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:55.362405+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-intel",
    "name": "Intel firmware / BIOS support",
    "developer": "Intel",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Intel BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "officialDownload": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "documentation": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "localFolder": "50_FIRMWARE/Intel",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      },
      "download": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked.",
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-amd",
    "name": "AMD firmware / BIOS support",
    "developer": "AMD",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "AMD BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.amd.com/en/support/download/drivers.html",
    "officialDownload": "https://www.amd.com/en/support/download/drivers.html",
    "documentation": "https://www.amd.com/en/support/download/drivers.html",
    "localFolder": "50_FIRMWARE/AMD",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "firmware-nvidia",
    "name": "NVIDIA firmware / BIOS support",
    "developer": "NVIDIA",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "NVIDIA BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.nvidia.com/en-us/drivers/",
    "officialDownload": "https://www.nvidia.com/en-us/drivers/",
    "documentation": "https://www.nvidia.com/en-us/drivers/",
    "localFolder": "50_FIRMWARE/BIOS/NVIDIA",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.nvidia.com/en-us/drivers/",
        "status": 200,
        "finalUrl": "https://www.nvidia.com/en-us/drivers/",
        "title": "Download The Official NVIDIA Drivers | NVIDIA",
        "checkedAt": "2026-09-09T20:17:56.868563+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.nvidia.com/en-us/drivers/",
        "status": 200,
        "finalUrl": "https://www.nvidia.com/en-us/drivers/",
        "title": "Download The Official NVIDIA Drivers | NVIDIA",
        "checkedAt": "2026-09-09T20:17:56.868563+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Identify the exact device model and current firmware.",
      "Read the vendor upgrade instructions and confirm stable power and recovery options.",
      "Apply only the matching approved image, then verify the reported firmware version."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "sysinternals",
    "name": "Sysinternals Suite",
    "developer": "Microsoft",
    "description": "Core portable Windows diagnostics, process inspection and administration suite. Individual tools are searchable below.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "Sysinternals suite"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/procexp64.exe",
    "inventoryPatterns": [
      "procexp64.exe",
      "Autoruns64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " The entire official suite is the parent archive; individual records highlight frequently used members. Parent detection requires configured marker files, not every suite member.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "inventoryMatch": "all",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
        "title": "Sysinternals Suite - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.326785+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
        "title": "Sysinternals Suite - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.326785+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Sysinternals Suite using the package for your operating system.",
      "Use it for: Core portable Windows diagnostics, process inspection and administration suite. Individual tools are searchable below.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "autoruns",
    "name": "Autoruns",
    "developer": "Microsoft Sysinternals",
    "description": "Inspect startup persistence and scheduled launch points. Disable selectively after recording originals.",
    "categories": [
      "Startup & Processes",
      "Malware & Security"
    ],
    "tags": [
      "malware Windows slow"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/autoruns64.exe",
    "inventoryPatterns": [
      "autoruns64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
        "title": "Autoruns - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.811989+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
        "title": "Autoruns - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.811989+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Autoruns using the package for your operating system.",
      "Use it for: Inspect startup persistence and scheduled launch points. Disable selectively after recording originals.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "process-explorer",
    "name": "Process Explorer",
    "developer": "Microsoft Sysinternals",
    "description": "Inspect processes, handles and loaded modules; use signatures to support investigation.",
    "categories": [
      "Startup & Processes",
      "Malware & Security"
    ],
    "tags": [
      "Windows slow malware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/procexp64.exe",
    "inventoryPatterns": [
      "procexp64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
        "title": "Process Explorer - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.847580+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
        "title": "Process Explorer - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.847580+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Process Explorer using the package for your operating system.",
      "Use it for: Inspect processes, handles and loaded modules; use signatures to support investigation.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "procmon",
    "name": "Process Monitor",
    "developer": "Microsoft Sysinternals",
    "description": "Trace file, registry and process activity with filters; logs may contain private paths.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "Windows repair"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/Procmon64.exe",
    "inventoryPatterns": [
      "Procmon64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
        "title": "Process Monitor - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.069848+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
        "title": "Process Monitor - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.069848+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Process Monitor using the package for your operating system.",
      "Use it for: Trace file, registry and process activity with filters; logs may contain private paths.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "tcpview",
    "name": "TCPView",
    "developer": "Microsoft Sysinternals",
    "description": "Map live TCP/UDP connections to owning processes.",
    "categories": [
      "Startup & Processes",
      "Networking",
      "Malware & Security"
    ],
    "tags": [
      "network malware",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/tcpview64.exe",
    "inventoryPatterns": [
      "tcpview64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
        "title": "TCPView for Windows - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.327784+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
        "title": "TCPView for Windows - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.327784+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open TCPView using the package for your operating system.",
      "Use it for: Map live TCP/UDP connections to owning processes.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "rammap",
    "name": "RAMMap",
    "developer": "Microsoft Sysinternals",
    "description": "Understand physical memory use and file cache; avoid treating cache as wasted RAM.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "RAM memory"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/RAMMap64.exe",
    "inventoryPatterns": [
      "RAMMap64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
        "title": "RAMMap - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.069848+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
        "title": "RAMMap - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.069848+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open RAMMap using the package for your operating system.",
      "Use it for: Understand physical memory use and file cache; avoid treating cache as wasted RAM.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "disk2vhd",
    "name": "Disk2vhd",
    "developer": "Microsoft Sysinternals",
    "description": "Capture Windows volumes into virtual disks; use consistent snapshots and a separate destination.",
    "categories": [
      "Startup & Processes",
      "Imaging & Cloning"
    ],
    "tags": [
      "SSD clone imaging"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/disk2vhd64.exe",
    "inventoryPatterns": [
      "disk2vhd64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
        "title": "Disk2vhd - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.752323+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
        "title": "Disk2vhd - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.752323+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Disk2vhd using the package for your operating system.",
      "Use it for: Capture Windows volumes into virtual disks; use consistent snapshots and a separate destination.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "sigcheck",
    "name": "Sigcheck",
    "developer": "Microsoft Sysinternals",
    "description": "Inspect file signatures and hashes; online reputation options transmit data.",
    "categories": [
      "Startup & Processes",
      "Malware & Security"
    ],
    "tags": [
      "malware signature"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/sigcheck64.exe",
    "inventoryPatterns": [
      "sigcheck64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
        "title": "Sigcheck - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.420190+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
        "title": "Sigcheck - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.420190+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Sigcheck using the package for your operating system.",
      "Use it for: Inspect file signatures and hashes; online reputation options transmit data.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "pstools",
    "name": "PsTools",
    "developer": "Microsoft Sysinternals",
    "description": "Administrative command-line suite; remote execution requires explicit authorization.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "remote administration"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/PsInfo64.exe",
    "inventoryPatterns": [
      "PsInfo64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
        "title": "PsTools - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.072367+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
        "title": "PsTools - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.072367+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open PsTools using the package for your operating system.",
      "Use it for: Administrative command-line suite; remote execution requires explicit authorization.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "procdump",
    "name": "ProcDump",
    "developer": "Microsoft Sysinternals",
    "description": "Capture process dumps for crash analysis. Dumps may contain sensitive memory.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "BSOD crash"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/procdump64.exe",
    "inventoryPatterns": [
      "procdump64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
        "title": "ProcDump - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.809473+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
        "title": "ProcDump - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.809473+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open ProcDump using the package for your operating system.",
      "Use it for: Capture process dumps for crash analysis. Dumps may contain sensitive memory.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "handle",
    "name": "Handle",
    "developer": "Microsoft Sysinternals",
    "description": "Identify processes holding file handles; avoid forced handle closure.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "locked file"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/handle64.exe",
    "inventoryPatterns": [
      "handle64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
        "title": "Handle - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.014554+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
        "title": "Handle - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.014554+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Handle using the package for your operating system.",
      "Use it for: Identify processes holding file handles; avoid forced handle closure.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "strings",
    "name": "Strings",
    "developer": "Microsoft Sysinternals",
    "description": "Extract printable strings from files for offline inspection.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "text binaries"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/strings64.exe",
    "inventoryPatterns": [
      "strings64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
        "title": "Strings - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.220255+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
        "title": "Strings - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.220255+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open Strings using the package for your operating system.",
      "Use it for: Extract printable strings from files for offline inspection.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "sdelete",
    "name": "SDelete",
    "developer": "Microsoft Sysinternals",
    "description": "Secure deletion utility. SSD wear leveling means file overwrite is not a guaranteed media sanitization method.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "erase delete"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/sdelete64.exe",
    "inventoryPatterns": [
      "sdelete64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
        "title": "SDelete - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.189679+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
        "title": "SDelete - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.189679+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open SDelete using the package for your operating system.",
      "Use it for: Secure deletion utility. SSD wear leveling means file overwrite is not a guaranteed media sanitization method.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "zoomit",
    "name": "ZoomIt",
    "developer": "Microsoft Sysinternals",
    "description": "Screen zoom and annotation for support demonstrations.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "presentation"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/ZoomIt64.exe",
    "inventoryPatterns": [
      "ZoomIt64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
        "title": "ZoomIt - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.377090+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
        "title": "ZoomIt - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.377090+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open ZoomIt using the package for your operating system.",
      "Use it for: Screen zoom and annotation for support demonstrations.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "psping",
    "name": "PsPing",
    "developer": "Microsoft Sysinternals",
    "description": "Measure ICMP/TCP connectivity and latency on authorized systems.",
    "categories": [
      "Startup & Processes",
      "Networking"
    ],
    "tags": [
      "packet loss port test",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/psping64.exe",
    "inventoryPatterns": [
      "psping64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
        "title": "PsPing - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.015556+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
        "title": "PsPing - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.015556+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Open PsPing using the package for your operating system.",
      "Use it for: Measure ICMP/TCP connectivity and latency on authorized systems.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "sfc",
    "name": "System File Checker",
    "developer": "Microsoft",
    "description": "Checks and repairs protected Windows files; run elevated and review CBS logs.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "sfc /scannow"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "sfc /scannow",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
        "title": "sfc | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:54.787105+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
        "title": "sfc | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:54.787105+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: sfc /scannow",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "dism",
    "name": "DISM component store repair",
    "developer": "Microsoft",
    "description": "Repairs the running Windows component store. May require internet or a matching local repair source.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "DISM /Online /Cleanup-Image /RestoreHealth"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "DISM /Online /Cleanup-Image /RestoreHealth",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism?view=windows-11",
        "title": "DISM Overview | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.703748+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism?view=windows-11",
        "title": "DISM Overview | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.703748+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: DISM /Online /Cleanup-Image /RestoreHealth",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "chkdsk",
    "name": "CHKDSK read-only check",
    "developer": "Microsoft",
    "description": "Reports filesystem errors without /f or /r. Image a failing drive before repair or extensive scans.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "chkdsk C:"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "chkdsk C:",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#diskpart",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
        "title": "chkdsk | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.421701+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
        "title": "chkdsk | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.421701+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: chkdsk C:",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "msconfig",
    "name": "System Configuration",
    "developer": "Microsoft",
    "description": "Review startup options. Persistent Safe Boot can strand a system; record changes.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "msconfig"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "msconfig",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: msconfig",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "msinfo32",
    "name": "System Information",
    "developer": "Microsoft",
    "description": "Inspect hardware, BIOS mode, Secure Boot and Windows details.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "msinfo32"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "msinfo32",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
        "title": "msinfo32 | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.451061+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
        "title": "msinfo32 | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.451061+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: msinfo32",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "dxdiag",
    "name": "DirectX Diagnostic Tool",
    "developer": "Microsoft",
    "description": "Collect graphics/audio information for GPU troubleshooting.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "dxdiag"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "dxdiag",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: dxdiag",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "eventvwr",
    "name": "Event Viewer",
    "developer": "Microsoft",
    "description": "Correlate errors by timestamp; an event alone does not prove the root cause.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "eventvwr.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "eventvwr.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: eventvwr.msc",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "perfmon",
    "name": "Performance Monitor",
    "developer": "Microsoft",
    "description": "Track system performance counters over time.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "perfmon"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "perfmon",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: perfmon",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "reliability",
    "name": "Reliability Monitor",
    "developer": "Microsoft",
    "description": "Review crashes and update history on a timeline.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "perfmon /rel",
      "BSOD",
      "blue screen",
      "crash"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "perfmon /rel",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: perfmon /rel",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "resmon",
    "name": "Resource Monitor",
    "developer": "Microsoft",
    "description": "Inspect CPU, disk, memory and network activity.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "resmon"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "resmon",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: resmon",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "taskmgr",
    "name": "Task Manager",
    "developer": "Microsoft",
    "description": "Inspect running processes and startup impact; ending tasks can lose work.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "taskmgr"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "taskmgr",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: taskmgr",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "services",
    "name": "Services console",
    "developer": "Microsoft",
    "description": "Review service status and dependencies; do not arbitrarily disable services.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "services.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "services.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: services.msc",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "devmgmt",
    "name": "Device Manager",
    "developer": "Microsoft",
    "description": "Inspect device error codes, hardware IDs and driver rollback options.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "devmgmt.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "devmgmt.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: devmgmt.msc",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "diskmgmt",
    "name": "Disk Management",
    "developer": "Microsoft",
    "description": "View disk layout. Initializing, formatting and deleting volumes destroy data.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "diskmgmt.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "diskmgmt.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#diskpart",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: diskmgmt.msc",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "diskpart",
    "name": "DiskPart inventory",
    "developer": "Microsoft",
    "description": "Inventory only. CLEAN, FORMAT and DELETE are destructive; no erase commands are provided here.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "diskpart list disk list volume exit"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "diskpart\nlist disk\nlist volume\nexit",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#diskpart",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
        "title": "diskpart | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.566388+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
        "title": "diskpart | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.566388+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: diskpart\nlist disk\nlist volume\nexit",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "compmgmt",
    "name": "Computer Management",
    "developer": "Microsoft",
    "description": "Administrative consoles for events, disks and local accounts; edition support varies.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "compmgmt.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "compmgmt.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: compmgmt.msc",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "regedit",
    "name": "Registry Editor",
    "developer": "Microsoft",
    "description": "Export the specific key before editing; avoid registry cleaners.",
    "categories": [
      "Windows Tweaks"
    ],
    "tags": [
      "regedit"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "regedit",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: regedit",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "gpedit",
    "name": "Local Group Policy Editor",
    "developer": "Microsoft",
    "description": "Review supported local policies; unavailable on Home editions. Managed policy can override changes.",
    "categories": [
      "Windows Privacy"
    ],
    "tags": [
      "gpedit.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "gpedit.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: gpedit.msc",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "secpol",
    "name": "Local Security Policy",
    "developer": "Microsoft",
    "description": "Review local security policy on supported Windows editions.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "secpol.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "secpol.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#bitlocker",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: secpol.msc",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "netplwiz",
    "name": "User Accounts",
    "developer": "Microsoft",
    "description": "Authorized local account administration; do not configure insecure automatic sign-in.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "netplwiz"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "netplwiz",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#bitlocker",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: netplwiz",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "cleanmgr",
    "name": "Disk Cleanup",
    "developer": "Microsoft",
    "description": "Review selected cleanup categories; previous installations may be needed for rollback.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "cleanmgr"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "cleanmgr",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: cleanmgr",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "mrt",
    "name": "Malicious Software Removal Tool",
    "developer": "Microsoft",
    "description": "Windows malware removal tool for a limited threat set; not a complete antivirus replacement.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "mrt"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "mrt",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: mrt",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "optionalfeatures",
    "name": "Windows Features",
    "developer": "Microsoft",
    "description": "Review optional components; enabling features may require installation sources.",
    "categories": [
      "Windows Tweaks"
    ],
    "tags": [
      "optionalfeatures"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "optionalfeatures",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: optionalfeatures",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "appwiz",
    "name": "Programs and Features",
    "developer": "Microsoft",
    "description": "Use the vendor uninstall path before forced leftover cleanup.",
    "categories": [
      "Uninstallers"
    ],
    "tags": [
      "appwiz.cpl"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "appwiz.cpl",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: appwiz.cpl",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "ncpa",
    "name": "Network Connections",
    "developer": "Microsoft",
    "description": "Inspect adapter properties; changing bindings can interrupt access.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "ncpa.cpl",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "ncpa.cpl",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: ncpa.cpl",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "powercfg",
    "name": "Power configuration report",
    "developer": "Microsoft",
    "description": "List available sleep states before diagnosing power behavior.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "powercfg /a"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "powercfg /a",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "reviewedUrl": "https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options",
      "checkedAt": "2026-09-09",
      "method": "web retrieval"
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: powercfg /a",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "winget",
    "name": "WinGet package manager",
    "developer": "Microsoft",
    "description": "List installed packages. Availability depends on App Installer and Windows edition.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget list"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "winget list",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: winget list",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "winget-upgrade",
    "name": "WinGet upgrade preview",
    "developer": "Microsoft",
    "description": "List packages with available upgrades without installing them; requires source access.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget upgrade"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "winget upgrade",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: winget upgrade",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "winget-export",
    "name": "Export package list",
    "developer": "Microsoft",
    "description": "Creates a package inventory in the current directory; review before sharing.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget export -o packages.json"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "winget export -o packages.json",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: winget export -o packages.json",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "winget-install",
    "name": "Install common software with WinGet",
    "developer": "Microsoft",
    "description": "Installs 7-Zip after reviewing source and installer prompts; needs internet.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget install --id 7zip.7zip --exact"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "winget install --id 7zip.7zip --exact",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: winget install --id 7zip.7zip --exact",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "robocopy",
    "name": "Robocopy copy preview",
    "developer": "Microsoft",
    "description": "Replace paths; /L previews. /MIR and /PURGE can delete destination files and are intentionally omitted.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "robocopy \"SOURCE\" \"DESTINATION\" /E /L /R:1 /W:1"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "robocopy \"SOURCE\" \"DESTINATION\" /E /L /R:1 /W:1",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
        "title": "Robocopy | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.773919+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
        "title": "Robocopy | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.773919+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: robocopy \"SOURCE\" \"DESTINATION\" /E /L /R:1 /W:1",
      "Review the output and follow the official documentation before taking additional action."
    ],
    "automationSupport": {
      "level": "documented",
      "source": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
      "notes": "Native Windows copy jobs, logs and documented return codes; preview paths and interpret codes using the official table."
    }
  },
  {
    "id": "cipher",
    "name": "EFS encryption information",
    "developer": "Microsoft",
    "description": "Replace FILE to inspect EFS encryption. EFS certificate recovery is different from BitLocker recovery.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "cipher /c \"FILE\""
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "cipher /c \"FILE\"",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#bitlocker",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
        "title": "cipher | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.529281+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
        "title": "cipher | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.529281+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: cipher /c \"FILE\"",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "manage-bde",
    "name": "BitLocker status",
    "developer": "Microsoft",
    "description": "Read volume encryption state. Authorized systems only; no encryption bypass exists here.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "manage-bde -status"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "manage-bde -status",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#bitlocker",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
        "title": "manage-bde | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.565389+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
        "title": "manage-bde | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.565389+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: manage-bde -status",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "reagentc",
    "name": "Windows RE status",
    "developer": "Microsoft",
    "description": "Inspect WinRE configuration from an elevated terminal.",
    "categories": [
      "Boot & Recovery"
    ],
    "tags": [
      "reagentc /info"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "reagentc /info",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: reagentc /info",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "bcdedit",
    "name": "BCD inspection",
    "developer": "Microsoft",
    "description": "Elevated read of boot entries. BCD edits can make a machine unbootable.",
    "categories": [
      "Boot & Recovery"
    ],
    "tags": [
      "bcdedit /enum all"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "bcdedit /enum all",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
        "title": "bcdedit | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.704749+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
        "title": "bcdedit | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.704749+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: bcdedit /enum all",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "ipconfig",
    "name": "IP configuration",
    "developer": "Microsoft",
    "description": "Inspect addressing, DNS servers and DHCP state. APIPA suggests no DHCP lease.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "ipconfig /all",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "ipconfig /all",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
        "title": "ipconfig | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.505223+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
        "title": "ipconfig | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.505223+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: ipconfig /all",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "dns",
    "name": "DNS lookup",
    "developer": "Microsoft",
    "description": "Compare lookup results against expected DNS; external names need internet.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "nslookup example.com",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "nslookup example.com",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
        "title": "nslookup | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.648594+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
        "title": "nslookup | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.648594+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: nslookup example.com",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "tracert",
    "name": "Route trace",
    "developer": "Microsoft",
    "description": "Trace route without reverse DNS. Missing hops can be filtering rather than failure.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "tracert -d example.com",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "tracert -d example.com",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
        "title": "tracert | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.804496+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
        "title": "tracert | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.804496+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: tracert -d example.com",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "porttest",
    "name": "TCP port test",
    "developer": "Microsoft",
    "description": "PowerShell connectivity test. Replace host and port with an authorized endpoint.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "Test-NetConnection example.com -Port 443",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Test-NetConnection example.com -Port 443",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: Test-NetConnection example.com -Port 443",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "netadapter",
    "name": "Network adapter status",
    "developer": "Microsoft",
    "description": "PowerShell adapter status and negotiated link speed.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "Get-NetAdapter ",
      " Format-Table Name, Status, LinkSpeed",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Get-NetAdapter | Format-Table Name, Status, LinkSpeed",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: Get-NetAdapter | Format-Table Name, Status, LinkSpeed",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "netip",
    "name": "PowerShell IP configuration",
    "developer": "Microsoft",
    "description": "Inspect interfaces, gateways and DNS settings.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "Get-NetIPConfiguration",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Get-NetIPConfiguration",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: Get-NetIPConfiguration",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "flushdns",
    "name": "Flush DNS cache",
    "developer": "Microsoft",
    "description": "Clear cached resolver results after correcting DNS configuration.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "ipconfig /flushdns",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "ipconfig /flushdns",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: ipconfig /flushdns",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "winsock",
    "name": "Winsock reset",
    "developer": "Microsoft",
    "description": "Elevated reset; may affect VPN/security software and requires restart. Record current settings first.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "netsh winsock reset",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "netsh winsock reset",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: netsh winsock reset",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "ping",
    "name": "Packet loss sample",
    "developer": "Microsoft",
    "description": "Compare gateway and external host tests. ICMP may be filtered.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "ping -n 20 example.com",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "ping -n 20 example.com",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
        "title": "ping | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.649592+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
        "title": "ping | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.649592+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: ping -n 20 example.com",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "wlan",
    "name": "Wi-Fi interface details",
    "developer": "Microsoft",
    "description": "Inspect SSID, radio and signal details; avoid exporting credentials.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "netsh wlan show interfaces",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "netsh wlan show interfaces",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: netsh wlan show interfaces",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "arp",
    "name": "Neighbor / duplicate IP inspection",
    "developer": "Microsoft",
    "description": "Compare IP-to-MAC observations with DHCP records; investigate changes before assigning addresses.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "arp -a",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "arp -a",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
        "title": "arp | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.296213+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
        "title": "arp | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.296213+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: arp -a",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "restore",
    "name": "System Restore",
    "developer": "Microsoft",
    "description": "Review available restore points; affected applications may need reinstalling.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "rstrui.exe"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "rstrui.exe",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: rstrui.exe",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "installer",
    "name": "Windows Installer service check",
    "developer": "Microsoft",
    "description": "PowerShell service inspection. A stopped demand-start service alone is not a fault.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "Get-Service msiserver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Get-Service msiserver",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: Get-Service msiserver",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "quickassist",
    "name": "Windows Quick Assist",
    "developer": "Microsoft",
    "description": "Attended support with a one-time code; app availability and internet are required.",
    "categories": [
      "Remote Support"
    ],
    "tags": [
      "quickassist"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Attended access only by default. Unattended service installation and enrollment must be separately authorized.",
    "sourceStatus": "Official page reachable",
    "command": "quickassist",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: quickassist",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "defenderoffline",
    "name": "Microsoft Defender Offline",
    "developer": "Microsoft",
    "description": "Elevated PowerShell starts an offline scan and restarts the PC. Save work and confirm recovery-key access first.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "Start-MpWDOScan"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Start-MpWDOScan",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: Start-MpWDOScan",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "ddrescue",
    "name": "GNU ddrescue",
    "developer": "GNU / Linux community",
    "description": "Image failing media with a mapfile to resume. Identify source and a healthy destination; follow the local recovery guide.",
    "categories": [
      "Homelab / Linux",
      "Data Recovery",
      "Imaging & Cloning"
    ],
    "tags": [
      "Linux rescue SSD recover files"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.gnu.org/software/ddrescue/",
    "officialDownload": "",
    "documentation": "https://www.gnu.org/software/ddrescue/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "ddrescue --help",
    "defaultFavorite": true,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.gnu.org/software/ddrescue/",
        "status": 200,
        "finalUrl": "https://www.gnu.org/software/ddrescue/",
        "title": "Ddrescue - GNU Project - Free Software Foundation (FSF)",
        "checkedAt": "2026-09-09T20:17:55.671088+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.gnu.org/software/ddrescue/",
        "status": 200,
        "finalUrl": "https://www.gnu.org/software/ddrescue/",
        "title": "Ddrescue - GNU Project - Free Software Foundation (FSF)",
        "checkedAt": "2026-09-09T20:17:55.671088+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: ddrescue --help",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "dd",
    "name": "dd",
    "developer": "GNU / Linux community",
    "description": "Raw block copying for healthy sources only. A reversed output device overwrites the wrong disk. Prefer a guided cloning tool.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
    "officialDownload": "",
    "documentation": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "dd --help",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
        "status": 200,
        "finalUrl": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
        "title": "dd invocation (GNU Coreutils 9.11)",
        "checkedAt": "2026-09-09T20:17:55.702162+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
        "status": 200,
        "finalUrl": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
        "title": "dd invocation (GNU Coreutils 9.11)",
        "checkedAt": "2026-09-09T20:17:55.702162+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: dd --help",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "ssh",
    "name": "OpenSSH client",
    "developer": "GNU / Linux community",
    "description": "Authorized remote shell; verify host key through a trusted channel.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.openssh.com/manual.html",
    "officialDownload": "",
    "documentation": "https://www.openssh.com/manual.html",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "ssh user@HOST",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.openssh.com/manual.html",
        "status": 200,
        "finalUrl": "https://www.openssh.org/manual.html",
        "title": "OpenSSH: Manual Pages",
        "checkedAt": "2026-09-09T20:17:57.725982+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.openssh.com/manual.html",
        "status": 200,
        "finalUrl": "https://www.openssh.org/manual.html",
        "title": "OpenSSH: Manual Pages",
        "checkedAt": "2026-09-09T20:17:57.725982+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: ssh user@HOST",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "mdadm",
    "name": "Linux software RAID",
    "developer": "GNU / Linux community",
    "description": "Read RAID state first; do not create or force-assemble arrays on original recovery media.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://docs.kernel.org/admin-guide/md.html",
    "officialDownload": "",
    "documentation": "https://docs.kernel.org/admin-guide/md.html",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "cat /proc/mdstat",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://docs.kernel.org/admin-guide/md.html",
        "status": 200,
        "finalUrl": "https://docs.kernel.org/admin-guide/md.html",
        "title": "RAID arrays — The Linux Kernel documentation",
        "checkedAt": "2026-09-09T20:17:51.159597+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://docs.kernel.org/admin-guide/md.html",
        "status": 200,
        "finalUrl": "https://docs.kernel.org/admin-guide/md.html",
        "title": "RAID arrays — The Linux Kernel documentation",
        "checkedAt": "2026-09-09T20:17:51.159597+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: cat /proc/mdstat",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "lvm",
    "name": "LVM inventory",
    "developer": "GNU / Linux community",
    "description": "List physical volumes, groups and logical volumes. Activation can permit writes.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://sourceware.org/lvm2/",
    "officialDownload": "",
    "documentation": "https://sourceware.org/lvm2/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "pvs; vgs; lvs",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://sourceware.org/lvm2/",
        "status": 200,
        "finalUrl": "https://sourceware.org/lvm2/",
        "title": "LVM2 Resource Page",
        "checkedAt": "2026-09-09T20:17:54.502509+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://sourceware.org/lvm2/",
        "status": 200,
        "finalUrl": "https://sourceware.org/lvm2/",
        "title": "LVM2 Resource Page",
        "checkedAt": "2026-09-09T20:17:54.502509+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: pvs; vgs; lvs",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "zfs",
    "name": "ZFS pool status",
    "developer": "GNU / Linux community",
    "description": "Inspect imported pools. Never create a new pool over a recovery target.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://openzfs.github.io/openzfs-docs/",
    "officialDownload": "",
    "documentation": "https://openzfs.github.io/openzfs-docs/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "zpool status",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://openzfs.github.io/openzfs-docs/",
        "status": 200,
        "finalUrl": "https://openzfs.github.io/openzfs-docs/",
        "title": "OpenZFS Documentation — OpenZFS documentation",
        "checkedAt": "2026-09-09T20:17:53.919791+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://openzfs.github.io/openzfs-docs/",
        "status": 200,
        "finalUrl": "https://openzfs.github.io/openzfs-docs/",
        "title": "OpenZFS Documentation — OpenZFS documentation",
        "checkedAt": "2026-09-09T20:17:53.919791+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: zpool status",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "lsblk",
    "name": "Linux block device inventory",
    "developer": "GNU / Linux community",
    "description": "Match disks by serial and capacity before mounting or imaging.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "officialDownload": "",
    "documentation": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "lsblk -o NAME,SIZE,MODEL,SERIAL,FSTYPE,MOUNTPOINTS",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: lsblk -o NAME,SIZE,MODEL,SERIAL,FSTYPE,MOUNTPOINTS",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "mount",
    "name": "Read-only filesystem mounting",
    "developer": "GNU / Linux community",
    "description": "Inspect existing mounts first. Filesystem-specific no-replay options are in the local guide.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "officialDownload": "",
    "documentation": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "findmnt",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: findmnt",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "rsync",
    "name": "rsync dry run",
    "developer": "GNU / Linux community",
    "description": "Preview a file copy. Trailing slashes matter; avoid --delete for initial recovery.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Open source",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://rsync.samba.org/",
    "officialDownload": "",
    "documentation": "https://rsync.samba.org/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "rsync -avhn /SOURCE/ /DESTINATION/",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://rsync.samba.org/",
        "status": 200,
        "finalUrl": "https://rsync.samba.org/",
        "title": "rsync",
        "checkedAt": "2026-09-09T20:17:54.580181+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://rsync.samba.org/",
        "status": 200,
        "finalUrl": "https://rsync.samba.org/",
        "title": "rsync",
        "checkedAt": "2026-09-09T20:17:54.580181+00:00",
        "contentType": "text/html"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: rsync -avhn /SOURCE/ /DESTINATION/",
      "Review the output and follow the official documentation before taking additional action."
    ],
    "automationSupport": {
      "level": "documented",
      "source": "https://rsync.samba.org/",
      "notes": "Scriptable incremental copying; preview changes and avoid deletion options unless explicitly approved."
    },
    "licenseSource": "https://rsync.samba.org/"
  },
  {
    "id": "fsck",
    "name": "Filesystem check planning",
    "developer": "GNU / Linux community",
    "description": "Identify filesystem and unmount before any checker. Image failing media first; use filesystem-specific tools.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "officialDownload": "",
    "documentation": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "lsblk -f",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: lsblk -f",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "ip-linux",
    "name": "Linux network inventory",
    "developer": "GNU / Linux community",
    "description": "Inspect addresses and routing before modifying interfaces.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
    "officialDownload": "",
    "documentation": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "ip address; ip route",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
        "title": "Index of /pub/linux/utils/net/iproute2/",
        "checkedAt": "2026-09-09T20:17:55.775338+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
        "title": "Index of /pub/linux/utils/net/iproute2/",
        "checkedAt": "2026-09-09T20:17:55.775338+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: ip address; ip route",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "unattend",
    "name": "Windows unattended language template",
    "developer": "Master IT Toolkit",
    "description": "Language-only template for Windows Setup. No account bypass, credentials or disk operations. Validate against the exact image.",
    "categories": [
      "Account & OOBE",
      "Documentation"
    ],
    "tags": [
      "offline",
      "reference"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "Architecture independent"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "https://github.com/samirank/master-it-toolkit#readme",
    "localFolder": "10_WINDOWS_TOOLBOX/06_Account-OOBE/Unattended",
    "localExecutable": "10_WINDOWS_TOOLBOX/06_Account-OOBE/Unattended/autounattend.xml",
    "inventoryPatterns": [
      "autounattend.xml"
    ],
    "kind": "Documentation",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html",
    "quickStart": [
      "Open Windows unattended language template using the package for your operating system.",
      "Use it for: Language-only template for Windows Setup. No account bypass, credentials or disk operations. Validate against the exact image.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "reference",
    "name": "Offline technician reference",
    "developer": "Master IT Toolkit",
    "description": "24 local cheat sheets covering recovery, BitLocker, boot keys, networking, Linux and privacy.",
    "categories": [
      "Documentation"
    ],
    "tags": [
      "offline",
      "reference"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "Architecture independent"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "https://github.com/samirank/master-it-toolkit#readme",
    "localFolder": "70_DOCUMENTATION",
    "localExecutable": "70_DOCUMENTATION/reference.html",
    "inventoryPatterns": [
      "reference.html"
    ],
    "kind": "Documentation",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html",
    "quickStart": [
      "Open Offline technician reference using the package for your operating system.",
      "Use it for: 24 local cheat sheets covering recovery, BitLocker, boot keys, networking, Linux and privacy.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "inventory-script",
    "name": "Update toolkit inventory",
    "developer": "Master IT Toolkit",
    "description": "Scan expected files and record local availability without executing tools.",
    "categories": [
      "Technician Scripts"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "https://github.com/samirank/master-it-toolkit#readme",
    "localFolder": "60_SCRIPTS/Inventory",
    "localExecutable": "60_SCRIPTS/Inventory/Update-ToolkitInventory.ps1",
    "inventoryPatterns": [
      "Update-ToolkitInventory.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Inventory\\Update-ToolkitInventory.ps1",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html",
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: .\\60_SCRIPTS\\Inventory\\Update-ToolkitInventory.ps1",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "metadata-script",
    "name": "Update toolkit metadata",
    "developer": "Master IT Toolkit",
    "description": "Optional online official-source and release checks; no software replacement.",
    "categories": [
      "Technician Scripts"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "https://github.com/samirank/master-it-toolkit#readme",
    "localFolder": "60_SCRIPTS/Inventory",
    "localExecutable": "60_SCRIPTS/Inventory/Update-ToolkitMetadata.ps1",
    "inventoryPatterns": [
      "Update-ToolkitMetadata.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Inventory\\Update-ToolkitMetadata.ps1",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html",
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: .\\60_SCRIPTS\\Inventory\\Update-ToolkitMetadata.ps1",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "download-script",
    "name": "Preview / download reviewed tools",
    "developer": "Master IT Toolkit",
    "description": "Preview the reviewed direct-download subset; explicit confirmation, no execution.",
    "categories": [
      "Technician Scripts"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "https://github.com/samirank/master-it-toolkit#readme",
    "localFolder": "60_SCRIPTS/Inventory",
    "localExecutable": "60_SCRIPTS/Inventory/Download-MissingTools.ps1",
    "inventoryPatterns": [
      "Download-MissingTools.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Inventory\\Download-MissingTools.ps1 -WhatIf",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html",
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: .\\60_SCRIPTS\\Inventory\\Download-MissingTools.ps1 -WhatIf",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "diagnostic-script",
    "name": "Collect PC diagnostics",
    "developer": "Master IT Toolkit",
    "description": "Read-only hardware report; requires an explicit new output file. Contains device identifiers.",
    "categories": [
      "Technician Scripts",
      "Hardware Diagnostics"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "https://github.com/samirank/master-it-toolkit#readme",
    "localFolder": "60_SCRIPTS/Diagnostics",
    "localExecutable": "60_SCRIPTS/Diagnostics/Get-PCDiagnostics.ps1",
    "inventoryPatterns": [
      "Get-PCDiagnostics.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html",
    "quickStart": [
      "Open Collect PC diagnostics using the package for your operating system.",
      "Use it for: Read-only hardware report; requires an explicit new output file. Contains device identifiers.",
      "Review the output and save your work or report; use the official documentation for advanced operations."
    ]
  },
  {
    "id": "network-script",
    "name": "Inspect network configuration",
    "developer": "Master IT Toolkit",
    "description": "Read adapter, IP and DNS configuration without resets or scans.",
    "categories": [
      "Technician Scripts",
      "Networking"
    ],
    "tags": [
      "offline",
      "PowerShell",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "https://github.com/samirank/master-it-toolkit#readme",
    "localFolder": "60_SCRIPTS/Network",
    "localExecutable": "60_SCRIPTS/Network/Get-NetworkDiagnostics.ps1",
    "inventoryPatterns": [
      "Get-NetworkDiagnostics.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Network\\Get-NetworkDiagnostics.ps1",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html",
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: .\\60_SCRIPTS\\Network\\Get-NetworkDiagnostics.ps1",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "repair-script",
    "name": "Windows system file repair helper",
    "developer": "Master IT Toolkit",
    "description": "Check current component-store status by default. Optional elevated repair is confirmed separately.",
    "categories": [
      "Technician Scripts",
      "Windows Repair"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "https://github.com/samirank/master-it-toolkit#readme",
    "localFolder": "60_SCRIPTS/Windows-Repair",
    "localExecutable": "60_SCRIPTS/Windows-Repair/Repair-WindowsFiles.ps1",
    "inventoryPatterns": [
      "Repair-WindowsFiles.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Windows-Repair\\Repair-WindowsFiles.ps1 -WhatIf",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html",
    "quickStart": [
      "Read the command and substitute only the documented target values.",
      "Run it in the appropriate OS shell with the documented privileges: .\\60_SCRIPTS\\Windows-Repair\\Repair-WindowsFiles.ps1 -WhatIf",
      "Review the output and follow the official documentation before taking additional action."
    ]
  },
  {
    "id": "obs",
    "name": "OBS Studio",
    "developer": "OBS Studio project / publisher",
    "description": "Record screens and produce live streams.",
    "categories": [
      "Media",
      "Software Installers"
    ],
    "tags": [
      "OBS Studio",
      "Media",
      "open source"
    ],
    "useCases": [
      "Record screens and produce live streams."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://obsproject.com/download",
    "officialDownload": "https://obsproject.com/download",
    "documentation": "https://obsproject.com/kb/quick-start-guide",
    "localFolder": "40_INSTALLERS/Applications/obs",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Run Tools > Auto-Configuration Wizard for recording or streaming.",
      "Create a scene, add a display/window source, and check microphone levels.",
      "Record a short test and inspect video and audio before recording a session."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "obsidian",
    "name": "Obsidian",
    "developer": "Obsidian project / publisher",
    "description": "Maintain a local Markdown knowledge base.",
    "categories": [
      "Office & PDF",
      "Software Installers"
    ],
    "tags": [
      "Obsidian",
      "Office & PDF",
      "vendor software"
    ],
    "useCases": [
      "Maintain a local Markdown knowledge base."
    ],
    "priority": "P2",
    "license": "Free / paid options",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://obsidian.md/download",
    "officialDownload": "https://obsidian.md/download",
    "documentation": "https://obsidian.md/help/",
    "localFolder": "40_INSTALLERS/Applications/obsidian",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Create a vault in your chosen private notes folder.",
      "Create a note and connect related notes using double-bracket links.",
      "Back up the vault folder; configure sync separately if required."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "4kdownloader",
    "name": "4K Video Downloader Plus",
    "developer": "4K Video Downloader Plus project / publisher",
    "description": "Save permitted online video and audio.",
    "categories": [
      "Media",
      "Software Installers"
    ],
    "tags": [
      "4K Video Downloader Plus",
      "Media",
      "vendor software"
    ],
    "useCases": [
      "Save permitted online video and audio."
    ],
    "priority": "P2",
    "license": "Free / paid options",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.4kdownload.com/products/videodownloader",
    "officialDownload": "https://www.4kdownload.com/products/videodownloader",
    "documentation": "https://www.4kdownload.com/howto",
    "localFolder": "40_INSTALLERS/Applications/4kdownloader",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Copy a video URL you have permission to download.",
      "Paste the link and choose format, quality, and output directory.",
      "Verify the saved file; check the free-tier limits before batching."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "shotcut",
    "name": "Shotcut",
    "developer": "Shotcut project / publisher",
    "description": "Edit and export video projects.",
    "categories": [
      "Media",
      "Software Installers"
    ],
    "tags": [
      "Shotcut",
      "Media",
      "open source"
    ],
    "useCases": [
      "Edit and export video projects."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://shotcut.org/download/",
    "officialDownload": "https://shotcut.org/download/",
    "documentation": "https://shotcut.org/tutorials/",
    "localFolder": "40_INSTALLERS/Applications/shotcut",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Create a project folder and choose the video mode.",
      "Import clips, add them to the timeline, and trim or split them.",
      "Save the project and export a short sample before the final render."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "kdenlive",
    "name": "Kdenlive",
    "developer": "Kdenlive project / publisher",
    "description": "Edit multitrack video with effects and proxies.",
    "categories": [
      "Media",
      "Software Installers"
    ],
    "tags": [
      "Kdenlive",
      "Media",
      "open source"
    ],
    "useCases": [
      "Edit multitrack video with effects and proxies."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://kdenlive.org/download/",
    "officialDownload": "https://kdenlive.org/download/",
    "documentation": "https://docs.kdenlive.org/",
    "localFolder": "40_INSTALLERS/Applications/kdenlive",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Create a project with the source frame rate and resolution.",
      "Import footage into the Project Bin and arrange it on the timeline.",
      "Use proxies for heavy footage, save the project, then render a test."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "openshot",
    "name": "OpenShot",
    "developer": "OpenShot project / publisher",
    "description": "Assemble and export video timelines.",
    "categories": [
      "Media",
      "Software Installers"
    ],
    "tags": [
      "OpenShot",
      "Media",
      "open source"
    ],
    "useCases": [
      "Assemble and export video timelines."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.openshot.org/download/",
    "officialDownload": "https://www.openshot.org/download/",
    "documentation": "https://www.openshot.org/user-guide/",
    "localFolder": "40_INSTALLERS/Applications/openshot",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Import clips into a new project.",
      "Drag clips to tracks, trim their edges, and add titles.",
      "Save the project, then export a short preview to verify settings."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "thunderbird",
    "name": "Mozilla Thunderbird",
    "developer": "Mozilla Thunderbird project / publisher",
    "description": "Manage email, calendars and contacts.",
    "categories": [
      "Office & PDF",
      "Software Installers"
    ],
    "tags": [
      "Mozilla Thunderbird",
      "Office & PDF",
      "open source"
    ],
    "useCases": [
      "Manage email, calendars and contacts."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.thunderbird.net/",
    "officialDownload": "https://www.thunderbird.net/",
    "documentation": "https://support.mozilla.org/products/thunderbird",
    "localFolder": "40_INSTALLERS/Applications/thunderbird",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Add your email account with the provider sign-in flow.",
      "Confirm incoming/outgoing server settings and test sending and receiving.",
      "Back up the profile before migration; keep customer profiles separate."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "betterbird",
    "name": "Betterbird",
    "developer": "Betterbird project / publisher",
    "description": "Use a Thunderbird-derived desktop email client.",
    "categories": [
      "Office & PDF",
      "Software Installers"
    ],
    "tags": [
      "Betterbird",
      "Office & PDF",
      "open source"
    ],
    "useCases": [
      "Use a Thunderbird-derived desktop email client."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.betterbird.eu/downloads/",
    "officialDownload": "https://www.betterbird.eu/downloads/",
    "documentation": "https://www.betterbird.eu/support/",
    "localFolder": "40_INSTALLERS/Applications/betterbird",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Back up the existing mail profile before trying Betterbird.",
      "Add an account or follow the documented profile migration procedure.",
      "Test send/receive and calendar access before switching permanently."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "clawsmail",
    "name": "Claws Mail",
    "developer": "Claws Mail project / publisher",
    "description": "Use a lightweight desktop email client.",
    "categories": [
      "Office & PDF",
      "Software Installers"
    ],
    "tags": [
      "Claws Mail",
      "Office & PDF",
      "open source"
    ],
    "useCases": [
      "Use a lightweight desktop email client."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.claws-mail.org/",
    "officialDownload": "https://www.claws-mail.org/",
    "documentation": "https://www.claws-mail.org/documentation.php",
    "localFolder": "40_INSTALLERS/Applications/clawsmail",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Create an account and enter the provider server settings.",
      "Configure authentication and TLS according to provider instructions.",
      "Test send/receive and back up the mail configuration."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "joplin",
    "name": "Joplin",
    "developer": "Joplin project / publisher",
    "description": "Keep notebooks and synchronize notes.",
    "categories": [
      "Office & PDF",
      "Software Installers"
    ],
    "tags": [
      "Joplin",
      "Office & PDF",
      "open source"
    ],
    "useCases": [
      "Keep notebooks and synchronize notes."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://joplinapp.org/",
    "officialDownload": "https://joplinapp.org/",
    "documentation": "https://joplinapp.org/help/",
    "localFolder": "40_INSTALLERS/Applications/joplin",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Create a notebook and add notes or attachments.",
      "Choose a sync target only if needed and test with non-sensitive notes.",
      "Export a backup before changing sync or encryption settings."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "remmina",
    "name": "Remmina",
    "developer": "Remmina project / publisher",
    "description": "Connect from Linux using remote desktop protocols.",
    "categories": [
      "Remote Support",
      "Software Installers"
    ],
    "tags": [
      "Remmina",
      "Remote Support",
      "open source"
    ],
    "useCases": [
      "Connect from Linux using remote desktop protocols."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://remmina.org/",
    "officialDownload": "https://remmina.org/",
    "documentation": "https://remmina.org/how-to-install-remmina/",
    "localFolder": "40_INSTALLERS/Applications/remmina",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Create a connection profile and choose the target protocol.",
      "Enter an authorized host and verify its certificate or host identity.",
      "Connect through a trusted network or VPN and disconnect after support."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "meshcentral",
    "name": "MeshCentral",
    "developer": "MeshCentral project / publisher",
    "description": "Host an authorized remote management service.",
    "categories": [
      "Remote Support",
      "Software Installers"
    ],
    "tags": [
      "MeshCentral",
      "Remote Support",
      "open source"
    ],
    "useCases": [
      "Host an authorized remote management service."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://meshcentral.com/",
    "officialDownload": "https://meshcentral.com/",
    "documentation": "https://docs.meshcentral.com/",
    "localFolder": "40_INSTALLERS/Applications/meshcentral",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Deploy the server using the official setup guide with TLS.",
      "Create an administrator account and enroll only approved devices.",
      "Test one device, scope operator permissions, and document agent removal."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "syncthing",
    "name": "Syncthing",
    "developer": "Syncthing project / publisher",
    "description": "Synchronize folders between approved devices.",
    "categories": [
      "Networking",
      "Software Installers",
      "Backup & Sync"
    ],
    "tags": [
      "Syncthing",
      "Networking",
      "open source",
      "network",
      "network tools"
    ],
    "useCases": [
      "Synchronize folders between approved devices."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://syncthing.net/",
    "officialDownload": "https://syncthing.net/",
    "documentation": "https://docs.syncthing.net/intro/getting-started.html",
    "localFolder": "40_INSTALLERS/Applications/syncthing",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Pair devices by verifying their device IDs.",
      "Share a small test folder and choose send/receive behavior.",
      "Enable versioning where appropriate; synchronization is not a separate backup."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "keepassxc",
    "name": "KeePassXC",
    "developer": "KeePassXC project / publisher",
    "description": "Maintain a local encrypted password database.",
    "categories": [
      "Malware & Security",
      "Software Installers"
    ],
    "tags": [
      "KeePassXC",
      "Malware & Security",
      "open source"
    ],
    "useCases": [
      "Maintain a local encrypted password database."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://keepassxc.org/",
    "officialDownload": "https://keepassxc.org/",
    "documentation": "https://keepassxc.org/docs/",
    "localFolder": "40_INSTALLERS/Applications/keepassxc",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Create a database with a strong master passphrase.",
      "Add a test entry and verify locking and unlocking.",
      "Keep a secure backup and never store client secrets in shared toolkit notes."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "bleachbit",
    "name": "BleachBit",
    "developer": "BleachBit project / publisher",
    "description": "Preview and clean selected application data.",
    "categories": [
      "Windows Privacy",
      "Software Installers"
    ],
    "tags": [
      "BleachBit",
      "Windows Privacy",
      "open source"
    ],
    "useCases": [
      "Preview and clean selected application data."
    ],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; consult its license and bundled components.",
    "technicianLicenseNotes": "Review the official license for redistribution and client deployments.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.bleachbit.org/download",
    "officialDownload": "https://www.bleachbit.org/download",
    "documentation": "https://docs.bleachbit.org/",
    "localFolder": "40_INSTALLERS/Applications/bleachbit",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Close the applications whose data you intend to clean.",
      "Select specific cleaners and use Preview to inspect affected files.",
      "Clean only approved items; avoid saved passwords and recovery evidence."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ]
  },
  {
    "id": "easeus-drw",
    "name": "EaseUS Data Recovery Wizard",
    "developer": "EaseUS",
    "description": "EaseUS Data Recovery Wizard product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Data Recovery Wizard",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "Data Recovery Wizard"
    ],
    "useCases": [
      "EaseUS Data Recovery Wizard product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/datarecoverywizard/free-data-recovery-software.htm",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/datarecoverywizard/free-data-recovery-software.htm",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-drw",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-drw-mac",
    "name": "EaseUS Data Recovery Wizard for Mac",
    "developer": "EaseUS",
    "description": "EaseUS Data Recovery Wizard for Mac product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Data Recovery Wizard for Mac",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "Data Recovery Wizard for Mac"
    ],
    "useCases": [
      "EaseUS Data Recovery Wizard for Mac product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/mac-data-recovery-software/drw-mac-free.htm",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/mac-data-recovery-software/drw-mac-free.htm",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-drw-mac",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-partition-mac",
    "name": "EaseUS Partition Master for Mac",
    "developer": "EaseUS",
    "description": "EaseUS Partition Master for Mac product and edition reference.",
    "categories": [
      "Disk & Partition",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Partition Master for Mac",
      "Disk & Partition",
      "vendor software",
      "EaseUS",
      "Partition Master for Mac"
    ],
    "useCases": [
      "EaseUS Partition Master for Mac product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/partition-manager/disk-partition-manager-for-mac.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/partition-manager/disk-partition-manager-for-mac.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-partition-mac",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-todo-backup",
    "name": "EaseUS Todo Backup (Free / Home / Enterprise)",
    "developer": "EaseUS",
    "description": "EaseUS Todo Backup (Free / Home / Enterprise) product and edition reference.",
    "categories": [
      "Imaging & Cloning",
      "Licensed Tools",
      "Backup & Sync"
    ],
    "tags": [
      "EaseUS Todo Backup (Free / Home / Enterprise)",
      "Imaging & Cloning",
      "vendor software",
      "EaseUS",
      "Todo Backup (Free / Home / Enterprise)"
    ],
    "useCases": [
      "EaseUS Todo Backup (Free / Home / Enterprise) product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/backup-software/tb-enterprise.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/backup-software/tb-enterprise.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-todo-backup",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Identify source and destination by model, capacity and serial number.",
      "Select the backup or clone operation and review every disk that will be overwritten.",
      "Verify the resulting image or cloned boot before reusing the original drive."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-todo-backup-mac",
    "name": "EaseUS Todo Backup for Mac",
    "developer": "EaseUS",
    "description": "EaseUS Todo Backup for Mac product and edition reference.",
    "categories": [
      "Imaging & Cloning",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Todo Backup for Mac",
      "Imaging & Cloning",
      "vendor software",
      "EaseUS",
      "Todo Backup for Mac"
    ],
    "useCases": [
      "EaseUS Todo Backup for Mac product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/backup-software/todo-backup-mac.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/backup-software/todo-backup-mac.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-todo-backup-mac",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Identify source and destination by model, capacity and serial number.",
      "Select the backup or clone operation and review every disk that will be overwritten.",
      "Verify the resulting image or cloned boot before reusing the original drive."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-pctrans",
    "name": "EaseUS Todo PCTrans (Free / Pro / Technician)",
    "developer": "EaseUS",
    "description": "EaseUS Todo PCTrans (Free / Pro / Technician) product and edition reference.",
    "categories": [
      "Software Installers",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Todo PCTrans (Free / Pro / Technician)",
      "Software Installers",
      "vendor software",
      "EaseUS",
      "Todo PCTrans (Free / Pro / Technician)"
    ],
    "useCases": [
      "EaseUS Todo PCTrans (Free / Pro / Technician) product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/pc-transfer-software/pctrans-technician.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/pc-transfer-software/pctrans-technician.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-pctrans",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-diskcopy",
    "name": "EaseUS Disk Copy (Pro / Technician)",
    "developer": "EaseUS",
    "description": "EaseUS Disk Copy (Pro / Technician) product and edition reference.",
    "categories": [
      "Imaging & Cloning",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Disk Copy (Pro / Technician)",
      "Imaging & Cloning",
      "vendor software",
      "EaseUS",
      "Disk Copy (Pro / Technician)"
    ],
    "useCases": [
      "EaseUS Disk Copy (Pro / Technician) product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/disk-copy/technician-edition/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/disk-copy/technician-edition/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-diskcopy",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "This operation can overwrite or erase data. Confirm ownership, backups, and the exact target before proceeding.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Identify source and destination by model, capacity and serial number.",
      "Select the backup or clone operation and review every disk that will be overwritten.",
      "Verify the resulting image or cloned boot before reusing the original drive."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-mobisaver",
    "name": "EaseUS MobiSaver for iOS",
    "developer": "EaseUS",
    "description": "EaseUS MobiSaver for iOS product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS MobiSaver for iOS",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "MobiSaver for iOS"
    ],
    "useCases": [
      "EaseUS MobiSaver for iOS product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/mobile-tool/free-iphone-data-recovery.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/mobile-tool/free-iphone-data-recovery.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-mobisaver",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-mobisaver-mac",
    "name": "EaseUS MobiSaver for Mac",
    "developer": "EaseUS",
    "description": "EaseUS MobiSaver for Mac product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS MobiSaver for Mac",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "MobiSaver for Mac"
    ],
    "useCases": [
      "EaseUS MobiSaver for Mac product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/mobile-tool/free-iphone-data-recovery-mac.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/mobile-tool/free-iphone-data-recovery-mac.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-mobisaver-mac",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-mobisaver-android",
    "name": "EaseUS MobiSaver for Android",
    "developer": "EaseUS",
    "description": "EaseUS MobiSaver for Android product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS MobiSaver for Android",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "MobiSaver for Android"
    ],
    "useCases": [
      "EaseUS MobiSaver for Android product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/android-data-recovery-software/free-android-data-recovery.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/android-data-recovery-software/free-android-data-recovery.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-mobisaver-android",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-mobisaver-app",
    "name": "EaseUS MobiSaver Android App",
    "developer": "EaseUS",
    "description": "EaseUS MobiSaver Android App product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS MobiSaver Android App",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "MobiSaver Android App"
    ],
    "useCases": [
      "EaseUS MobiSaver Android App product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Android"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/android-data-recovery-software/app-version.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/android-data-recovery-software/app-version.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-mobisaver-app",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-mobimover",
    "name": "EaseUS MobiMover",
    "developer": "EaseUS",
    "description": "EaseUS MobiMover product and edition reference.",
    "categories": [
      "Software Installers",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS MobiMover",
      "Software Installers",
      "vendor software",
      "EaseUS",
      "MobiMover"
    ],
    "useCases": [
      "EaseUS MobiMover product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://mobi.easeus.com/phone-transfer/mobimover-free.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://mobi.easeus.com/phone-transfer/mobimover-free.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-mobimover",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-mobiunlock",
    "name": "EaseUS MobiUnlock",
    "developer": "EaseUS",
    "description": "EaseUS MobiUnlock product and edition reference.",
    "categories": [
      "Account & OOBE",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS MobiUnlock",
      "Account & OOBE",
      "vendor software",
      "EaseUS",
      "MobiUnlock"
    ],
    "useCases": [
      "EaseUS MobiUnlock product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://mobi.easeus.com/unlock-iphone/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://mobi.easeus.com/unlock-iphone/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-mobiunlock",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "This operation can overwrite or erase data. Confirm ownership, backups, and the exact target before proceeding.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Confirm device ownership and review official account-recovery options first.",
      "Back up accessible data and read the vendor reset/erase limitations.",
      "Use only documented, authorized device recovery; this guide provides no activation-lock or authentication bypass steps."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-mobianygo",
    "name": "EaseUS MobiAnyGo",
    "developer": "EaseUS",
    "description": "EaseUS MobiAnyGo product and edition reference.",
    "categories": [
      "Software Installers",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS MobiAnyGo",
      "Software Installers",
      "vendor software",
      "EaseUS",
      "MobiAnyGo"
    ],
    "useCases": [
      "EaseUS MobiAnyGo product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://mobi.easeus.com/location-changer/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://mobi.easeus.com/location-changer/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-mobianygo",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-ringtone",
    "name": "EaseUS Ringtone Editor",
    "developer": "EaseUS",
    "description": "EaseUS Ringtone Editor product and edition reference.",
    "categories": [
      "Media",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Ringtone Editor",
      "Media",
      "vendor software",
      "EaseUS",
      "Ringtone Editor"
    ],
    "useCases": [
      "EaseUS Ringtone Editor product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://mobi.easeus.com/iphone-ringtone-maker/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://mobi.easeus.com/iphone-ringtone-maker/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-ringtone",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-recexperts",
    "name": "EaseUS RecExperts",
    "developer": "EaseUS",
    "description": "EaseUS RecExperts product and edition reference.",
    "categories": [
      "Media",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS RecExperts",
      "Media",
      "vendor software",
      "EaseUS",
      "RecExperts"
    ],
    "useCases": [
      "EaseUS RecExperts product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://recorder.easeus.com/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://recorder.easeus.com/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-recexperts",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-makemyaudio",
    "name": "EaseUS MakeMyAudio",
    "developer": "EaseUS",
    "description": "EaseUS MakeMyAudio product and edition reference.",
    "categories": [
      "Media",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS MakeMyAudio",
      "Media",
      "vendor software",
      "EaseUS",
      "MakeMyAudio"
    ],
    "useCases": [
      "EaseUS MakeMyAudio product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://multimedia.easeus.com/audio-tool/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://multimedia.easeus.com/audio-tool/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-makemyaudio",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-voicewave",
    "name": "EaseUS VoiceWave",
    "developer": "EaseUS",
    "description": "EaseUS VoiceWave product and edition reference.",
    "categories": [
      "Media",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS VoiceWave",
      "Media",
      "vendor software",
      "EaseUS",
      "VoiceWave"
    ],
    "useCases": [
      "EaseUS VoiceWave product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://multimedia.easeus.com/voice-changer/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://multimedia.easeus.com/voice-changer/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-voicewave",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-videoeditor",
    "name": "EaseUS Video Editor",
    "developer": "EaseUS",
    "description": "EaseUS Video Editor product and edition reference.",
    "categories": [
      "Media",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Video Editor",
      "Media",
      "vendor software",
      "EaseUS",
      "Video Editor"
    ],
    "useCases": [
      "EaseUS Video Editor product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://multimedia.easeus.com/video-editor/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://multimedia.easeus.com/video-editor/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-videoeditor",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-videokit",
    "name": "EaseUS VideFlow / VideoKit",
    "developer": "EaseUS",
    "description": "EaseUS VideFlow / VideoKit product and edition reference.",
    "categories": [
      "Media",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS VideFlow / VideoKit",
      "Media",
      "vendor software",
      "EaseUS",
      "VideFlow / VideoKit"
    ],
    "useCases": [
      "EaseUS VideFlow / VideoKit product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://multimedia.easeus.com/videokit/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://multimedia.easeus.com/videokit/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-videokit",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-videodownloader",
    "name": "EaseUS Video Downloader",
    "developer": "EaseUS",
    "description": "EaseUS Video Downloader product and edition reference.",
    "categories": [
      "Media",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Video Downloader",
      "Media",
      "vendor software",
      "EaseUS",
      "Video Downloader"
    ],
    "useCases": [
      "EaseUS Video Downloader product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://multimedia.easeus.com/video-downloader/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://multimedia.easeus.com/video-downloader/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-videodownloader",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-pdf",
    "name": "EaseUS PDF Editor",
    "developer": "EaseUS",
    "description": "EaseUS PDF Editor product and edition reference.",
    "categories": [
      "Office & PDF",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS PDF Editor",
      "Office & PDF",
      "vendor software",
      "EaseUS",
      "PDF Editor"
    ],
    "useCases": [
      "EaseUS PDF Editor product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://pdf.easeus.com/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://pdf.easeus.com/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-pdf",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-email",
    "name": "EaseUS Email Recovery Wizard",
    "developer": "EaseUS",
    "description": "EaseUS Email Recovery Wizard product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Email Recovery Wizard",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "Email Recovery Wizard"
    ],
    "useCases": [
      "EaseUS Email Recovery Wizard product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/emailrecoverywizard/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/emailrecoverywizard/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-email",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-exchange",
    "name": "EaseUS Exchange Recovery",
    "developer": "EaseUS",
    "description": "EaseUS Exchange Recovery product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Exchange Recovery",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "Exchange Recovery"
    ],
    "useCases": [
      "EaseUS Exchange Recovery product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/data-recovery-software/exchange-recovery.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/data-recovery-software/exchange-recovery.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-exchange",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-partitionrecovery",
    "name": "EaseUS Partition Recovery",
    "developer": "EaseUS",
    "description": "EaseUS Partition Recovery product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Partition Recovery",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "Partition Recovery"
    ],
    "useCases": [
      "EaseUS Partition Recovery product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/partition-recovery/index.htm",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/partition-recovery/index.htm",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-partitionrecovery",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "This operation can overwrite or erase data. Confirm ownership, backups, and the exact target before proceeding.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-sql",
    "name": "EaseUS MS SQL Recovery",
    "developer": "EaseUS",
    "description": "EaseUS MS SQL Recovery product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS MS SQL Recovery",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "MS SQL Recovery"
    ],
    "useCases": [
      "EaseUS MS SQL Recovery product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/data-recovery-software/ms-sql-recovery.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/data-recovery-software/ms-sql-recovery.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-sql",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-lockmyfile",
    "name": "EaseUS LockMyFile",
    "developer": "EaseUS",
    "description": "EaseUS LockMyFile product and edition reference.",
    "categories": [
      "Malware & Security",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS LockMyFile",
      "Malware & Security",
      "vendor software",
      "EaseUS",
      "LockMyFile"
    ],
    "useCases": [
      "EaseUS LockMyFile product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://toolbox.easeus.com/file-lock/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://toolbox.easeus.com/file-lock/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-lockmyfile",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-os2go",
    "name": "EaseUS OS2Go",
    "developer": "EaseUS",
    "description": "EaseUS OS2Go product and edition reference.",
    "categories": [
      "USB Tools",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS OS2Go",
      "USB Tools",
      "vendor software",
      "EaseUS",
      "OS2Go"
    ],
    "useCases": [
      "EaseUS OS2Go product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/utilities/ostogo.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/utilities/ostogo.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-os2go",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "This operation can overwrite or erase data. Confirm ownership, backups, and the exact target before proceeding.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-ntfs",
    "name": "EaseUS NTFS for Mac",
    "developer": "EaseUS",
    "description": "EaseUS NTFS for Mac product and edition reference.",
    "categories": [
      "Disk & Partition",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS NTFS for Mac",
      "Disk & Partition",
      "vendor software",
      "EaseUS",
      "NTFS for Mac"
    ],
    "useCases": [
      "EaseUS NTFS for Mac product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/all-products.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/all-products.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-ntfs",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-keyfinder",
    "name": "EaseUS Key Finder",
    "developer": "EaseUS",
    "description": "EaseUS Key Finder product and edition reference.",
    "categories": [
      "Licensed Tools",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Key Finder",
      "Licensed Tools",
      "vendor software",
      "EaseUS",
      "Key Finder"
    ],
    "useCases": [
      "EaseUS Key Finder product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/key-finder/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/key-finder/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-keyfinder",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-bitwiper",
    "name": "EaseUS BitWiper",
    "developer": "EaseUS",
    "description": "EaseUS BitWiper product and edition reference.",
    "categories": [
      "Disk & Partition",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS BitWiper",
      "Disk & Partition",
      "vendor software",
      "EaseUS",
      "BitWiper"
    ],
    "useCases": [
      "EaseUS BitWiper product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://toolbox.easeus.com/bitwiper/index.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://toolbox.easeus.com/bitwiper/index.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-bitwiper",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "This operation can overwrite or erase data. Confirm ownership, backups, and the exact target before proceeding.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Confirm that the owner authorized permanent data destruction.",
      "Disconnect unrelated drives and verify the target serial number against the work order.",
      "Select the supported erase method and verify the result; erasure is irreversible."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-duplicates",
    "name": "EaseUS DupFiles Cleaner",
    "developer": "EaseUS",
    "description": "EaseUS DupFiles Cleaner product and edition reference.",
    "categories": [
      "Windows Privacy",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS DupFiles Cleaner",
      "Windows Privacy",
      "vendor software",
      "EaseUS",
      "DupFiles Cleaner"
    ],
    "useCases": [
      "EaseUS DupFiles Cleaner product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/all-products.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/all-products.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-duplicates",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-driverhandy",
    "name": "EaseUS DriverHandy",
    "developer": "EaseUS",
    "description": "EaseUS DriverHandy product and edition reference.",
    "categories": [
      "Drivers",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS DriverHandy",
      "Drivers",
      "vendor software",
      "EaseUS",
      "DriverHandy"
    ],
    "useCases": [
      "EaseUS DriverHandy product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://toolbox.easeus.com/driver-handy/index.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://toolbox.easeus.com/driver-handy/index.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-driverhandy",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-everysync",
    "name": "EaseUS EverySync",
    "developer": "EaseUS",
    "description": "EaseUS EverySync product and edition reference.",
    "categories": [
      "Networking",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS EverySync",
      "Networking",
      "vendor software",
      "EaseUS",
      "EverySync",
      "network",
      "network tools"
    ],
    "useCases": [
      "EaseUS EverySync product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/file-sync/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/file-sync/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-everysync",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-chattrans",
    "name": "EaseUS ChatTrans",
    "developer": "EaseUS",
    "description": "EaseUS ChatTrans product and edition reference.",
    "categories": [
      "Software Installers",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS ChatTrans",
      "Software Installers",
      "vendor software",
      "EaseUS",
      "ChatTrans"
    ],
    "useCases": [
      "EaseUS ChatTrans product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://mobi.easeus.com/chat-transfer/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://mobi.easeus.com/chat-transfer/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-chattrans",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-winrescuer",
    "name": "EaseUS WinRescuer",
    "developer": "EaseUS",
    "description": "EaseUS WinRescuer product and edition reference.",
    "categories": [
      "Windows Repair",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS WinRescuer",
      "Windows Repair",
      "vendor software",
      "EaseUS",
      "WinRescuer"
    ],
    "useCases": [
      "EaseUS WinRescuer product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/boot-repair/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/boot-repair/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-winrescuer",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "This operation can overwrite or erase data. Confirm ownership, backups, and the exact target before proceeding.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-fixo",
    "name": "EaseUS Fixo",
    "developer": "EaseUS",
    "description": "EaseUS Fixo product and edition reference.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Fixo",
      "Data Recovery",
      "vendor software",
      "EaseUS",
      "Fixo"
    ],
    "useCases": [
      "EaseUS Fixo product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/repair-tools/",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/repair-tools/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-fixo",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Stop writing to the affected storage or database; work from an image or backup where possible.",
      "Choose the source and scan or repair a copy, then preview the recoverable output.",
      "Save recovered files to separate healthy storage and validate them before restoring service."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-cleangenius",
    "name": "EaseUS CleanGenius",
    "developer": "EaseUS",
    "description": "EaseUS CleanGenius product and edition reference.",
    "categories": [
      "Windows Privacy",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS CleanGenius",
      "Windows Privacy",
      "vendor software",
      "EaseUS",
      "CleanGenius"
    ],
    "useCases": [
      "EaseUS CleanGenius product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.easeus.com/all-products.html",
    "officialDownload": "https://www.easeus.com/download.htm",
    "documentation": "https://www.easeus.com/all-products.html",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-cleangenius",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.apk"
    ],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "easeus-vocalremover",
    "name": "EaseUS Vocal Remover Online",
    "developer": "EaseUS",
    "description": "EaseUS Vocal Remover Online product and edition reference.",
    "categories": [
      "Media",
      "Licensed Tools"
    ],
    "tags": [
      "EaseUS Vocal Remover Online",
      "Media",
      "vendor software",
      "EaseUS",
      "Vocal Remover Online"
    ],
    "useCases": [
      "EaseUS Vocal Remover Online product and edition reference."
    ],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Proprietary software. Free tiers, trials and paid features depend on the selected edition.",
    "technicianLicenseNotes": "Check business/technician licensing; a personal free edition is not a technician license.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Browser"
    ],
    "architecture": [
      "Choose the publisher build for your OS and CPU"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://vocalremover.easeus.com/",
    "officialDownload": "https://vocalremover.easeus.com/",
    "documentation": "https://vocalremover.easeus.com/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS/easeus-vocalremover",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Online",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review the selected operation and keep a backup of affected data.",
    "notes": "Select the OS and license edition on the publisher page. Downloaded packages are not automatically installed.",
    "sourceStatus": "Official product source reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {},
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification.",
    "quickStart": [
      "Choose the appropriate platform and Free, trial, paid or technician edition on the official product page.",
      "Work on a backup or test copy first; review the selected input and output before starting.",
      "Follow the product documentation for the operation and verify the result before replacing original files."
    ],
    "packagePatterns": [],
    "editions": "Select Free / trial / Pro / business / technician as offered by this product; licenses differ."
  },
  {
    "id": "foldersize",
    "name": "Folder Size (MindGems)",
    "developer": "MindGems",
    "description": "Disk and folder usage analysis; identify large files before choosing what to clean.",
    "categories": [
      "Storage Diagnostics",
      "Portable Apps"
    ],
    "tags": [
      "folder size",
      "foldersize",
      "disk usage",
      "space analyzer"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free / paid options",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.mindgems.com/products/Folder-Size/Folder-Size.html",
    "officialDownload": "https://www.mindgems.com/products/Folder-Size/Folder-Size.html",
    "documentation": "https://www.mindgems.com/products/Folder-Size/Folder-Size.html",
    "localFolder": "20_PORTABLE_APPS/Storage-Diagnostics/foldersize",
    "localExecutable": "",
    "inventoryPatterns": [
      "FolderSize.exe",
      "FolderSize*.exe"
    ],
    "packagePatterns": [
      "foldersize*.zip",
      "foldersize*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Choose a drive or folder to scan.",
      "Sort by size and inspect large folders.",
      "Review contents and backups before deleting anything."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.mindgems.com/products/Folder-Size/Folder-Size.html",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.mindgems.com/products/Folder-Size/Folder-Size.html"
  },
  {
    "id": "windirstat",
    "name": "WinDirStat",
    "developer": "WinDirStat contributors",
    "description": "Open-source disk usage visualizer and large-file investigation.",
    "categories": [
      "Storage Diagnostics",
      "Portable Apps"
    ],
    "tags": [],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://windirstat.net/",
    "officialDownload": "https://windirstat.net/",
    "documentation": "https://github.com/windirstat/windirstat",
    "localFolder": "20_PORTABLE_APPS/Storage-Diagnostics/windirstat",
    "localExecutable": "",
    "inventoryPatterns": [
      "WinDirStat*.exe"
    ],
    "packagePatterns": [
      "windirstat*.zip",
      "windirstat*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Select the drive to analyze.",
      "Use the treemap to locate large files.",
      "Open and review the containing folder before cleanup."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://github.com/windirstat/windirstat",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://windirstat.net/"
  },
  {
    "id": "sharex",
    "name": "ShareX",
    "developer": "ShareX Team",
    "description": "Screen capture, recording, annotation and configurable capture workflows.",
    "categories": [
      "Media",
      "Portable Apps"
    ],
    "tags": [
      "screenshot",
      "screen capture",
      "sharex"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://getsharex.com/downloads.html",
    "officialDownload": "https://getsharex.com/downloads.html",
    "documentation": "https://getsharex.com/docs",
    "localFolder": "20_PORTABLE_APPS/Media/sharex",
    "localExecutable": "",
    "inventoryPatterns": [
      "ShareX.exe"
    ],
    "packagePatterns": [
      "sharex*.zip",
      "sharex*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Choose Capture → Region for a screenshot.",
      "Annotate or save the result locally.",
      "Review after-capture and upload tasks before capturing customer data."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://getsharex.com/docs",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://getsharex.com/downloads.html"
  },
  {
    "id": "jdownloader",
    "name": "JDownloader 2",
    "developer": "AppWork / JDownloader",
    "description": "Download manager with queues, link collection and publisher-specific plugins.",
    "categories": [
      "Networking",
      "Software Installers"
    ],
    "tags": [
      "jdownload",
      "jdownloader",
      "download manager",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://jdownloader.org/download/index",
    "officialDownload": "https://jdownloader.org/download/index",
    "documentation": "https://support.jdownloader.org/knowledgebase",
    "localFolder": "40_INSTALLERS/Networking/jdownloader",
    "localExecutable": "",
    "inventoryPatterns": [
      "JDownloader2.exe",
      "JDownloader*.exe"
    ],
    "packagePatterns": [
      "jdownloader*.zip",
      "jdownloader*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Use the current installer linked by the official site.",
      "Set the download directory before adding links to LinkGrabber.",
      "Review the queue and select Start downloads; some hosts require accounts."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://support.jdownloader.org/knowledgebase",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://jdownloader.org/download/index"
  },
  {
    "id": "powertoys",
    "name": "Microsoft PowerToys",
    "developer": "Microsoft",
    "description": "Windows productivity utilities including FancyZones, PowerRename and keyboard tools.",
    "categories": [
      "Windows Tweaks",
      "Software Installers"
    ],
    "tags": [
      "power toys",
      "powertoys",
      "window layout",
      "bulk rename"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://github.com/microsoft/PowerToys/releases",
    "officialDownload": "https://github.com/microsoft/PowerToys/releases",
    "documentation": "https://learn.microsoft.com/en-us/windows/powertoys/",
    "localFolder": "40_INSTALLERS/Windows-Tweaks/powertoys",
    "localExecutable": "",
    "inventoryPatterns": [
      "PowerToys.exe",
      "PowerToys*Setup*.exe"
    ],
    "packagePatterns": [
      "powertoys*.zip",
      "powertoys*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Install the architecture matching this PC.",
      "Open PowerToys Settings and enable only the utilities you need.",
      "Preview PowerRename changes before applying them."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://learn.microsoft.com/en-us/windows/powertoys/",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://github.com/microsoft/PowerToys/releases"
  },
  {
    "id": "sublime",
    "name": "Sublime Text",
    "developer": "Sublime HQ",
    "description": "Text and code editor with evaluation downloads; continued use requires a license.",
    "categories": [
      "Developer Tools",
      "Portable Apps"
    ],
    "tags": [
      "sublime text",
      "editor"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free / trial / paid",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.sublimetext.com/download",
    "officialDownload": "https://www.sublimetext.com/download",
    "documentation": "https://www.sublimetext.com/docs/",
    "localFolder": "20_PORTABLE_APPS/Developer-Tools/sublime",
    "localExecutable": "",
    "inventoryPatterns": [
      "sublime_text.exe",
      "sublime_text*.exe"
    ],
    "packagePatterns": [
      "sublime*.zip",
      "sublime*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Choose the installer or portable archive for your platform.",
      "Open a folder or file and use the command palette.",
      "Purchase a license for continued use after evaluation."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.sublimetext.com/docs/",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.sublimetext.com/download"
  },
  {
    "id": "brave",
    "name": "Brave Browser",
    "developer": "Brave Software",
    "description": "Chromium-based browser with built-in Shields for blocking ads and trackers.",
    "categories": [
      "Browsers",
      "Software Installers"
    ],
    "tags": [],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://brave.com/download/",
    "officialDownload": "https://brave.com/download/",
    "documentation": "https://support.brave.com/",
    "localFolder": "40_INSTALLERS/Browsers/brave",
    "localExecutable": "",
    "inventoryPatterns": [
      "brave.exe",
      "BraveBrowser*Setup*.exe"
    ],
    "packagePatterns": [
      "brave*.zip",
      "brave*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Download and install the correct platform build.",
      "Use a separate profile for technician work.",
      "Review Shields per site if a legitimate page fails to load."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://support.brave.com/",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://brave.com/download/"
  },
  {
    "id": "chromium",
    "name": "Chromium",
    "developer": "The Chromium Authors",
    "description": "Upstream Chromium browser builds for testing; downloaded snapshots do not auto-update.",
    "categories": [
      "Browsers",
      "Developer Tools"
    ],
    "tags": [
      "chromium",
      "browser testing"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.chromium.org/getting-involved/download-chromium/",
    "officialDownload": "https://www.chromium.org/getting-involved/download-chromium/",
    "documentation": "https://www.chromium.org/getting-involved/download-chromium/",
    "localFolder": "20_PORTABLE_APPS/Browsers/chromium",
    "localExecutable": "",
    "inventoryPatterns": [
      "chrome.exe",
      "chromium.exe",
      "chrome-win*.zip"
    ],
    "packagePatterns": [
      "chromium*.zip",
      "chromium*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Choose the platform using the official Chromium build instructions.",
      "Extract the build and keep its application files together.",
      "Refresh snapshots manually; distinguish Chromium from Chrome for Testing."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.chromium.org/getting-involved/download-chromium/",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.chromium.org/getting-involved/download-chromium/"
  },
  {
    "id": "platform-tools",
    "name": "Android SDK Platform-Tools (ADB & Fastboot)",
    "developer": "Google / Android Open Source Project",
    "description": "Command-line Android debugging, device communication and model-specific fastboot operations.",
    "categories": [
      "Phone & Tablet",
      "Developer Tools"
    ],
    "tags": [
      "phone debug",
      "android",
      "adb",
      "fastboot",
      "flash",
      "firmware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://developer.android.com/tools/releases/platform-tools",
    "officialDownload": "https://developer.android.com/tools/releases/platform-tools",
    "documentation": "https://developer.android.com/tools/adb",
    "localFolder": "20_PORTABLE_APPS/Phone-Tablet/platform-tools",
    "localExecutable": "",
    "inventoryPatterns": [
      "adb.exe",
      "fastboot.exe",
      "adb",
      "fastboot"
    ],
    "packagePatterns": [
      "platform-tools*.zip",
      "platform-tools*.exe"
    ],
    "kind": "Command-line",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Flashing, unlocking, resetting or restoring can erase data or disable the device. Confirm the exact model, back up data and review the vendor procedure.",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Extract the platform-tools directory for your computer OS.",
      "Enable USB debugging on the phone and approve this computer’s RSA prompt.",
      "From that directory run adb devices; follow official documentation for debugging or fastboot operations."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://developer.android.com/tools/adb",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://developer.android.com/tools/releases/platform-tools"
  },
  {
    "id": "scrcpy",
    "name": "scrcpy",
    "developer": "Genymobile",
    "description": "Display and control an authorized Android phone over USB or supported network connections.",
    "categories": [
      "Phone & Tablet",
      "Remote Support"
    ],
    "tags": [
      "phone debug",
      "android mirror",
      "screen mirror"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://github.com/Genymobile/scrcpy/releases",
    "officialDownload": "https://github.com/Genymobile/scrcpy/releases",
    "documentation": "https://github.com/Genymobile/scrcpy/tree/master/doc",
    "localFolder": "20_PORTABLE_APPS/Phone-Tablet/scrcpy",
    "localExecutable": "",
    "inventoryPatterns": [
      "scrcpy.exe"
    ],
    "packagePatterns": [
      "scrcpy*.zip",
      "scrcpy*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Extract the complete release package.",
      "Enable USB debugging and approve the phone’s authorization prompt.",
      "Run scrcpy to mirror the phone; see official options for recording and connection modes."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://github.com/Genymobile/scrcpy/tree/master/doc",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://github.com/Genymobile/scrcpy/releases"
  },
  {
    "id": "android-flash",
    "name": "Android Flash Tool",
    "developer": "Google / Android Open Source Project",
    "description": "Browser-based flashing for supported Android devices, including supported Pixel models.",
    "categories": [
      "Phone & Tablet",
      "Firmware"
    ],
    "tags": [
      "phone flash",
      "firmware flashing",
      "pixel",
      "android recovery"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://flash.android.com/",
    "officialDownload": "https://flash.android.com/",
    "documentation": "https://source.android.com/docs/setup/test/flash",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "packagePatterns": [
      "android-flash*.zip",
      "android-flash*.exe"
    ],
    "kind": "Online",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Flashing, unlocking, resetting or restoring can erase data or disable the device. Confirm the exact model, back up data and review the vendor procedure.",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Confirm that the exact device is supported and back up its data.",
      "Follow Google’s USB, browser and bootloader prerequisites.",
      "Select the intended build and review all erase/unlock prompts before flashing."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://source.android.com/docs/setup/test/flash",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://flash.android.com/"
  },
  {
    "id": "google-usb-driver",
    "name": "Google USB Driver",
    "developer": "Google",
    "description": "Windows USB driver for supported Google Android development devices.",
    "categories": [
      "Phone & Tablet",
      "Drivers"
    ],
    "tags": [
      "adb driver",
      "phone debug",
      "android usb"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://developer.android.com/studio/run/win-usb",
    "officialDownload": "https://developer.android.com/studio/run/win-usb",
    "documentation": "https://developer.android.com/studio/run/win-usb",
    "localFolder": "30_DRIVERS/Phone-Tablet/google-usb-driver",
    "localExecutable": "",
    "inventoryPatterns": [
      "android_winusb.inf"
    ],
    "packagePatterns": [
      "google-usb-driver*.zip",
      "google-usb-driver*.exe"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Confirm that the device uses Google’s USB driver.",
      "Download the official package and follow Device Manager instructions.",
      "Reconnect the device and verify it with adb devices."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://developer.android.com/studio/run/win-usb",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://developer.android.com/studio/run/win-usb"
  },
  {
    "id": "samsung-smartswitch",
    "name": "Samsung Smart Switch",
    "developer": "Samsung",
    "description": "Samsung device data transfer, backup and restore using supported desktop and phone workflows.",
    "categories": [
      "Phone & Tablet",
      "Imaging & Cloning"
    ],
    "tags": [
      "samsung",
      "phone backup",
      "phone migration"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.samsung.com/us/apps/smart-switch/",
    "officialDownload": "https://www.samsung.com/us/apps/smart-switch/",
    "documentation": "https://www.samsung.com/us/apps/smart-switch/",
    "localFolder": "40_INSTALLERS/Phone-Tablet/samsung-smartswitch",
    "localExecutable": "",
    "inventoryPatterns": [
      "SmartSwitchPC.exe",
      "SmartSwitch*.exe"
    ],
    "packagePatterns": [
      "samsung-smartswitch*.zip",
      "samsung-smartswitch*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Check device and desktop compatibility on Samsung’s page.",
      "Connect and unlock the phone, then approve the requested access.",
      "Create and verify a backup before restore or migration."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.samsung.com/us/apps/smart-switch/",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.samsung.com/us/apps/smart-switch/"
  },
  {
    "id": "libimobiledevice",
    "name": "libimobiledevice",
    "developer": "libimobiledevice contributors",
    "description": "Command-line libraries and tools for communicating with authorized iOS devices.",
    "categories": [
      "Phone & Tablet",
      "Developer Tools"
    ],
    "tags": [
      "iphone",
      "ios",
      "phone debug"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux",
      "macOS",
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://libimobiledevice.org/",
    "officialDownload": "https://libimobiledevice.org/",
    "documentation": "https://docs.libimobiledevice.org/",
    "localFolder": "20_PORTABLE_APPS/Phone-Tablet/libimobiledevice",
    "localExecutable": "",
    "inventoryPatterns": [],
    "packagePatterns": [
      "libimobiledevice*.zip",
      "libimobiledevice*.exe"
    ],
    "kind": "Command-line",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Install packages for your OS using the project’s instructions.",
      "Unlock the device and approve Trust This Computer.",
      "Use the documented device-information tools before backup or restore operations."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://docs.libimobiledevice.org/",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://libimobiledevice.org/"
  },
  {
    "id": "naps2",
    "name": "NAPS2",
    "developer": "NAPS2 contributors",
    "description": "Document scanning to PDF/images with profiles, OCR and documented command-line support.",
    "categories": [
      "Printers & Scanners",
      "Office & PDF"
    ],
    "tags": [
      "printer",
      "scanner",
      "scan pdf",
      "ocr"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.naps2.com/download",
    "officialDownload": "https://www.naps2.com/download",
    "documentation": "https://www.naps2.com/doc",
    "localFolder": "20_PORTABLE_APPS/Printers-Scanners/naps2",
    "localExecutable": "",
    "inventoryPatterns": [
      "NAPS2.exe",
      "naps2*.exe"
    ],
    "packagePatterns": [
      "naps2*.zip",
      "naps2*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Create a scan profile and select the correct scanner/driver.",
      "Scan one test page, then check resolution, color and page order.",
      "Save the document; use the official command-line guide for repeatable jobs."
    ],
    "automationSupport": {
      "level": "documented",
      "source": "https://www.naps2.com/doc/command-line",
      "notes": "Use named scan profiles and the documented console interface."
    },
    "licenseSource": "https://www.naps2.com/download"
  },
  {
    "id": "cups",
    "name": "CUPS / OpenPrinting",
    "developer": "OpenPrinting",
    "description": "Linux and Unix printing administration, queues and driverless IPP printing.",
    "categories": [
      "Printers & Scanners",
      "Homelab / Linux"
    ],
    "tags": [
      "printer",
      "print queue",
      "ipp",
      "cups"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://openprinting.github.io/cups/",
    "officialDownload": "https://openprinting.github.io/cups/",
    "documentation": "https://openprinting.github.io/documentation/05-User-Manual",
    "localFolder": "20_PORTABLE_APPS/Printers-Scanners/cups",
    "localExecutable": "",
    "inventoryPatterns": [],
    "packagePatterns": [
      "cups*.zip",
      "cups*.exe"
    ],
    "kind": "Command-line",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Install your distribution’s CUPS packages and printer administration tools.",
      "Inspect printer and queue status with lpstat.",
      "Add a supported IPP printer or matching driver and print a test page."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://openprinting.github.io/documentation/05-User-Manual",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://openprinting.github.io/cups/"
  },
  {
    "id": "hp-printer",
    "name": "HP Printer Drivers",
    "developer": "HP",
    "description": "Model-specific printer/scanner drivers and publisher support utilities.",
    "categories": [
      "Printers & Scanners",
      "Drivers"
    ],
    "tags": [
      "printer drivers",
      "scanner drivers"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://support.hp.com/us-en/drivers/printers",
    "officialDownload": "https://support.hp.com/us-en/drivers/printers",
    "documentation": "https://support.hp.com/us-en/drivers/printers",
    "localFolder": "30_DRIVERS/Printers-Scanners/hp-printer",
    "localExecutable": "",
    "inventoryPatterns": [],
    "packagePatterns": [
      "hp-printer*.zip",
      "hp-printer*.exe"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Identify the exact printer/scanner model and OS version.",
      "Select the matching driver or utility from the publisher.",
      "Install according to its instructions, then test printing and scanning separately."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://support.hp.com/us-en/drivers/printers",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://support.hp.com/us-en/drivers/printers"
  },
  {
    "id": "brother-printer",
    "name": "Brother Printer & Scanner Support",
    "developer": "Brother",
    "description": "Model-specific printer/scanner drivers and publisher support utilities.",
    "categories": [
      "Printers & Scanners",
      "Drivers"
    ],
    "tags": [
      "printer drivers",
      "scanner drivers"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://support.brother.com/",
    "officialDownload": "https://support.brother.com/",
    "documentation": "https://support.brother.com/",
    "localFolder": "30_DRIVERS/Printers-Scanners/brother-printer",
    "localExecutable": "",
    "inventoryPatterns": [],
    "packagePatterns": [
      "brother-printer*.zip",
      "brother-printer*.exe"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Identify the exact printer/scanner model and OS version.",
      "Select the matching driver or utility from the publisher.",
      "Install according to its instructions, then test printing and scanning separately."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://support.brother.com/",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://support.brother.com/"
  },
  {
    "id": "epson-printer",
    "name": "Epson Printer & Scanner Support",
    "developer": "Epson",
    "description": "Model-specific printer/scanner drivers and publisher support utilities.",
    "categories": [
      "Printers & Scanners",
      "Drivers"
    ],
    "tags": [
      "printer drivers",
      "scanner drivers"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://epson.com/Support/sl/s",
    "officialDownload": "https://epson.com/Support/sl/s",
    "documentation": "https://epson.com/Support/sl/s",
    "localFolder": "30_DRIVERS/Printers-Scanners/epson-printer",
    "localExecutable": "",
    "inventoryPatterns": [],
    "packagePatterns": [
      "epson-printer*.zip",
      "epson-printer*.exe"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Identify the exact printer/scanner model and OS version.",
      "Select the matching driver or utility from the publisher.",
      "Install according to its instructions, then test printing and scanning separately."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://epson.com/Support/sl/s",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://epson.com/Support/sl/s"
  },
  {
    "id": "canon-printer",
    "name": "Canon Printer & Scanner Support",
    "developer": "Canon",
    "description": "Model-specific printer/scanner drivers and publisher support utilities.",
    "categories": [
      "Printers & Scanners",
      "Drivers"
    ],
    "tags": [
      "printer drivers",
      "scanner drivers"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.usa.canon.com/support",
    "officialDownload": "https://www.usa.canon.com/support",
    "documentation": "https://www.usa.canon.com/support",
    "localFolder": "30_DRIVERS/Printers-Scanners/canon-printer",
    "localExecutable": "",
    "inventoryPatterns": [],
    "packagePatterns": [
      "canon-printer*.zip",
      "canon-printer*.exe"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Identify the exact printer/scanner model and OS version.",
      "Select the matching driver or utility from the publisher.",
      "Install according to its instructions, then test printing and scanning separately."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.usa.canon.com/support",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.usa.canon.com/support"
  },
  {
    "id": "wifiinfoview",
    "name": "WifiInfoView",
    "developer": "NirSoft",
    "description": "View nearby wireless networks, channels and signal information.",
    "categories": [
      "Wi-Fi Tools",
      "Networking"
    ],
    "tags": [
      "wifi",
      "wi-fi",
      "wireless",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.nirsoft.net/utils/wifi_information_view.html",
    "officialDownload": "https://www.nirsoft.net/utils/wifi_information_view.html",
    "documentation": "https://www.nirsoft.net/utils/wifi_information_view.html",
    "localFolder": "20_PORTABLE_APPS/Wi-Fi-Tools/wifiinfoview",
    "localExecutable": "",
    "inventoryPatterns": [
      "WifiInfoView.exe"
    ],
    "packagePatterns": [
      "wifiinfoview*.zip",
      "wifiinfoview*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Extract the package and run WifiInfoView.",
      "Compare signal and channel usage near the affected PC.",
      "Use findings to review access-point placement/channel settings."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.nirsoft.net/utils/wifi_information_view.html",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.nirsoft.net/utils/wifi_information_view.html"
  },
  {
    "id": "wifidiagnostics",
    "name": "WifiDiagnosticsView",
    "developer": "NirSoft",
    "description": "Monitor Windows Wi-Fi connection and disconnection events.",
    "categories": [
      "Wi-Fi Tools",
      "Networking"
    ],
    "tags": [
      "wifi",
      "wi-fi",
      "wireless",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.nirsoft.net/utils/wifi_diagnostics_view.html",
    "officialDownload": "https://www.nirsoft.net/utils/wifi_diagnostics_view.html",
    "documentation": "https://www.nirsoft.net/utils/wifi_diagnostics_view.html",
    "localFolder": "20_PORTABLE_APPS/Wi-Fi-Tools/wifidiagnostics",
    "localExecutable": "",
    "inventoryPatterns": [
      "WifiDiagnosticsView.exe"
    ],
    "packagePatterns": [
      "wifidiagnostics*.zip",
      "wifidiagnostics*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Run the tool on the affected Windows PC.",
      "Reproduce the connection problem while monitoring events.",
      "Save the relevant event list with timestamps for troubleshooting."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.nirsoft.net/utils/wifi_diagnostics_view.html",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.nirsoft.net/utils/wifi_diagnostics_view.html"
  },
  {
    "id": "wirelesswatcher",
    "name": "Wireless Network Watcher",
    "developer": "NirSoft",
    "description": "Discover devices on the connected network for local inventory.",
    "categories": [
      "Wi-Fi Tools",
      "Networking"
    ],
    "tags": [
      "network diagnostics",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.nirsoft.net/utils/wireless_network_watcher.html",
    "officialDownload": "https://www.nirsoft.net/utils/wireless_network_watcher.html",
    "documentation": "https://www.nirsoft.net/utils/wireless_network_watcher.html",
    "localFolder": "20_PORTABLE_APPS/Wi-Fi-Tools/wirelesswatcher",
    "localExecutable": "",
    "inventoryPatterns": [
      "WNetWatcher.exe"
    ],
    "packagePatterns": [
      "wirelesswatcher*.zip",
      "wirelesswatcher*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Select the active network adapter.",
      "Scan a network you administer and compare detected devices with inventory.",
      "Treat device names and vendor labels as clues, not proof of identity."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.nirsoft.net/utils/wireless_network_watcher.html",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.nirsoft.net/utils/wireless_network_watcher.html"
  },
  {
    "id": "currports",
    "name": "CurrPorts",
    "developer": "NirSoft",
    "description": "Inspect open TCP/UDP ports and their owning Windows processes.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "network diagnostics",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.nirsoft.net/utils/cports.html",
    "officialDownload": "https://www.nirsoft.net/utils/cports.html",
    "documentation": "https://www.nirsoft.net/utils/cports.html",
    "localFolder": "20_PORTABLE_APPS/Networking/currports",
    "localExecutable": "",
    "inventoryPatterns": [
      "cports.exe"
    ],
    "packagePatterns": [
      "currports*.zip",
      "currports*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Run CurrPorts and sort by process or port.",
      "Correlate unexpected connections with the application and destination.",
      "Export findings; review before closing connections or processes."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.nirsoft.net/utils/cports.html",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.nirsoft.net/utils/cports.html"
  },
  {
    "id": "networklatency",
    "name": "NetworkLatencyView",
    "developer": "NirSoft",
    "description": "Measure observed TCP connection latency with supported packet capture.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "network diagnostics",
      "network",
      "network tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Use the publisher’s license for the selected edition.",
    "technicianLicenseNotes": "Check commercial-service and redistribution terms before using on customer systems.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.nirsoft.net/utils/network_latency_view.html",
    "officialDownload": "https://www.nirsoft.net/utils/network_latency_view.html",
    "documentation": "https://www.nirsoft.net/utils/network_latency_view.html",
    "localFolder": "20_PORTABLE_APPS/Networking/networklatency",
    "localExecutable": "",
    "inventoryPatterns": [
      "NetworkLatencyView.exe"
    ],
    "packagePatterns": [
      "networklatency*.zip",
      "networklatency*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official source linked; download availability is tracked separately",
    "command": "",
    "defaultFavorite": false,
    "quickStart": [
      "Read the capture-driver and permissions prerequisites.",
      "Choose the adapter and reproduce the affected traffic.",
      "Compare latency across destinations and export the relevant samples."
    ],
    "automationSupport": {
      "level": "manual",
      "source": "https://www.nirsoft.net/utils/network_latency_view.html",
      "notes": "Follow the publisher documentation; no automatic device changes are configured."
    },
    "licenseSource": "https://www.nirsoft.net/utils/network_latency_view.html"
  },
  {
    "id": "filezilla",
    "name": "FileZilla (Client)",
    "developer": "Tim Kosse / FileZilla Project",
    "description": "Graphical FTP, FTPS and SFTP client for transferring files between computers and servers.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "sftp",
      "ssh",
      "file transfer",
      "ftp",
      "remote administration"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Free open-source FileZilla Client; FileZilla Pro is a separate commercial offering.",
    "technicianLicenseNotes": "Review the client license before redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://filezilla-project.org/",
    "officialDownload": "https://filezilla-project.org/download.php?show_all=1",
    "documentation": "https://wiki.filezilla-project.org/Using",
    "localFolder": "20_PORTABLE_APPS/Networking/FileZilla",
    "localExecutable": "20_PORTABLE_APPS/Networking/FileZilla/filezilla.exe",
    "inventoryPatterns": [
      "filezilla.exe",
      "FileZilla_*.exe",
      "FileZilla_*.zip",
      "FileZilla_*.tar.bz2",
      "FileZilla*.app",
      "filezilla"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Verify remote host identity and destination paths before transfers or administrative commands.",
    "notes": "Choose FileZilla Client and your platform; use the ZIP edition for portable use. Prefer SFTP or FTPS when available.",
    "sourceStatus": "Official download page reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Open Site Manager and add an SFTP connection using the server address and your own credentials.",
      "Verify the server host-key fingerprint, connect, and transfer a small test file.",
      "Review overwrite settings and queued-transfer results before moving larger folders."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "termius",
    "name": "Termius",
    "developer": "Termius Corporation",
    "description": "SSH client and connection manager with a free Starter tier and paid collaboration features.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "sftp",
      "ssh",
      "file transfer",
      "terminal",
      "remote administration"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Starter tier is free; premium features require a paid plan. Review current plan terms.",
    "technicianLicenseNotes": "Review the selected plan for business use, team sharing and credential storage.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://termius.com/",
    "officialDownload": "https://termius.com/download/windows",
    "documentation": "https://support.termius.com/hc/en-us",
    "localFolder": "40_INSTALLERS/Networking/Termius",
    "localExecutable": "",
    "inventoryPatterns": [
      "Install Termius.exe",
      "Termius*.exe",
      "Termius*.dmg",
      "termius*.deb",
      "termius*.rpm",
      "Termius*.AppImage"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Verify remote host identity and destination paths before transfers or administrative commands.",
    "notes": "Windows managed download uses repository-maintained WinGet metadata. Other platforms are available from the publisher. Free Starter is not open source.",
    "sourceStatus": "Official download page reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Install the package for your platform and choose the plan appropriate to your needs.",
      "Create a host with its address, SSH port and authentication method; verify the host-key fingerprint.",
      "Open a test session. Review sync, vault and team-sharing settings before storing work credentials."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "github-desktop",
    "name": "GitHub Desktop",
    "developer": "GitHub",
    "description": "Graphical Git client for repositories, branches, commits and pull requests.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "github-desktop",
      "github desktop",
      "development",
      "programming",
      "build tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://desktop.github.com/download/",
    "officialDownload": "https://desktop.github.com/download/",
    "documentation": "https://docs.github.com/en/desktop",
    "localFolder": "40_INSTALLERS/Developer/github-desktop",
    "localExecutable": "",
    "inventoryPatterns": [
      "GitHubDesktopSetup*.exe",
      "GitHubDesktopSetup*.msi",
      "GitHubDesktop*.zip",
      "GitHubDesktop.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Offline use requires pre-downloaded dependencies, images or database drivers. Packages do not include a full offline dependency cache.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Install the correct OS package; sign in only to your own account.",
      "Clone a test repository and review changes before committing.",
      "Create a branch and test a pull request without publishing secrets."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ],
    "automationSupport": {
      "level": "manual",
      "notes": "Use the official command-line documentation for scripted workflows; toolkit setup still requires reviewed steps.",
      "source": "https://docs.github.com/en/desktop"
    }
  },
  {
    "id": "gh",
    "name": "GitHub CLI (gh)",
    "developer": "GitHub",
    "description": "GitHub command-line tools for repositories, issues, pull requests and Actions.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "gh",
      "github cli (gh)",
      "development",
      "programming",
      "build tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://cli.github.com/",
    "officialDownload": "https://cli.github.com/",
    "documentation": "https://cli.github.com/manual/",
    "localFolder": "20_PORTABLE_APPS/Developer/gh",
    "localExecutable": "",
    "inventoryPatterns": [
      "gh.exe",
      "gh_*",
      "gh"
    ],
    "kind": "Command-line",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Offline use requires pre-downloaded dependencies, images or database drivers. Packages do not include a full offline dependency cache.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Install or extract the platform package and check gh --version.",
      "Use gh auth login, then gh auth status to check the selected account.",
      "Try gh repo view from a repository; review commands before changing remote state."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ],
    "automationSupport": {
      "level": "documented",
      "notes": "Use the official command-line documentation for scripted workflows; toolkit setup still requires reviewed steps.",
      "source": "https://cli.github.com/manual/"
    }
  },
  {
    "id": "nodejs",
    "name": "Node.js LTS (includes npm)",
    "developer": "OpenJS Foundation",
    "description": "LTS JavaScript runtime and npm package manager for development and build tooling.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "nodejs",
      "node.js lts (includes npm)",
      "development",
      "programming",
      "build tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://nodejs.org/en/download",
    "officialDownload": "https://nodejs.org/en/download",
    "documentation": "https://nodejs.org/en/learn/getting-started/introduction-to-nodejs",
    "localFolder": "40_INSTALLERS/Developer/nodejs",
    "localExecutable": "",
    "inventoryPatterns": [
      "node-v*.msi",
      "node-v*.zip",
      "node-v*.pkg",
      "node-v*.tar.xz",
      "node.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Offline use requires pre-downloaded dependencies, images or database drivers. Packages do not include a full offline dependency cache.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Choose the LTS package compatible with the project and OS.",
      "Open a new terminal; verify node --version and npm --version.",
      "Use the project lockfile and npm ci for repeatable dependency installation."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ],
    "automationSupport": {
      "level": "documented",
      "notes": "Use the official command-line documentation for scripted workflows; toolkit setup still requires reviewed steps.",
      "source": "https://nodejs.org/en/learn/getting-started/introduction-to-nodejs"
    }
  },
  {
    "id": "docker-desktop",
    "name": "Docker Desktop",
    "developer": "Docker Inc.",
    "description": "Container development environment with Docker Engine, CLI and Compose integration.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "docker-desktop",
      "docker desktop",
      "development",
      "programming",
      "containers"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Docker Desktop is free only for eligible uses; review the current subscription terms.",
    "technicianLicenseNotes": "Check https://docs.docker.com/subscription-billing/desktop-license/ before deploying in an organization.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 800,
    "officialWebsite": "https://www.docker.com/products/docker-desktop/",
    "officialDownload": "https://www.docker.com/products/docker-desktop/",
    "documentation": "https://docs.docker.com/desktop/",
    "localFolder": "40_INSTALLERS/Developer/docker-desktop",
    "localExecutable": "",
    "inventoryPatterns": [
      "Docker Desktop Installer.exe",
      "Docker*.dmg",
      "docker-desktop*.deb",
      "docker-desktop*.rpm",
      "Docker Desktop.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Offline use requires pre-downloaded dependencies, images or database drivers. Packages do not include a full offline dependency cache.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Review Docker Desktop license eligibility and host virtualization requirements.",
      "Follow the official OS setup instructions; Windows may require WSL 2 and a restart.",
      "Verify docker version and docker compose version; run a trusted test container."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ],
    "automationSupport": {
      "level": "documented",
      "notes": "Use the official command-line documentation for scripted workflows; toolkit setup still requires reviewed steps.",
      "source": "https://docs.docker.com/desktop/"
    }
  },
  {
    "id": "podman-desktop",
    "name": "Podman Desktop",
    "developer": "Podman Desktop contributors",
    "description": "Open-source graphical container management and a Docker Desktop alternative.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "podman-desktop",
      "podman desktop",
      "development",
      "programming",
      "containers"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 800,
    "officialWebsite": "https://podman-desktop.io/downloads",
    "officialDownload": "https://podman-desktop.io/downloads",
    "documentation": "https://podman-desktop.io/docs/intro",
    "localFolder": "40_INSTALLERS/Developer/podman-desktop",
    "localExecutable": "",
    "inventoryPatterns": [
      "podman-desktop*.exe",
      "podman-desktop*.dmg",
      "podman-desktop*.tar.gz",
      "podman-desktop*.flatpak"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Offline use requires pre-downloaded dependencies, images or database drivers. Packages do not include a full offline dependency cache.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Install the native package and complete Podman engine setup.",
      "Create a local machine when required by your platform.",
      "Run a trusted test container; check project compatibility before replacing Docker."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ],
    "automationSupport": {
      "level": "documented",
      "notes": "Use the official command-line documentation for scripted workflows; toolkit setup still requires reviewed steps.",
      "source": "https://podman-desktop.io/docs/intro"
    }
  },
  {
    "id": "uv",
    "name": "uv (Python environment manager)",
    "developer": "Astral",
    "description": "Python runtime, package and project environment management with lockfiles.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "uv",
      "uv (python environment manager)",
      "development",
      "programming",
      "build tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://docs.astral.sh/uv/getting-started/installation/",
    "officialDownload": "https://docs.astral.sh/uv/getting-started/installation/",
    "documentation": "https://docs.astral.sh/uv/",
    "localFolder": "20_PORTABLE_APPS/Developer/uv",
    "localExecutable": "",
    "inventoryPatterns": [
      "uv.exe",
      "uv-*.zip",
      "uv-*.tar.gz",
      "uv"
    ],
    "kind": "Command-line",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Offline use requires pre-downloaded dependencies, images or database drivers. Packages do not include a full offline dependency cache.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Install the documented native package or extract the release; verify uv --version.",
      "Use uv init for a new project or uv sync in an existing uv project.",
      "Pin the project Python version and commit the lockfile for reproducible environments."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ],
    "automationSupport": {
      "level": "documented",
      "notes": "Use the official command-line documentation for scripted workflows; toolkit setup still requires reviewed steps.",
      "source": "https://docs.astral.sh/uv/"
    }
  },
  {
    "id": "dbeaver",
    "name": "DBeaver Community",
    "developer": "DBeaver Community",
    "description": "Database client for SQL development and administration across multiple engines.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "dbeaver",
      "dbeaver community",
      "development",
      "programming",
      "build tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://dbeaver.io/download/",
    "officialDownload": "https://dbeaver.io/download/",
    "documentation": "https://dbeaver.com/docs/dbeaver/",
    "localFolder": "40_INSTALLERS/Developer/dbeaver",
    "localExecutable": "",
    "inventoryPatterns": [
      "dbeaver-ce-*.exe",
      "dbeaver-ce-*.zip",
      "dbeaver-ce-*.dmg",
      "dbeaver-ce-*.deb",
      "dbeaver-ce-*.rpm",
      "dbeaver.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Offline use requires pre-downloaded dependencies, images or database drivers. Packages do not include a full offline dependency cache.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Install Community Edition and select the database driver.",
      "Test a connection using an appropriate least-privilege account.",
      "Begin with read-only queries; review transactions before changing data."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ],
    "automationSupport": {
      "level": "manual",
      "notes": "Use the official command-line documentation for scripted workflows; toolkit setup still requires reviewed steps.",
      "source": "https://dbeaver.com/docs/dbeaver/"
    }
  },
  {
    "id": "windows-terminal",
    "name": "Windows Terminal",
    "developer": "Microsoft",
    "description": "Tabbed terminal host for PowerShell, Command Prompt and WSL shells.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "windows-terminal",
      "windows terminal",
      "development",
      "programming",
      "build tools"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://github.com/microsoft/terminal/releases",
    "officialDownload": "https://github.com/microsoft/terminal/releases",
    "documentation": "https://learn.microsoft.com/en-us/windows/terminal/install",
    "localFolder": "40_INSTALLERS/Developer/windows-terminal",
    "localExecutable": "",
    "inventoryPatterns": [
      "Microsoft.WindowsTerminal*.msixbundle",
      "Microsoft.WindowsTerminal*.zip",
      "WindowsTerminal.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Offline use requires pre-downloaded dependencies, images or database drivers. Packages do not include a full offline dependency cache.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Install the stable release using Microsoft Store or documented package instructions.",
      "Choose the default terminal profile and review keyboard shortcuts.",
      "Open PowerShell and any configured WSL distributions; terminal profiles do not install their shells."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ],
    "automationSupport": {
      "level": "manual",
      "notes": "Use the official command-line documentation for scripted workflows; toolkit setup still requires reviewed steps.",
      "source": "https://learn.microsoft.com/en-us/windows/terminal/install"
    }
  },
  {
    "id": "restic",
    "name": "Restic",
    "developer": "Restic contributors",
    "description": "Encrypted, versioned backups to local storage, NAS paths and supported cloud repositories.",
    "categories": [
      "Backup & Sync"
    ],
    "tags": [
      "backup",
      "nas",
      "cloud",
      "recovery",
      "veam alternative"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://restic.net/",
    "officialDownload": "https://github.com/restic/restic/releases",
    "documentation": "https://restic.readthedocs.io/en/stable/",
    "localFolder": "20_PORTABLE_APPS/Backup/restic",
    "localExecutable": "",
    "inventoryPatterns": [
      "restic*.exe",
      "restic*.bz2",
      "restic"
    ],
    "kind": "Command-line",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Use a private repository and keep recovery credentials independently of the backed-up SSD.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Extract the binary and verify restic version.",
      "Create a repository using the official backend instructions and keep the recovery password separately.",
      "Back up a test directory, check the repository and restore a sample file before scheduling larger backups."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz",
      "*.bz2"
    ],
    "automationSupport": {
      "level": "documented",
      "notes": "Scheduling and command-line operation are documented by the project; configure destination and restore verification explicitly.",
      "source": "https://restic.readthedocs.io/en/stable/"
    }
  },
  {
    "id": "kopia",
    "name": "Kopia",
    "developer": "Kopia contributors",
    "description": "Encrypted snapshot backups with deduplication, retention and cloud or local repository support.",
    "categories": [
      "Backup & Sync"
    ],
    "tags": [
      "backup",
      "nas",
      "cloud",
      "recovery",
      "veam alternative"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://kopia.io/",
    "officialDownload": "https://github.com/kopia/kopia/releases",
    "documentation": "https://kopia.io/docs/",
    "localFolder": "40_INSTALLERS/Backup/kopia",
    "localExecutable": "",
    "inventoryPatterns": [
      "KopiaUI*.exe",
      "KopiaUI*.dmg",
      "kopia*.zip",
      "kopia*.tar.gz",
      "kopia*.deb",
      "kopia*.rpm"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Use a private repository and keep recovery credentials independently of the backed-up SSD.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Choose KopiaUI or the CLI for your platform.",
      "Connect a private repository and record its recovery password outside the toolkit.",
      "Create a snapshot and restore a test file; review retention and scheduling."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz",
      "*.bz2"
    ],
    "automationSupport": {
      "level": "documented",
      "notes": "Scheduling and command-line operation are documented by the project; configure destination and restore verification explicitly.",
      "source": "https://kopia.io/docs/"
    }
  },
  {
    "id": "duplicati",
    "name": "Duplicati",
    "developer": "Duplicati contributors",
    "description": "Scheduled encrypted file backups to network storage and supported cloud destinations.",
    "categories": [
      "Backup & Sync"
    ],
    "tags": [
      "backup",
      "nas",
      "cloud",
      "recovery",
      "veam alternative"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://duplicati.com/",
    "officialDownload": "https://github.com/duplicati/duplicati/releases",
    "documentation": "https://docs.duplicati.com/",
    "localFolder": "40_INSTALLERS/Backup/duplicati",
    "localExecutable": "",
    "inventoryPatterns": [
      "duplicati*.msi",
      "duplicati*.exe",
      "duplicati*.zip",
      "duplicati*.dmg",
      "duplicati*.deb",
      "duplicati*.rpm"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Use a private repository and keep recovery credentials independently of the backed-up SSD.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Install the stable package and secure its local management interface.",
      "Choose the source folders, destination and encryption password.",
      "Run a test backup and restore; then set retention and a schedule."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz",
      "*.bz2"
    ],
    "automationSupport": {
      "level": "documented",
      "notes": "Scheduling and command-line operation are documented by the project; configure destination and restore verification explicitly.",
      "source": "https://docs.duplicati.com/"
    }
  },
  {
    "id": "rclone",
    "name": "rclone",
    "developer": "rclone contributors",
    "description": "Transfers between cloud storage and local or NAS paths; useful for copying completed toolkit backups.",
    "categories": [
      "Backup & Sync"
    ],
    "tags": [
      "backup",
      "nas",
      "cloud",
      "recovery",
      "veam alternative"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Open source",
    "personalLicenseNotes": "Open-source project; review component licenses.",
    "technicianLicenseNotes": "Review license and dependency terms for redistribution and organizational use.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64",
      "arm64; package availability varies"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://rclone.org/downloads/",
    "officialDownload": "https://github.com/rclone/rclone/releases",
    "documentation": "https://rclone.org/docs/",
    "localFolder": "20_PORTABLE_APPS/Backup/rclone",
    "localExecutable": "",
    "inventoryPatterns": [
      "rclone.exe",
      "rclone-*.zip",
      "rclone"
    ],
    "kind": "Command-line",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review PATH, virtualization and service changes before installation. Keep project secrets out of shared toolkit storage.",
    "notes": "Review credentials, retention and restore procedures before relying on the backup. rclone transfers are not versioned backups by themselves.",
    "sourceStatus": "Official download and documentation reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Extract the platform package and verify rclone version.",
      "Configure a remote with the official provider instructions; keep tokens private.",
      "Use copy and a dry run first. Sync can delete destination files; use versioned backup archives and verify transfers."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz",
      "*.bz2"
    ],
    "automationSupport": {
      "level": "documented",
      "notes": "Scheduling and command-line operation are documented by the project; configure destination and restore verification explicitly.",
      "source": "https://rclone.org/docs/"
    }
  },
  {
    "id": "airvpn",
    "name": "AirVPN (Eddie client)",
    "developer": "AirVPN",
    "description": "VPN service client for connecting this computer to AirVPN using Eddie.",
    "categories": [
      "VPN",
      "Networking"
    ],
    "tags": [
      "airvpn",
      "airvpn (eddie client)",
      "vpn",
      "privacy",
      "network tunnel"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "The Eddie client is open source; using AirVPN service requires a valid service plan.",
    "technicianLicenseNotes": "Use the device owner’s authorized account; review provider terms before organizational deployment. Toolkit inclusion does not include a subscription.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other architectures depend on provider and platform"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://airvpn.org/",
    "officialDownload": "https://airvpn.org/download/",
    "documentation": "https://github.com/AirVPN/Eddie",
    "localFolder": "40_INSTALLERS/VPN/airvpn",
    "localExecutable": "",
    "inventoryPatterns": [
      "eddie-ui*.exe",
      "eddie-ui*.msi",
      "eddie-ui*.zip",
      "eddie-ui*.deb",
      "eddie-ui*.rpm",
      "eddie-ui*.dmg",
      "Eddie-UI.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "VPN routes and kill switches can interrupt NAS access and remote support sessions. Review local-network access before connecting.",
    "notes": "Eddie is an open-source client; the AirVPN service is paid. Official mobile packages and manual configurations are available from the provider.",
    "sourceStatus": "Official download and support pages reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Download the native application for your platform from the official publisher.",
      "Install and sign in with your own provider account or activation details.",
      "Choose a server and review protocol, kill-switch and local-network access settings. Test internet access, DNS and NAS access before enabling automatic connection."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "expressvpn",
    "name": "ExpressVPN",
    "developer": "ExpressVPN",
    "description": "VPN service client for connecting this computer to ExpressVPN servers.",
    "categories": [
      "VPN",
      "Networking"
    ],
    "tags": [
      "expressvpn",
      "expressvpn",
      "vpn",
      "privacy",
      "network tunnel"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "A valid provider account and service plan are required; review current trial and subscription terms.",
    "technicianLicenseNotes": "Use the device owner’s authorized account; review provider terms before organizational deployment. Toolkit inclusion does not include a subscription.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other architectures depend on provider and platform"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.expressvpn.com/",
    "officialDownload": "https://www.expressvpn.com/vpn-download",
    "documentation": "https://www.expressvpn.com/support/",
    "localFolder": "40_INSTALLERS/VPN/expressvpn",
    "localExecutable": "",
    "inventoryPatterns": [
      "expressvpn*.exe",
      "expressvpn*.msi",
      "expressvpn*.pkg",
      "expressvpn*.dmg",
      "expressvpn*.deb",
      "expressvpn*.rpm"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "VPN routes and kill switches can interrupt NAS access and remote support sessions. Review local-network access before connecting.",
    "notes": "Publisher-managed download. Mobile and other device support is described on the official site.",
    "sourceStatus": "Official download and support pages reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Download the native application for your platform from the official publisher.",
      "Install and sign in with your own provider account or activation details.",
      "Choose a server and review protocol, kill-switch and local-network access settings. Test internet access, DNS and NAS access before enabling automatic connection."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "vpn-unlimited",
    "name": "VPN Unlimited",
    "developer": "KeepSolid",
    "description": "VPN service client for connecting this computer to VPN Unlimited servers.",
    "categories": [
      "VPN",
      "Networking"
    ],
    "tags": [
      "vpn-unlimited",
      "vpn unlimited",
      "vpn",
      "privacy",
      "network tunnel"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "A valid provider account and service plan are required; review current trial and subscription terms.",
    "technicianLicenseNotes": "Use the device owner’s authorized account; review provider terms before organizational deployment. Toolkit inclusion does not include a subscription.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows",
      "Linux",
      "macOS"
    ],
    "architecture": [
      "x64; other architectures depend on provider and platform"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.vpnunlimited.com/",
    "officialDownload": "https://www.vpnunlimited.com/downloads",
    "documentation": "https://www.vpnunlimited.com/help",
    "localFolder": "40_INSTALLERS/VPN/vpn-unlimited",
    "localExecutable": "",
    "inventoryPatterns": [
      "VPN_Unlimited*.exe",
      "VPNUnlimited*.exe",
      "VPNUnlimited*.msi",
      "VPNUnlimited*.dmg",
      "VPNUnlimited*.pkg",
      "vpn-unlimited*.deb",
      "vpn_unlimited*.deb"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "VPN routes and kill switches can interrupt NAS access and remote support sessions. Review local-network access before connecting.",
    "notes": "Publisher-managed download. Mobile and other device support is described on the official site.",
    "sourceStatus": "Official download and support pages reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Download the native application for your platform from the official publisher.",
      "Install and sign in with your own provider account or activation details.",
      "Choose a server and review protocol, kill-switch and local-network access settings. Test internet access, DNS and NAS access before enabling automatic connection."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  },
  {
    "id": "fastestvpn",
    "name": "FastestVPN",
    "developer": "FastestVPN",
    "description": "VPN service client for connecting this computer to FastestVPN servers.",
    "categories": [
      "VPN",
      "Networking"
    ],
    "tags": [
      "fastestvpn",
      "fastestvpn",
      "vpn",
      "privacy",
      "network tunnel"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "A valid provider account and service plan are required; review current trial and subscription terms.",
    "technicianLicenseNotes": "Use the device owner’s authorized account; review provider terms before organizational deployment. Toolkit inclusion does not include a subscription.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows",
      "macOS"
    ],
    "architecture": [
      "x64; other architectures depend on provider and platform"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://fastestvpn.com/",
    "officialDownload": "https://fastestvpn.com/download",
    "documentation": "https://support.fastestvpn.com/",
    "localFolder": "40_INSTALLERS/VPN/fastestvpn",
    "localExecutable": "",
    "inventoryPatterns": [
      "FastestVPN*.exe",
      "FastestVPN*.msi",
      "FastestVPN*.dmg",
      "FastestVPN*.pkg"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "2026-09-10",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "VPN routes and kill switches can interrupt NAS access and remote support sessions. Review local-network access before connecting.",
    "notes": "Publisher-managed download. Mobile and other device support is described on the official site. Linux uses the provider’s manual setup guidance rather than a cataloged native desktop installer.",
    "sourceStatus": "Official download and support pages reviewed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-10",
    "quickStart": [
      "Download the native application for your platform from the official publisher.",
      "Install and sign in with your own provider account or activation details.",
      "Choose a server and review protocol, kill-switch and local-network access settings. Test internet access, DNS and NAS access before enabling automatic connection."
    ],
    "packagePatterns": [
      "*.exe",
      "*.msi",
      "*.msix",
      "*.msixbundle",
      "*.zip",
      "*.7z",
      "*.iso",
      "*.dmg",
      "*.pkg",
      "*.deb",
      "*.rpm",
      "*.AppImage",
      "*.tar.xz",
      "*.tar.gz"
    ]
  }
];
