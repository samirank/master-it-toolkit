// Unscanned inventory; run a local updater to detect your files.
window.LOCAL_INVENTORY = {"generatedAt":null,"tools":{},"storage":null,"errors":[]};
