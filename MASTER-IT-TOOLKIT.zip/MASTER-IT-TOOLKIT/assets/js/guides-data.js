// Original field-service guidance. Optional local launches are handled by the reviewed workflow runner.
window.TOOLKIT_TASKS = [
 {id:'boot',name:"PC won't boot",icon:'⏻',summary:'Triage startup & recover access',tags:['not booting','boot failure'],tools:['hirens','systemrescue','windows11','gparted','reagentc','bcdedit'],reference:'windows-recovery',checklist:'boot',warning:'Confirm backup and BitLocker recovery-key access before changing boot configuration.',steps:['Record the exact error, recent changes, BIOS disk detection and boot mode. Disconnect unnecessary peripherals.','If the drive disappears, clicks or reports errors, stop repair attempts and follow Failing Disk.','Use Windows RE Startup Repair first. Identify the Windows volume and EFI partition before considering manual boot repair.']},
 {id:'clone',name:'Clone a drive',icon:'▣',summary:'Image, migrate & restore',tags:['SSD upgrade','disk migration'],tools:['rescuezilla','clonezilla','diskgenius','disk2vhd'],reference:'cloning',checklist:'ssd',warning:'Cloning overwrites the destination. Match both drives by serial number and capacity.',steps:['Check source health and encryption, make a backup, and ensure the destination is large enough.','For healthy media, use Rescuezilla for a guided workflow or Clonezilla for repeatable imaging. For damaged media, use ddrescue instead.','Boot the clone with the original disconnected, verify files and applications, then retain the original until handover.']},
 {id:'failing',name:'Drive may be failing',icon:'◴',summary:'Preserve data before repair',tags:['SSD health','HDD clicking','bad sectors'],tools:['cdi','smartmontools','ddrescue','dmde'],reference:'ddrescue',checklist:'failing',warning:'Image the failing disk before unnecessary repair attempts. Stop powering a clicking or physically damaged drive; consider professional recovery.',steps:['Confirm the value of the data and choose professional recovery for irreplaceable data or physical symptoms.','Read identity and health with minimal load. Do not benchmark, CHKDSK /r, format or repeatedly scan the original.','Create an image and mapfile on healthy separate storage. Recover from the image and save results to a third location.']},
 {id:'malware',name:'Remove malware',icon:'◇',summary:'Isolate, investigate & clean',tags:['virus','adware','infected'],tools:['defenderoffline','safetyscanner','eek','adwcleaner','autoruns','process-explorer','tcpview','sigcheck'],reference:'malware',checklist:'malware',warning:'Isolate active compromise when appropriate. Preserve evidence before cleanup if incident response is needed.',steps:['Confirm scope and authorization. Preserve necessary data and incident evidence.','Use fresh trusted scanners or a trusted boot environment; review detections and persistence.','Patch the system and applications, then rotate compromised credentials from a clean device. Reinstall from trusted media if confidence cannot be restored.']},
 {id:'slow',name:'Windows is slow',icon:'≋',summary:'Find the bottleneck first',tags:['slow PC','performance','sluggish'],tools:['autoruns','process-explorer','wiztree','cdi','hwinfo','revo','bcu','resmon'],reference:'windows-recovery',checklist:'return',steps:['Observe CPU, memory, disk and temperatures while reproducing the issue.','Check drive health and free space before cleanup. Review startup entries and recently installed software.','Change one item at a time, then repeat the same workload to verify improvement.']},
 {id:'debloat',name:'Remove Windows bloat',icon:'⊟',summary:'Remove optional apps carefully',tags:['debloat','bloatware','OEM trialware'],tools:['win11debloat','appbuster','winutil','bcu'],reference:'privacy-presets',checklist:'newpc',warning:'Review every removal. Preserve required business, accessibility, security and gaming dependencies.',steps:['Record the owner’s preferences and create a restore point or recoverable backup.','Start with normal uninstall for OEM trialware, then review optional Windows app removal.','Test Start, search, Store, Windows Update and required apps after changes.']},
 {id:'telemetry',name:'Disable telemetry',icon:'◈',summary:'Review supported privacy controls',tags:['advertising','privacy','tracking'],tools:['shutup','win11debloat','gpedit'],reference:'privacy-presets',checklist:'newpc',steps:['Review the SAFE and PRIVACY concepts in the local presets guide.','Change supported advertising, suggestions and diagnostic settings. Managed policy and edition may limit controls.','Keep Windows Update, Defender and System Restore enabled; document changes and rollback.']},
 {id:'ai',name:'Disable Windows AI',icon:'✧',summary:'Copilot, Recall & app AI controls',tags:['AI','Copilot','Recall','Click to Do','Edge AI','Paint AI','Notepad AI'],tools:['win11debloat','shutup','winutil'],reference:'privacy-presets',checklist:'newpc',warning:'Available controls depend on Windows build, edition and app version. Review each tool’s current option descriptions.',steps:['Record which AI features the owner wants disabled, including Recall and Click to Do.','Review Win11Debloat feature controls and supported Windows policies; avoid bulk scripts that remove unknown dependencies.','Check Windows and individual app settings after updates because defaults can change.']},
 {id:'onedrive',name:'Remove OneDrive',icon:'☁',summary:'Protect synced files first',tags:['OneDrive startup','cloud backup','remove OneDrive'],tools:['win11debloat','shutup','autoruns'],reference:'account-oobe',checklist:'migration',warning:'Confirm Files On-Demand and known-folder backup status. Cloud-only placeholders are not a local backup.',steps:['Ask the owner to confirm sync completion and which folders are protected. Download required cloud files and verify an independent backup.','Review unlinking, startup preference and known-folder locations before uninstalling.','Verify Desktop, Documents and Pictures paths and files after changes. Preserve Microsoft 365/Teams integration when required.']},
 {id:'localfirst',name:'Set up Windows, local-first',icon:'⊞',summary:'Plan accounts & integrations',tags:['install Windows without Microsoft account','OOBE','local account'],tools:['rufus','ntlite','windows11','unattend'],reference:'account-oobe',checklist:'reinstall',warning:'AUTHORIZED SYSTEMS ONLY. Setup options vary by edition and build; use supported choices and licensed media.',steps:['Agree account, OneDrive, backup and AI preferences with the owner.','Validate unattended settings against the exact image in a VM. The supplied example sets language only; it contains no credentials or authentication bypass.','Let the owner enter passwords and retain recovery keys in their own approved location.']},
 {id:'gpu',name:'GPU crashing',icon:'▤',summary:'Drivers, thermals & stability',tags:['GPU crash','graphics crash','black screen'],tools:['ddu','hwinfo','gpuz','occt','nvidia','amd-gpu','intel-gpu','reliability'],reference:'drivers',checklist:'gaming',warning:'Monitor temperatures before and during stress testing. Stage the replacement driver before using DDU.',steps:['Collect crash timing and versions. Return overclocks to defaults and inspect cooling and power connections.','Use OEM/vendor drivers or rollback a recent change. Use DDU in Safe Mode only when normal reinstall is insufficient.','Test progressively and monitor sensors; compare results using the same workload.']},
 {id:'nonetwork',name:'No network after install',icon:'⌁',summary:'Use your offline driver library',tags:['no Wi-Fi','no wifi','missing network','no network'],tools:['intel-network','realtek','sdio','hpia','dell','lenovo','surface','devmgmt'],reference:'drivers',checklist:'network',steps:['Check airplane mode, cable/link lights and Device Manager hardware IDs.','Install the model-matched offline OEM network driver. Use SDIO only after reviewing its match and signature.','Test DHCP, gateway and DNS after the adapter appears; then obtain remaining updates from official sources.']},
 {id:'recover',name:'Recover files',icon:'↶',summary:'Work from an image or copy',tags:['recover files','deleted files','lost photos'],tools:['dmde','testdisk','photorec','ddrescue','recuva'],reference:'data-recovery',checklist:'failing',warning:'Never write recovered files back to the source. SSD TRIM and encryption can make recovery impossible.',steps:['Stop writes to the source. If it is unhealthy, image it first or escalate to a recovery lab.','Use filesystem-aware recovery first, then PhotoRec file carving if metadata is lost.','Save results to separate healthy storage, open sample files and verify critical documents.']},
 {id:'ram',name:'Test RAM',icon:'▥',summary:'Test outside Windows',tags:['memory errors','test RAM','BSOD memory'],tools:['memtest','passmark','cpuz'],reference:'hardware',checklist:'gaming',steps:['Record memory layout and current settings. Return overclocks/XMP/EXPO to supported defaults for baseline testing.','Boot MemTest86+ on compatible firmware and run multiple passes; record any errors.','Test modules and slots systematically with power disconnected when changing hardware. A pass is evidence, not a guarantee.']},
 {id:'network',name:'Troubleshoot network',icon:'⌘',summary:'Link → address → DNS → service',tags:['no internet','DNS problem','DHCP problem','duplicate IP','slow Ethernet','slow Wi-Fi','packet loss','port test','LAN discovery','throughput testing'],tools:['ipconfig','netadapter','dns','porttest','ping','tracert','wlan','arp','wireshark','iperf3','nmap'],reference:'networking',checklist:'network',steps:['Check physical link, negotiated speed and adapter state; compare a known-good cable or port.','Inspect DHCP address, gateway and DNS. Test gateway, a known IP and a hostname separately.','For slow links, compare wired and wireless and use iperf3 between two controlled LAN endpoints. Capture only authorized traffic.']},
 {id:'uninstall',name:'Remove stubborn software',icon:'⊖',summary:'Uninstall, then review leftovers',tags:['uninstall','stubborn app','remove software'],tools:['revo','bcu','geek','hibit','appwiz'],reference:'privacy-presets',checklist:'return',warning:'A leftover scan can include shared files and registry entries. Do not accept every result automatically.',steps:['Try the application’s normal uninstaller and restart if requested.','Prefer free, open-source BCUninstaller for batch review. Choose licensed Revo Pro only when installation tracing is specifically required.','Review leftovers, preserve user data and test related applications. Avoid registry-cleaner functions.']}
];
window.TOOLKIT_CHECKLISTS = {
  "newpc": {
    "name": "New Windows PC Setup",
    "items": [
      "Confirm ownership, scope and backup preferences",
      "Record model, serial and Windows edition",
      "Create a restore point or recoverable baseline backup",
      "Run Windows Update and restart; recheck",
      "Review BIOS/firmware model, release notes and stable power",
      "Install OEM chipset, network and GPU drivers",
      "Remove unwanted OEM trialware with owner approval",
      "Review supported privacy, advertising and telemetry settings",
      "Review Copilot, Recall, Click to Do and app AI preferences",
      "Confirm OneDrive known-folder backup and account preferences",
      "Check BitLocker status and owner-held recovery-key access",
      "Install browser, office suite, PDF reader, 7-Zip and media player",
      "Install required Visual C++ / .NET runtimes",
      "Test audio, webcam, networking, sleep and peripheral devices",
      "Record versions, changes and owner handover"
    ]
  },
  "malware": {
    "name": "Malware Cleanup",
    "items": [
      "Confirm authorization and incident-response requirements",
      "Isolate active compromise when appropriate",
      "Preserve evidence and necessary data before modifying",
      "Prepare a trusted environment and fresh scanner definitions",
      "Scan and review findings; avoid restoring infected executables",
      "Review startup persistence, services, tasks and browser extensions",
      "Update Windows, browsers and software",
      "Rotate compromised credentials from a clean device",
      "Reinstall trusted media if cleanup confidence is insufficient",
      "Document findings and verify protection is enabled"
    ]
  },
  "boot": {
    "name": "PC Won't Boot",
    "items": [
      "Record error, recent changes and firmware boot mode",
      "Check power, cables and firmware disk detection",
      "Confirm BitLocker key availability with owner",
      "Check drive health before filesystem or boot repair",
      "Back up / image important data",
      "Use Windows RE Startup Repair",
      "Identify Windows and EFI partitions before manual repair",
      "Review BCD and WinRE configuration without blanket changes",
      "Test repeated cold boots",
      "Record cause and successful recovery steps"
    ]
  },
  "failing": {
    "name": "Failing Disk",
    "items": [
      "Stop unnecessary use and writes",
      "Discuss professional recovery for physical damage or irreplaceable files",
      "Record drive serial, capacity and minimal health observations",
      "Prepare a healthy destination large enough for image and recovery output",
      "Image first with a resumable mapfile, if appropriate",
      "Preserve source and original image",
      "Recover from a working image copy",
      "Save recovered files to separate healthy storage",
      "Verify critical files with owner",
      "Replace failed media and document outcome"
    ]
  },
  "gaming": {
    "name": "Gaming PC Troubleshooting",
    "items": [
      "Record game, symptom and reproducible workload",
      "Review Reliability Monitor and crash timestamps",
      "Return CPU/GPU/RAM tuning to defaults for baseline",
      "Check temperatures, cooling and power connectors",
      "Check RAM and storage health",
      "Stage and install model-matched GPU drivers",
      "Verify required runtimes and game files",
      "Test one subsystem at a time while monitoring temperatures",
      "Preserve Xbox/anti-cheat dependencies required by games",
      "Repeat original workload and record result"
    ]
  },
  "network": {
    "name": "Network Troubleshooting",
    "items": [
      "Check cable, link LEDs, airplane mode and adapter state",
      "Confirm driver hardware ID and link speed",
      "Record IP, mask, gateway, DNS and DHCP status",
      "Test the gateway and another LAN device",
      "Compare known external IP and DNS lookup results",
      "Check duplicate IP against DHCP leases / neighbor table",
      "Test required TCP port and proxy/VPN configuration",
      "Compare known-good Ethernet cable and Wi-Fi location",
      "Run authorized throughput or packet capture tests if needed",
      "Document changes and restore temporary test settings"
    ]
  },
  "return": {
    "name": "Before Returning Customer PC",
    "items": [
      "Verify the original issue is resolved using the original workload",
      "Check updates, Defender, firewall and restore configuration",
      "Verify user data, applications, printing and peripherals",
      "Confirm BitLocker recovery key is held by the owner",
      "Remove temporary remote access and technician accounts if created",
      "Remove customer copies from toolkit according to agreed retention",
      "Remove test files and close customer sessions",
      "Export service notes without credentials",
      "Document changes, licenses and remaining issues",
      "Obtain owner acceptance and disconnect toolkit safely"
    ]
  },
  "migration": {
    "name": "Data Migration",
    "items": [
      "Identify source, destination and owner-approved data scope",
      "Check source health, encryption and cloud-only placeholders",
      "Create an independent backup before migration",
      "Download necessary synced files and verify availability",
      "Preview copy paths; avoid mirror/delete modes",
      "Preview and copy the selected regular files into a new job folder; verify contents and retain originals.",
      "Compare counts, sizes and open critical sample files",
      "Confirm Desktop, Documents, Pictures and application data",
      "Do not transfer unknown persistence or compromised executables",
      "Keep original until the owner approves the migration"
    ]
  },
  "ssd": {
    "name": "SSD Upgrade",
    "items": [
      "Confirm interface, form factor and capacity compatibility",
      "Check source health and encryption",
      "Create verified backup and confirm recovery-key access",
      "Record both disk serials before cloning",
      "Use guided clone/image tool for healthy media",
      "Do not interrupt copy; maintain stable power",
      "Disconnect original before first boot of clone",
      "Verify partitions, files, applications and boot behavior",
      "Check SSD health and available space",
      "Retain original until verification and handover are complete"
    ]
  },
  "reinstall": {
    "name": "Windows Reinstallation",
    "items": [
      "Confirm owner authorization, Windows license and edition",
      "Back up data and application/license records without passwords",
      "Verify recovery keys and cloud sync completeness",
      "Stage correct offline network, chipset and storage drivers",
      "Create trusted Windows media and verify source",
      "Review partition selection carefully; installation can erase data",
      "Use supported account/OOBE choices agreed with owner",
      "Install drivers, Windows updates and required runtimes",
      "Restore verified data and install approved applications",
      "Review privacy, AI, OneDrive and BitLocker preferences",
      "Test hardware, apps, activation and recovery options",
      "Document build and return the PC with owner acceptance"
    ]
  },
  "profile-migration": {
    "name": "New PC / profile migration",
    "items": [
      "Agree which user folders, browser bookmarks, mail archives and application settings to migrate. Record application licenses without credentials.",
      "Back up the source independently, unlock encrypted data with the owner and fully download cloud-only files.",
      "Check the source drive health before copying. Stop and use a recovery workflow if it is failing.",
      "Preview and copy the selected regular files into a new job folder; verify contents and retain originals.",
      "Review the copy log and verification failures. Compare file counts and sizes; open critical files on the destination.",
      "Install applications from trusted installers on the new PC. Import supported bookmarks, mail and settings; do not copy Windows or Program Files as an OS migration.",
      "Have the owner confirm access to files and applications. Keep the original and backup until acceptance."
    ]
  }
};
window.TOOLKIT_REFERENCES = [
 ['windows-recovery','Windows Recovery Commands','Start with the symptom and preserve data.'],['dism','DISM Commands','Repair the component store with a matched source.'],['sfc','SFC','Check protected Windows system files.'],['chkdsk','CHKDSK','Inspect before attempting filesystem repair.'],['diskpart','DiskPart','Read disk layout before changing anything.'],['bcd','Bootrec / BCD / EFI','Identify boot mode and partitions first.'],['networking','Networking Commands','Link, DHCP, DNS, routes and ports.'],['powershell','PowerShell Troubleshooting','Logs, service state and command discovery.'],['linux-rescue','Linux Rescue Commands','Inspect storage, RAID, LVM and ZFS.'],['smart','SMART','Health indicators and their limits.'],['ddrescue','GNU ddrescue','Resumable failing-media imaging.'],['mounting','Filesystem Mounting','Read-only and journal replay considerations.'],['bios','BIOS Boot Keys','Common keys; always verify the exact model.'],['safe-mode','Safe Mode','Use temporary Windows recovery startup settings.'],['winre','Windows Recovery Environment','Check and enter the recovery environment.'],['bitlocker','BitLocker Recovery','AUTHORIZED SYSTEMS ONLY.'],['drivers','Driver Troubleshooting','Hardware IDs, offline packages and rollback.'],['malware','Malware Workflow','Isolate, preserve, scan and verify.'],['account-oobe','Account, OOBE & OneDrive','Supported setup and owner-controlled recovery.'],['privacy-presets','Windows Privacy Presets','Reviewable concepts, never auto-applied.'],['data-recovery','Data Recovery','Recover from an image to separate storage.'],['cloning','Imaging & Cloning','Healthy-drive migration versus failing media.'],['hardware','Hardware & Firmware','Temperatures, power and model verification.'],['updates','Windows Update / Profile Repair','Conservative troubleshooting and escalation.']
];
