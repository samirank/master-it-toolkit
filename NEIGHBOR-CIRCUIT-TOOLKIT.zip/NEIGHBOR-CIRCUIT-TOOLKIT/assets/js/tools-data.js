// Central catalog. Source checks are not software or license certification.
window.TOOLKIT_DATA = [
  {
    "id": "windows11",
    "name": "Windows 11 ISO",
    "developer": "Microsoft",
    "description": "Official installation media and Windows Recovery Environment.",
    "categories": [
      "Boot & Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "Windows installation"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 7000,
    "officialWebsite": "https://www.microsoft.com/en-us/software-download/windows11",
    "officialDownload": "https://www.microsoft.com/en-us/software-download/windows11",
    "documentation": "https://www.microsoft.com/en-us/software-download/windows11",
    "localFolder": "00_BOOT/Windows",
    "localExecutable": "",
    "inventoryPatterns": [
      "Win11*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.microsoft.com/en-us/software-download/windows11",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/software-download/windows11",
        "title": "Download Windows 11",
        "checkedAt": "2026-09-09T20:17:57.239917+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.microsoft.com/en-us/software-download/windows11",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/software-download/windows11",
        "title": "Download Windows 11",
        "checkedAt": "2026-09-09T20:17:57.239917+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "hirens",
    "name": "Hiren's BootCD PE",
    "developer": "Hiren's BootCD PE team",
    "description": "Windows PE rescue desktop; check bundled utility licenses separately.",
    "categories": [
      "Boot & Recovery"
    ],
    "tags": [
      "PC won't boot"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 3500,
    "officialWebsite": "https://www.hirensbootcd.org/download/",
    "officialDownload": "https://www.hirensbootcd.org/download/",
    "documentation": "https://www.hirensbootcd.org/download/",
    "localFolder": "00_BOOT/WinPE",
    "localExecutable": "",
    "inventoryPatterns": [
      "HBCD_PE*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.hirensbootcd.org/download/",
        "status": 200,
        "finalUrl": "https://www.hirensbootcd.org/download/",
        "title": "Download | Hiren's BootCD PE",
        "checkedAt": "2026-09-09T20:17:56.892630+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.hirensbootcd.org/download/",
        "status": 200,
        "finalUrl": "https://www.hirensbootcd.org/download/",
        "title": "Download | Hiren's BootCD PE",
        "checkedAt": "2026-09-09T20:17:56.892630+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "systemrescue",
    "name": "SystemRescue",
    "developer": "SystemRescue project",
    "description": "Linux rescue environment with storage, network and filesystem tools.",
    "categories": [
      "Boot & Recovery",
      "Homelab / Linux",
      "Data Recovery"
    ],
    "tags": [
      "Linux rescue"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1200,
    "officialWebsite": "https://www.system-rescue.org/Download/",
    "officialDownload": "https://www.system-rescue.org/Download/",
    "documentation": "https://www.system-rescue.org/Download/",
    "localFolder": "00_BOOT/Linux-Rescue",
    "localExecutable": "",
    "inventoryPatterns": [
      "systemrescue*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.system-rescue.org/Download/",
        "status": 200,
        "finalUrl": "https://www.system-rescue.org/Download/",
        "title": "SystemRescue - Download",
        "checkedAt": "2026-09-09T20:17:58.593999+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.system-rescue.org/Download/",
        "status": 200,
        "finalUrl": "https://www.system-rescue.org/Download/",
        "title": "SystemRescue - Download",
        "checkedAt": "2026-09-09T20:17:58.593999+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "gparted",
    "name": "GParted Live",
    "developer": "GParted project",
    "description": "Offline partition editor. Resizing and formatting change disk contents.",
    "categories": [
      "Boot & Recovery",
      "Disk & Partition"
    ],
    "tags": [
      "SSD HDD partition"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 600,
    "officialWebsite": "https://gparted.org/download.php",
    "officialDownload": "https://gparted.org/download.php",
    "documentation": "https://gparted.org/download.php",
    "localFolder": "00_BOOT/Linux-Rescue",
    "localExecutable": "",
    "inventoryPatterns": [
      "gparted-live*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://gparted.org/download.php",
        "status": 200,
        "finalUrl": "https://gparted.org/download.php",
        "title": "GParted -- Download",
        "checkedAt": "2026-09-09T20:17:52.491691+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://gparted.org/download.php",
        "status": 200,
        "finalUrl": "https://gparted.org/download.php",
        "title": "GParted -- Download",
        "checkedAt": "2026-09-09T20:17:52.491691+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "ubuntu",
    "name": "Ubuntu Live",
    "developer": "Canonical",
    "description": "Live Linux desktop for hardware checks and mounting filesystems.",
    "categories": [
      "Homelab / Linux",
      "Boot & Recovery"
    ],
    "tags": [
      "Linux rescue"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 6500,
    "officialWebsite": "https://ubuntu.com/download/desktop",
    "officialDownload": "https://ubuntu.com/download/desktop",
    "documentation": "https://ubuntu.com/download/desktop",
    "localFolder": "00_BOOT/Linux-Rescue",
    "localExecutable": "",
    "inventoryPatterns": [
      "ubuntu*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://ubuntu.com/download/desktop",
        "status": 200,
        "finalUrl": "https://ubuntu.com/download/desktop",
        "title": "Download Ubuntu Desktop | Ubuntu",
        "checkedAt": "2026-09-09T20:17:55.411012+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://ubuntu.com/download/desktop",
        "status": 200,
        "finalUrl": "https://ubuntu.com/download/desktop",
        "title": "Download Ubuntu Desktop | Ubuntu",
        "checkedAt": "2026-09-09T20:17:55.411012+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "rescuezilla",
    "name": "Rescuezilla",
    "developer": "Rescuezilla project",
    "description": "Graphical image backup and restore for healthy drives.",
    "categories": [
      "Imaging & Cloning",
      "Boot & Recovery"
    ],
    "tags": [
      "clone a drive SSD"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://rescuezilla.com/download",
    "officialDownload": "https://rescuezilla.com/download",
    "documentation": "https://rescuezilla.com/download",
    "localFolder": "00_BOOT/Imaging",
    "localExecutable": "",
    "inventoryPatterns": [
      "rescuezilla*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://rescuezilla.com/download",
        "status": 200,
        "finalUrl": "https://rescuezilla.com/download",
        "title": "Download | Rescuezilla (Clonezilla GUI)",
        "checkedAt": "2026-09-09T20:17:53.920790+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://rescuezilla.com/download",
        "status": 200,
        "finalUrl": "https://rescuezilla.com/download",
        "title": "Download | Rescuezilla (Clonezilla GUI)",
        "checkedAt": "2026-09-09T20:17:53.920790+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "clonezilla",
    "name": "Clonezilla Live",
    "developer": "Clonezilla project",
    "description": "Partition and disk imaging for repeatable deployments; verify source and destination.",
    "categories": [
      "Imaging & Cloning",
      "Boot & Recovery"
    ],
    "tags": [
      "clone a drive SSD"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 600,
    "officialWebsite": "https://clonezilla.org/downloads.php",
    "officialDownload": "https://clonezilla.org/downloads.php",
    "documentation": "https://clonezilla.org/downloads.php",
    "localFolder": "00_BOOT/Imaging",
    "localExecutable": "",
    "inventoryPatterns": [
      "clonezilla-live*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official project listing reviewed",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://clonezilla.org/downloads.php",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:51.215242+00:00"
      },
      "download": {
        "url": "https://clonezilla.org/downloads.php",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:51.215242+00:00"
      }
    },
    "sourceReviewNotes": "Official project SourceForge release listing and Clonezilla changelog reviewed; main download page blocks automated requests. Latest version left manual."
  },
  {
    "id": "kaspersky",
    "name": "Kaspersky Rescue Disk",
    "developer": "Kaspersky",
    "description": "Bootable antivirus rescue environment. Verify availability and current definitions for your region.",
    "categories": [
      "Malware & Security",
      "Boot & Recovery"
    ],
    "tags": [
      "malware rescue"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 800,
    "officialWebsite": "https://www.kaspersky.com/downloads/free-rescue-disk",
    "officialDownload": "https://www.kaspersky.com/downloads/free-rescue-disk",
    "documentation": "https://www.kaspersky.com/downloads/free-rescue-disk",
    "localFolder": "00_BOOT/Security",
    "localExecutable": "",
    "inventoryPatterns": [
      "krd*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": true,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Official rescue download remains listed. Verify current definitions, availability, regulatory restrictions and organization policy for the region of use; never assume an old ISO is current.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kaspersky.com/downloads/free-rescue-disk",
        "status": 200,
        "finalUrl": "https://www.kaspersky.com/downloads/free-rescue-disk",
        "title": "Free Rescue Disk Download | Kaspersky",
        "checkedAt": "2026-09-09T20:17:57.554921+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kaspersky.com/downloads/free-rescue-disk",
        "status": 200,
        "finalUrl": "https://www.kaspersky.com/downloads/free-rescue-disk",
        "title": "Free Rescue Disk Download | Kaspersky",
        "checkedAt": "2026-09-09T20:17:57.554921+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "memtest",
    "name": "MemTest86+",
    "developer": "MemTest86+ project",
    "description": "Standalone RAM testing outside the operating system; run multiple passes.",
    "categories": [
      "Hardware Diagnostics",
      "Boot & Recovery"
    ],
    "tags": [
      "test RAM memory"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://memtest.org/",
    "officialDownload": "https://memtest.org/",
    "documentation": "https://memtest.org/",
    "localFolder": "00_BOOT/Diagnostics",
    "localExecutable": "",
    "inventoryPatterns": [
      "memtest86plus*.iso",
      "mt86plus*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://memtest.org/",
        "status": 200,
        "finalUrl": "https://memtest.org/",
        "title": "Memtest86+ | The Open-Source Memory Testing Tool",
        "checkedAt": "2026-09-09T20:17:54.521547+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://memtest.org/",
        "status": 200,
        "finalUrl": "https://memtest.org/",
        "title": "Memtest86+ | The Open-Source Memory Testing Tool",
        "checkedAt": "2026-09-09T20:17:54.521547+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "passmark",
    "name": "PassMark MemTest86",
    "developer": "PassMark",
    "description": "UEFI memory diagnostics; edition features and technician rights differ.",
    "categories": [
      "Hardware Diagnostics",
      "Boot & Recovery"
    ],
    "tags": [
      "RAM UEFI"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.memtest86.com/download.htm",
    "officialDownload": "https://www.memtest86.com/download.htm",
    "documentation": "https://www.memtest86.com/download.htm",
    "localFolder": "00_BOOT/Diagnostics/PassMark",
    "localExecutable": "",
    "inventoryPatterns": [
      "memtest86*.img"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.memtest86.com/download.htm",
        "status": 200,
        "finalUrl": "https://www.memtest86.com/download.htm",
        "title": "MemTest86 - Download now!",
        "checkedAt": "2026-09-09T20:17:56.356922+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.memtest86.com/download.htm",
        "status": 200,
        "finalUrl": "https://www.memtest86.com/download.htm",
        "title": "MemTest86 - Download now!",
        "checkedAt": "2026-09-09T20:17:56.356922+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "winaero",
    "name": "Winaero Tweaker",
    "developer": "Winaero",
    "description": "Windows interface and behavior customization with reversible options.",
    "categories": [
      "Windows Tweaks"
    ],
    "tags": [
      "customization",
      "OneDrive startup",
      "Windows Backup prompts",
      "Microsoft account prompts"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://winaero.com/winaero-tweaker/",
    "officialDownload": "https://winaero.com/winaero-tweaker/",
    "documentation": "https://winaero.com/winaero-tweaker/",
    "localFolder": "10_WINDOWS_TOOLBOX/03_Windows-Tweaks/Winaero",
    "localExecutable": "10_WINDOWS_TOOLBOX/03_Windows-Tweaks/Winaero/WinaeroTweaker.exe",
    "inventoryPatterns": [
      "WinaeroTweaker.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://winaero.com/winaero-tweaker/",
        "status": 200,
        "finalUrl": "https://winaero.com/winaero-tweaker/",
        "title": "Winaero Tweaker",
        "checkedAt": "2026-09-09T20:17:55.010055+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://winaero.com/winaero-tweaker/",
        "status": 200,
        "finalUrl": "https://winaero.com/winaero-tweaker/",
        "title": "Winaero Tweaker",
        "checkedAt": "2026-09-09T20:17:55.010055+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "shutup",
    "name": "O&O ShutUp10++",
    "developer": "O&O Software",
    "description": "Review privacy, telemetry and Windows feature settings with recommendations.",
    "categories": [
      "Windows Privacy",
      "Windows AI Controls"
    ],
    "tags": [
      "telemetry advertising OneDrive Copilot AI",
      "ShutUp10++",
      "OneDrive startup",
      "Windows Backup prompts",
      "Microsoft account prompts"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 3,
    "officialWebsite": "https://www.oo-software.com/en/shutup10",
    "officialDownload": "https://www.oo-software.com/en/shutup10",
    "documentation": "https://www.oo-software.com/en/shutup10",
    "localFolder": "10_WINDOWS_TOOLBOX/02_Privacy-Telemetry/ShutUp10",
    "localExecutable": "10_WINDOWS_TOOLBOX/02_Privacy-Telemetry/ShutUp10/OOSU10.exe",
    "inventoryPatterns": [
      "OOSU10.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "The current official page brands this O&O ShutUp10, with free and Premium choices. The catalog retains the familiar ShutUp10++ name for search.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.oo-software.com/en/shutup10",
        "status": 200,
        "finalUrl": "https://www.oo-software.com/en/shutup10",
        "title": "O&O ShutUp10 - O&O Software GmbH",
        "checkedAt": "2026-09-09T20:18:02.619848+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.oo-software.com/en/shutup10",
        "status": 200,
        "finalUrl": "https://www.oo-software.com/en/shutup10",
        "title": "O&O ShutUp10 - O&O Software GmbH",
        "checkedAt": "2026-09-09T20:18:02.619848+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "win11debloat",
    "name": "Win11Debloat",
    "developer": "Raphire",
    "description": "Selective app removal and controls for telemetry, Copilot, Recall, Click to Do and app AI features.",
    "categories": [
      "Windows Debloat",
      "Windows Privacy",
      "Windows AI Controls",
      "Account & OOBE"
    ],
    "tags": [
      "AI Windows AI Edge AI Paint AI Notepad AI OneDrive Bing suggestions consumer features",
      "OneDrive startup",
      "Windows Backup prompts",
      "Microsoft account prompts"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://github.com/Raphire/Win11Debloat",
    "officialDownload": "https://github.com/Raphire/Win11Debloat/releases",
    "documentation": "https://github.com/Raphire/Win11Debloat",
    "localFolder": "10_WINDOWS_TOOLBOX/04_App-Debloat/Win11Debloat",
    "localExecutable": "10_WINDOWS_TOOLBOX/04_App-Debloat/Win11Debloat/Win11Debloat.ps1",
    "inventoryPatterns": [
      "Win11Debloat.ps1"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "githubRepo": "Raphire/Win11Debloat",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/Raphire/Win11Debloat",
        "status": 200,
        "finalUrl": "https://github.com/Raphire/Win11Debloat",
        "title": "GitHub - Raphire/Win11Debloat: A simple, lightweight PowerShell script that allows you to remove pre-installed apps, disable telemetry, as well as perform various other changes to declutter and customize your Windows experience. Win11Debloat works for both Windows 10 and Windows 11. · GitHub",
        "checkedAt": "2026-09-09T20:17:52.179886+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/Raphire/Win11Debloat/releases",
        "status": 200,
        "finalUrl": "https://github.com/Raphire/Win11Debloat/releases",
        "title": "Releases · Raphire/Win11Debloat · GitHub",
        "checkedAt": "2026-09-09T20:17:52.555819+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "winutil",
    "name": "Chris Titus Tech WinUtil",
    "developer": "Chris Titus Tech",
    "description": "Interactive Windows tweaks, repair, update settings and software management; some functions need internet.",
    "categories": [
      "Windows Tweaks",
      "Windows Repair",
      "Windows Debloat",
      "Windows AI Controls",
      "Software Installers"
    ],
    "tags": [
      "debloat AI Copilot Windows repair updates"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://github.com/ChrisTitusTech/winutil",
    "officialDownload": "https://github.com/ChrisTitusTech/winutil/releases",
    "documentation": "https://github.com/ChrisTitusTech/winutil",
    "localFolder": "10_WINDOWS_TOOLBOX/03_Windows-Tweaks/WinUtil",
    "localExecutable": "10_WINDOWS_TOOLBOX/03_Windows-Tweaks/WinUtil/winutil.ps1",
    "inventoryPatterns": [
      "winutil.ps1"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "githubRepo": "ChrisTitusTech/winutil",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/ChrisTitusTech/winutil",
        "status": 200,
        "finalUrl": "https://github.com/ChrisTitusTech/winutil",
        "title": "GitHub - ChrisTitusTech/winutil: Chris Titus Tech's Windows Utility - Install Programs, Tweaks, Fixes, and Updates · GitHub",
        "checkedAt": "2026-09-09T20:17:52.084613+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/ChrisTitusTech/winutil/releases",
        "status": 200,
        "finalUrl": "https://github.com/ChrisTitusTech/winutil/releases",
        "title": "Releases · ChrisTitusTech/winutil · GitHub",
        "checkedAt": "2026-09-09T20:17:52.851087+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "appbuster",
    "name": "O&O AppBuster",
    "developer": "O&O Software",
    "description": "Remove optional Windows apps; restoration may require Store access or source packages.",
    "categories": [
      "Windows Debloat"
    ],
    "tags": [
      "built-in apps restore"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://www.oo-software.com/en/ooappbuster",
    "officialDownload": "https://www.oo-software.com/en/ooappbuster",
    "documentation": "https://www.oo-software.com/en/ooappbuster",
    "localFolder": "10_WINDOWS_TOOLBOX/04_App-Debloat/AppBuster",
    "localExecutable": "10_WINDOWS_TOOLBOX/04_App-Debloat/AppBuster/OOAPB.exe",
    "inventoryPatterns": [
      "OOAPB.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.oo-software.com/en/ooappbuster",
        "status": 200,
        "finalUrl": "https://www.oo-software.com/en/ooappbuster",
        "title": "O&O AppBuster - O&O Software GmbH",
        "checkedAt": "2026-09-09T20:17:58.180100+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.oo-software.com/en/ooappbuster",
        "status": 200,
        "finalUrl": "https://www.oo-software.com/en/ooappbuster",
        "title": "O&O AppBuster - O&O Software GmbH",
        "checkedAt": "2026-09-09T20:17:58.180100+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "optimizernxt",
    "name": "OptimizerNXT",
    "developer": "hellzerg",
    "description": "Specialty YAML-driven configuration CLI. Review every operation; never apply a broad tweak bundle blindly.",
    "categories": [
      "Windows Privacy"
    ],
    "tags": [
      "privacy registry services"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://github.com/hellzerg/optimizerNXT",
    "officialDownload": "https://github.com/hellzerg/optimizerNXT/releases",
    "documentation": "https://github.com/hellzerg/optimizerNXT",
    "localFolder": "10_WINDOWS_TOOLBOX/02_Privacy-Telemetry/OptimizerNXT",
    "localExecutable": "10_WINDOWS_TOOLBOX/02_Privacy-Telemetry/OptimizerNXT/optimizerNXT.exe",
    "inventoryPatterns": [
      "optimizerNXT.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "githubRepo": "hellzerg/optimizerNXT",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/hellzerg/optimizerNXT",
        "status": 200,
        "finalUrl": "https://github.com/hellzerg/optimizerNXT",
        "title": "GitHub - hellzerg/optimizerNXT: The finest Windows Optimizer CLI · GitHub",
        "checkedAt": "2026-09-09T20:17:52.354293+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/hellzerg/optimizerNXT/releases",
        "status": 200,
        "finalUrl": "https://github.com/hellzerg/optimizerNXT/releases",
        "title": "Releases · hellzerg/optimizerNXT · GitHub",
        "checkedAt": "2026-09-09T20:17:52.423548+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "revo",
    "name": "Revo Uninstaller Pro Portable",
    "developer": "VS Revo Group",
    "description": "Licensed portable uninstaller with monitored uninstall and leftover review.",
    "categories": [
      "Uninstallers",
      "Licensed Tools"
    ],
    "tags": [
      "stubborn software"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Portable licensing is per user rather than per computer. Obtain the paid portable package from your account and verify the current license scope for client service.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 80,
    "officialWebsite": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
    "officialDownload": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
    "documentation": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
    "localFolder": "80_LICENSED_TOOLS/Revo",
    "localExecutable": "80_LICENSED_TOOLS/Revo/RevoUPPort.exe",
    "inventoryPatterns": [
      "RevoUPPort.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "5.5.2",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
        "status": 200,
        "finalUrl": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
        "title": "Download Revo Uninstaller Freeware - Free and Full Download",
        "checkedAt": "2026-09-09T20:17:58.355650+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
        "status": 200,
        "finalUrl": "https://www.revouninstaller.com/revo-uninstaller-free-download/",
        "title": "Download Revo Uninstaller Freeware - Free and Full Download",
        "checkedAt": "2026-09-09T20:17:58.355650+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "bcu",
    "name": "Bulk Crap Uninstaller",
    "developer": "Klocman",
    "description": "Open-source batch uninstaller; preview selected programs and leftovers.",
    "categories": [
      "Uninstallers"
    ],
    "tags": [
      "BCU BCUninstaller stubborn software"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.bcuninstaller.com/",
    "officialDownload": "https://www.bcuninstaller.com/",
    "documentation": "https://www.bcuninstaller.com/",
    "localFolder": "10_WINDOWS_TOOLBOX/01_Uninstallers/BCUninstaller",
    "localExecutable": "10_WINDOWS_TOOLBOX/01_Uninstallers/BCUninstaller/BCUninstaller.exe",
    "inventoryPatterns": [
      "BCUninstaller.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.bcuninstaller.com/",
        "status": 200,
        "finalUrl": "https://www.bcuninstaller.com/",
        "title": "Bulk Crap Uninstaller - Remove large amounts of unwanted applications",
        "checkedAt": "2026-09-09T20:17:54.857733+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.bcuninstaller.com/",
        "status": 200,
        "finalUrl": "https://www.bcuninstaller.com/",
        "title": "Bulk Crap Uninstaller - Remove large amounts of unwanted applications",
        "checkedAt": "2026-09-09T20:17:54.857733+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "geek",
    "name": "Geek Uninstaller",
    "developer": "Thomas Koen",
    "description": "Small single-app uninstaller; free edition is personal-use only.",
    "categories": [
      "Uninstallers"
    ],
    "tags": [
      "uninstall"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 6,
    "officialWebsite": "https://geekuninstaller.com/download",
    "officialDownload": "https://geekuninstaller.com/download",
    "documentation": "https://geekuninstaller.com/download",
    "localFolder": "10_WINDOWS_TOOLBOX/01_Uninstallers/Geek",
    "localExecutable": "10_WINDOWS_TOOLBOX/01_Uninstallers/Geek/geek.exe",
    "inventoryPatterns": [
      "geek.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "1.5.4.180",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://geekuninstaller.com/download",
        "status": 200,
        "finalUrl": "https://geekuninstaller.com/download",
        "title": "Geek Uninstaller - Download",
        "checkedAt": "2026-09-09T20:17:51.438751+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://geekuninstaller.com/download",
        "status": 200,
        "finalUrl": "https://geekuninstaller.com/download",
        "title": "Geek Uninstaller - Download",
        "checkedAt": "2026-09-09T20:17:51.438751+00:00",
        "contentType": "text/html"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "hibit",
    "name": "HiBit Uninstaller",
    "developer": "HiBitSoft",
    "description": "Alternative uninstaller. Use uninstall functions only; skip registry cleaning and speed claims.",
    "categories": [
      "Uninstallers"
    ],
    "tags": [
      "uninstall"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.hibitsoft.ir/Uninstaller.html",
    "officialDownload": "https://www.hibitsoft.ir/Uninstaller.html",
    "documentation": "https://www.hibitsoft.ir/Uninstaller.html",
    "localFolder": "10_WINDOWS_TOOLBOX/01_Uninstallers/HiBit",
    "localExecutable": "",
    "inventoryPatterns": [
      "HiBitUninstaller*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "4.0.10",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.hibitsoft.ir/Uninstaller.html",
        "status": 200,
        "finalUrl": "https://www.hibitsoft.ir/Uninstaller.html",
        "title": "HiBit Uninstaller",
        "checkedAt": "2026-09-09T20:17:56.941318+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.hibitsoft.ir/Uninstaller.html",
        "status": 200,
        "finalUrl": "https://www.hibitsoft.ir/Uninstaller.html",
        "title": "HiBit Uninstaller",
        "checkedAt": "2026-09-09T20:17:56.941318+00:00",
        "contentType": "text/html"
      }
    },
    "sourceReviewNotes": "Current publisher/project page reviewed on 2026-09-09. This is source provenance, not independent software safety certification."
  },
  {
    "id": "rufus",
    "name": "Rufus Portable",
    "developer": "Akeo",
    "description": "Create Windows installation USB media; supported setup choices vary by Windows release.",
    "categories": [
      "USB Tools",
      "Account & OOBE"
    ],
    "tags": [
      "OOBE local account Windows install"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 3,
    "officialWebsite": "https://rufus.ie/",
    "officialDownload": "https://rufus.ie/",
    "documentation": "https://rufus.ie/",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/Rufus",
    "localExecutable": "",
    "inventoryPatterns": [
      "rufus*p.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://rufus.ie/",
        "status": 200,
        "finalUrl": "https://rufus.ie/",
        "title": "Rufus - The Official Website (Download, New Releases)",
        "checkedAt": "2026-09-09T20:17:53.976953+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://rufus.ie/",
        "status": 200,
        "finalUrl": "https://rufus.ie/",
        "title": "Rufus - The Official Website (Download, New Releases)",
        "checkedAt": "2026-09-09T20:17:53.976953+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "ntlite",
    "name": "NTLite",
    "developer": "Nlitesoft",
    "description": "Customize Windows images and unattended setup; removing components can break updates.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "unattended setup local account"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.ntlite.com/download/",
    "officialDownload": "https://www.ntlite.com/download/",
    "documentation": "https://www.ntlite.com/download/",
    "localFolder": "10_WINDOWS_TOOLBOX/06_Account-OOBE/NTLite",
    "localExecutable": "",
    "inventoryPatterns": [
      "NTLite*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ntlite.com/download/",
        "status": 200,
        "finalUrl": "https://ntlite.com/download/",
        "title": "Download | NTLite",
        "checkedAt": "2026-09-09T20:17:57.138313+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.ntlite.com/download/",
        "status": 200,
        "finalUrl": "https://ntlite.com/download/",
        "title": "Download | NTLite",
        "checkedAt": "2026-09-09T20:17:57.138313+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "easeus",
    "name": "EaseUS Partition Master",
    "developer": "EaseUS",
    "description": "Licensed partition and migration option; keep your authorized installer and license separately.",
    "categories": [
      "Disk & Partition",
      "Licensed Tools"
    ],
    "tags": [
      "SSD partition"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://www.easeus.com/partition-manager/",
    "officialDownload": "https://www.easeus.com/partition-manager/",
    "documentation": "https://www.easeus.com/partition-manager/",
    "localFolder": "80_LICENSED_TOOLS/EaseUS",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.easeus.com/partition-manager/",
        "status": 200,
        "finalUrl": "https://www.easeus.com/partition-manager/",
        "title": "EaseUS Partition Master | Best Partition Software for All Windows Users.",
        "checkedAt": "2026-09-09T20:17:55.255165+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.easeus.com/partition-manager/",
        "status": 200,
        "finalUrl": "https://www.easeus.com/partition-manager/",
        "title": "EaseUS Partition Master | Best Partition Software for All Windows Users.",
        "checkedAt": "2026-09-09T20:17:55.255165+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "diskgenius",
    "name": "DiskGenius",
    "developer": "Eassos",
    "description": "Partition, file recovery and cloning tools with edition-specific capabilities.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "SSD clone recover files"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://www.diskgenius.com/download.php",
    "officialDownload": "https://www.diskgenius.com/download.php",
    "documentation": "https://www.diskgenius.com/download.php",
    "localFolder": "10_WINDOWS_TOOLBOX/14_Specialty/DiskGenius",
    "localExecutable": "10_WINDOWS_TOOLBOX/14_Specialty/DiskGenius/DiskGenius.exe",
    "inventoryPatterns": [
      "DiskGenius.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.diskgenius.com/download.php",
        "status": 200,
        "finalUrl": "https://www.diskgenius.com/download.php",
        "title": "DiskGenius Download Center | Free Download DiskGenius",
        "checkedAt": "2026-09-09T20:17:55.224607+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.diskgenius.com/download.php",
        "status": 200,
        "finalUrl": "https://www.diskgenius.com/download.php",
        "title": "DiskGenius Download Center | Free Download DiskGenius",
        "checkedAt": "2026-09-09T20:17:55.224607+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "minitool",
    "name": "MiniTool Partition Wizard",
    "developer": "MiniTool",
    "description": "Optional partition manager; confirm whether your edition permits commercial service.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "partition SSD"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.partitionwizard.com/download.html",
    "officialDownload": "https://www.partitionwizard.com/download.html",
    "documentation": "https://www.partitionwizard.com/download.html",
    "localFolder": "10_WINDOWS_TOOLBOX/14_Specialty/MiniTool",
    "localExecutable": "",
    "inventoryPatterns": [
      "pw*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.partitionwizard.com/download.html",
        "status": 200,
        "finalUrl": "https://www.partitionwizard.com/download.html",
        "title": "Free Download MiniTool Partition Wizard for Windows PC and Server",
        "checkedAt": "2026-09-09T20:17:57.371045+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.partitionwizard.com/download.html",
        "status": 200,
        "finalUrl": "https://www.partitionwizard.com/download.html",
        "title": "Free Download MiniTool Partition Wizard for Windows PC and Server",
        "checkedAt": "2026-09-09T20:17:57.371045+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "aomei",
    "name": "AOMEI Partition Assistant",
    "developer": "AOMEI",
    "description": "Optional partition suite with separate paid technician editions.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "partition SSD"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.diskpart.com/download.html",
    "officialDownload": "https://www.diskpart.com/download.html",
    "documentation": "https://www.diskpart.com/download.html",
    "localFolder": "10_WINDOWS_TOOLBOX/14_Specialty/AOMEI",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.diskpart.com/download.html",
        "status": 200,
        "finalUrl": "https://www.diskpart.com/download.html",
        "title": "Free Download Hard Disk Partition Manager Software | AOMEI Partition Assistant Download",
        "checkedAt": "2026-09-09T20:17:55.544811+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.diskpart.com/download.html",
        "status": 200,
        "finalUrl": "https://www.diskpart.com/download.html",
        "title": "Free Download Hard Disk Partition Manager Software | AOMEI Partition Assistant Download",
        "checkedAt": "2026-09-09T20:17:55.544811+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "macrium",
    "name": "Macrium Reflect",
    "developer": "Macrium Software",
    "description": "Paid Windows image backup and restore; select a current authorized edition.",
    "categories": [
      "Imaging & Cloning",
      "Licensed Tools"
    ],
    "tags": [
      "SSD clone backup"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 500,
    "officialWebsite": "https://www.macrium.com/products/home",
    "officialDownload": "https://www.macrium.com/products/home",
    "documentation": "https://www.macrium.com/products/home",
    "localFolder": "80_LICENSED_TOOLS/Other/Macrium",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.macrium.com/products/home",
        "status": 200,
        "finalUrl": "https://www.macrium.com/products/home",
        "title": "Macrium Reflect Home | The complete backup solution for personal use.",
        "checkedAt": "2026-09-09T20:17:56.841494+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.macrium.com/products/home",
        "status": 200,
        "finalUrl": "https://www.macrium.com/products/home",
        "title": "Macrium Reflect Home | The complete backup solution for personal use.",
        "checkedAt": "2026-09-09T20:17:56.841494+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "veeam",
    "name": "Veeam Agent for Microsoft Windows",
    "developer": "Veeam",
    "description": "Windows endpoint backup and recovery; installation and recovery media preparation required.",
    "categories": [
      "Imaging & Cloning"
    ],
    "tags": [
      "backup image"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 800,
    "officialWebsite": "https://www.veeam.com/products/free/microsoft-windows.html",
    "officialDownload": "https://www.veeam.com/products/free/microsoft-windows.html",
    "documentation": "https://www.veeam.com/products/free/microsoft-windows.html",
    "localFolder": "40_INSTALLERS/Utilities/Veeam",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.veeam.com/products/free/microsoft-windows.html",
        "status": 200,
        "finalUrl": "https://www.veeam.com/products/free/microsoft-windows.html",
        "title": "Free Windows Backup Solution for PCs and Endpoints",
        "checkedAt": "2026-09-09T20:17:59.197256+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.veeam.com/products/free/microsoft-windows.html",
        "status": 200,
        "finalUrl": "https://www.veeam.com/products/free/microsoft-windows.html",
        "title": "Free Windows Backup Solution for PCs and Endpoints",
        "checkedAt": "2026-09-09T20:17:59.197256+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "testdisk",
    "name": "TestDisk",
    "developer": "CGSecurity",
    "description": "Recover lost partitions and inspect filesystems; analyze an image before writing changes.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "recover files partition"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 40,
    "officialWebsite": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "officialDownload": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "documentation": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "localFolder": "20_PORTABLE_APPS/Misc/TestDisk",
    "localExecutable": "20_PORTABLE_APPS/Misc/TestDisk/testdisk_win.exe",
    "inventoryPatterns": [
      "testdisk_win.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "status": 200,
        "finalUrl": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "title": "TestDisk Download - CGSecurity",
        "checkedAt": "2026-09-09T20:17:55.726221+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "status": 200,
        "finalUrl": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "title": "TestDisk Download - CGSecurity",
        "checkedAt": "2026-09-09T20:17:55.726221+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "photorec",
    "name": "PhotoRec",
    "developer": "CGSecurity",
    "description": "Signature-based file recovery when directory structures are damaged; filenames may be lost.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "recover files photos"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 40,
    "officialWebsite": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "officialDownload": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "documentation": "https://www.cgsecurity.org/wiki/TestDisk_Download",
    "localFolder": "20_PORTABLE_APPS/Misc/TestDisk",
    "localExecutable": "20_PORTABLE_APPS/Misc/TestDisk/photorec_win.exe",
    "inventoryPatterns": [
      "photorec_win.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "status": 200,
        "finalUrl": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "title": "TestDisk Download - CGSecurity",
        "checkedAt": "2026-09-09T20:17:55.726221+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "status": 200,
        "finalUrl": "https://www.cgsecurity.org/wiki/TestDisk_Download",
        "title": "TestDisk Download - CGSecurity",
        "checkedAt": "2026-09-09T20:17:55.726221+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "dmde",
    "name": "DMDE",
    "developer": "DMDE Software",
    "description": "Inspect disks, recover files and work with images; free edition has recovery limits.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "recover files failing disk SSD"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://dmde.com/download.html",
    "officialDownload": "https://dmde.com/download.html",
    "documentation": "https://dmde.com/download.html",
    "localFolder": "20_PORTABLE_APPS/Misc/DMDE",
    "localExecutable": "20_PORTABLE_APPS/Misc/DMDE/dmde.exe",
    "inventoryPatterns": [
      "dmde.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://dmde.com/download.html",
        "status": 200,
        "finalUrl": "https://dmde.com/download.html",
        "title": "Download DMDE - All Versions (DM Disk Editor and Data Recovery Software)",
        "checkedAt": "2026-09-09T20:17:51.136549+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://dmde.com/download.html",
        "status": 200,
        "finalUrl": "https://dmde.com/download.html",
        "title": "Download DMDE - All Versions (DM Disk Editor and Data Recovery Software)",
        "checkedAt": "2026-09-09T20:17:51.136549+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "recuva",
    "name": "Recuva",
    "developer": "Piriform / CCleaner",
    "description": "Simple deleted-file recovery for healthy media; do not install onto the source drive.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "undelete"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.ccleaner.com/recuva/download",
    "officialDownload": "https://www.ccleaner.com/recuva/download",
    "documentation": "https://www.ccleaner.com/recuva/download",
    "localFolder": "40_INSTALLERS/Utilities/Recuva",
    "localExecutable": "",
    "inventoryPatterns": [
      "rcsetup*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ccleaner.com/recuva/download",
        "status": 200,
        "finalUrl": "https://www.ccleaner.com/recuva/download",
        "title": "Recuva - Free Download",
        "checkedAt": "2026-09-09T20:17:54.969444+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.ccleaner.com/recuva/download",
        "status": 200,
        "finalUrl": "https://www.ccleaner.com/recuva/download",
        "title": "Recuva - Free Download",
        "checkedAt": "2026-09-09T20:17:54.969444+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "rstudio",
    "name": "R-Studio",
    "developer": "R-Tools Technology",
    "description": "Commercial recovery suite with filesystem and RAID reconstruction tools.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "RAID recover files"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://www.r-studio.com/data-recovery-software/",
    "officialDownload": "https://www.r-studio.com/data-recovery-software/",
    "documentation": "https://www.r-studio.com/data-recovery-software/",
    "localFolder": "80_LICENSED_TOOLS/Other/R-Studio",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.r-studio.com/data-recovery-software/",
        "status": 200,
        "finalUrl": "https://www.r-studio.com/data-recovery-software/",
        "title": "R-STUDIO Data Recovery Software",
        "checkedAt": "2026-09-09T20:17:57.802833+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.r-studio.com/data-recovery-software/",
        "status": 200,
        "finalUrl": "https://www.r-studio.com/data-recovery-software/",
        "title": "R-STUDIO Data Recovery Software",
        "checkedAt": "2026-09-09T20:17:57.802833+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "ufs",
    "name": "UFS Explorer",
    "developer": "SysDev Laboratories",
    "description": "Specialty commercial recovery for complex filesystems, NAS and RAID.",
    "categories": [
      "Data Recovery",
      "Licensed Tools"
    ],
    "tags": [
      "NAS RAID recovery"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Paid",
    "personalLicenseNotes": "Paid license or evaluation terms required.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://www.ufsexplorer.com/",
    "officialDownload": "https://www.ufsexplorer.com/",
    "documentation": "https://www.ufsexplorer.com/",
    "localFolder": "80_LICENSED_TOOLS/Other/UFS-Explorer",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ufsexplorer.com/",
        "status": 200,
        "finalUrl": "https://www.ufsexplorer.com/",
        "title": "Tried and trusted data recovery software solutions",
        "checkedAt": "2026-09-09T20:17:59.017604+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.ufsexplorer.com/",
        "status": 200,
        "finalUrl": "https://www.ufsexplorer.com/",
        "title": "Tried and trusted data recovery software solutions",
        "checkedAt": "2026-09-09T20:17:59.017604+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "cdi",
    "name": "CrystalDiskInfo",
    "developer": "Crystal Dew World",
    "description": "Read SMART attributes, temperature and drive health indicators; USB bridges may hide SMART.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD HDD SMART health failing disk"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://crystalmark.info/en/software/crystaldiskinfo/",
    "officialDownload": "https://crystalmark.info/en/software/crystaldiskinfo/",
    "documentation": "https://crystalmark.info/en/software/crystaldiskinfo/",
    "localFolder": "20_PORTABLE_APPS/Misc/CrystalDiskInfo",
    "localExecutable": "20_PORTABLE_APPS/Misc/CrystalDiskInfo/DiskInfo64.exe",
    "inventoryPatterns": [
      "DiskInfo64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://crystalmark.info/en/software/crystaldiskinfo/",
        "status": 200,
        "finalUrl": "https://crystalmark.info/en/software/crystaldiskinfo/",
        "title": "CrystalDiskInfo – Crystal Dew World",
        "checkedAt": "2026-09-09T20:17:51.769542+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://crystalmark.info/en/software/crystaldiskinfo/",
        "status": 200,
        "finalUrl": "https://crystalmark.info/en/software/crystaldiskinfo/",
        "title": "CrystalDiskInfo – Crystal Dew World",
        "checkedAt": "2026-09-09T20:17:51.769542+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "cdm",
    "name": "CrystalDiskMark",
    "developer": "Crystal Dew World",
    "description": "Storage throughput benchmark; writes test data and is unsuitable for failing drives.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD HDD benchmark"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://crystalmark.info/en/software/crystaldiskmark/",
    "officialDownload": "https://crystalmark.info/en/software/crystaldiskmark/",
    "documentation": "https://crystalmark.info/en/software/crystaldiskmark/",
    "localFolder": "20_PORTABLE_APPS/Misc/CrystalDiskMark",
    "localExecutable": "20_PORTABLE_APPS/Misc/CrystalDiskMark/DiskMark64.exe",
    "inventoryPatterns": [
      "DiskMark64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://crystalmark.info/en/software/crystaldiskmark/",
        "status": 200,
        "finalUrl": "https://crystalmark.info/en/software/crystaldiskmark/",
        "title": "CrystalDiskMark – Crystal Dew World",
        "checkedAt": "2026-09-09T20:17:52.329734+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://crystalmark.info/en/software/crystaldiskmark/",
        "status": 200,
        "finalUrl": "https://crystalmark.info/en/software/crystaldiskmark/",
        "title": "CrystalDiskMark – Crystal Dew World",
        "checkedAt": "2026-09-09T20:17:52.329734+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "gsmart",
    "name": "GSmartControl",
    "developer": "GSmartControl project",
    "description": "Graphical SMART viewer and drive self-test controller.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD HDD SMART"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://gsmartcontrol.shaduri.dev/downloads",
    "officialDownload": "https://gsmartcontrol.shaduri.dev/downloads",
    "documentation": "https://gsmartcontrol.shaduri.dev/downloads",
    "localFolder": "20_PORTABLE_APPS/Misc/GSmartControl",
    "localExecutable": "20_PORTABLE_APPS/Misc/GSmartControl/gsmartcontrol.exe",
    "inventoryPatterns": [
      "gsmartcontrol.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://gsmartcontrol.shaduri.dev/downloads",
        "status": 200,
        "finalUrl": "https://gsmartcontrol.shaduri.dev/downloads",
        "title": "Downloads · GSmartControl",
        "checkedAt": "2026-09-09T20:17:52.491691+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://gsmartcontrol.shaduri.dev/downloads",
        "status": 200,
        "finalUrl": "https://gsmartcontrol.shaduri.dev/downloads",
        "title": "Downloads · GSmartControl",
        "checkedAt": "2026-09-09T20:17:52.491691+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "smartmontools",
    "name": "smartmontools",
    "developer": "smartmontools project",
    "description": "Read drive SMART and NVMe health; extended tests add load to damaged media.",
    "categories": [
      "Storage Diagnostics",
      "Homelab / Linux"
    ],
    "tags": [
      "SSD HDD SMART smartctl failing disk"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.smartmontools.org/",
    "officialDownload": "https://www.smartmontools.org/",
    "documentation": "https://www.smartmontools.org/",
    "localFolder": "20_PORTABLE_APPS/Misc/smartmontools",
    "localExecutable": "20_PORTABLE_APPS/Misc/smartmontools/smartctl.exe",
    "inventoryPatterns": [
      "smartctl.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official project listing reviewed",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.smartmontools.org/",
        "status": 200,
        "finalUrl": "https://www.smartmontools.org/",
        "title": "Making sure you're not a bot!",
        "checkedAt": "2026-09-09T20:17:58.508673+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.smartmontools.org/",
        "status": 200,
        "finalUrl": "https://www.smartmontools.org/",
        "title": "Making sure you're not a bot!",
        "checkedAt": "2026-09-09T20:17:58.508673+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    },
    "sourceReviewNotes": "Project GitHub releases reviewed; primary domain presents bot challenge. Version remains manual."
  },
  {
    "id": "hddscan",
    "name": "HDDScan",
    "developer": "HDDScan project",
    "description": "Specialty storage diagnostics. Avoid write/erase tests and confirm current hardware support.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "HDD surface"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://hddscan.com/",
    "officialDownload": "https://hddscan.com/",
    "documentation": "https://hddscan.com/",
    "localFolder": "20_PORTABLE_APPS/Misc/HDDScan",
    "localExecutable": "20_PORTABLE_APPS/Misc/HDDScan/HDDScan.exe",
    "inventoryPatterns": [
      "HDDScan.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "The official site still offers 4.1; recent development could not be established. Kept P4 for legacy/specialty diagnosis, not a default modern SSD recommendation.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://hddscan.com/",
        "status": 200,
        "finalUrl": "https://hddscan.com/",
        "title": "HDDScan - FREE HDD and SSD Test Diagnostics Software with RAID and USB Flash support",
        "checkedAt": "2026-09-09T20:17:52.958872+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://hddscan.com/",
        "status": 200,
        "finalUrl": "https://hddscan.com/",
        "title": "HDDScan - FREE HDD and SSD Test Diagnostics Software with RAID and USB Flash support",
        "checkedAt": "2026-09-09T20:17:52.958872+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "samsung",
    "name": "Samsung Magician",
    "developer": "Samsung",
    "description": "Supported Samsung SSD health, maintenance and firmware; features depend on model.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD firmware Samsung"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://semiconductor.samsung.com/consumer-storage/magician/",
    "officialDownload": "https://semiconductor.samsung.com/consumer-storage/magician/",
    "documentation": "https://semiconductor.samsung.com/consumer-storage/magician/",
    "localFolder": "50_FIRMWARE/SSD/Samsung",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://semiconductor.samsung.com/consumer-storage/magician/",
        "status": 200,
        "finalUrl": "https://semiconductor.samsung.com/consumer-storage/magician/",
        "title": "Samsung Magician Software Download | Consumer Storage | Samsung Semiconductor Global",
        "checkedAt": "2026-09-09T20:17:54.198156+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://semiconductor.samsung.com/consumer-storage/magician/",
        "status": 200,
        "finalUrl": "https://semiconductor.samsung.com/consumer-storage/magician/",
        "title": "Samsung Magician Software Download | Consumer Storage | Samsung Semiconductor Global",
        "checkedAt": "2026-09-09T20:17:54.198156+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "wd",
    "name": "Western Digital / SanDisk support",
    "developer": "Western Digital",
    "description": "Select the exact drive model to locate its current utility and firmware; older Dashboard packages may be retired.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "SSD HDD Western Digital SanDisk"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://support-en.wd.com/",
    "officialDownload": "https://support-en.wd.com/",
    "documentation": "https://support-en.wd.com/",
    "localFolder": "50_FIRMWARE/SSD/WD",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://support-en.wd.com/",
        "status": 200,
        "finalUrl": "https://www.westerndigital.com/support",
        "title": "",
        "checkedAt": "2026-09-09T20:17:55.052759+00:00",
        "contentType": "text/html;charset=utf-8"
      },
      "download": {
        "url": "https://support-en.wd.com/",
        "status": 200,
        "finalUrl": "https://www.westerndigital.com/support",
        "title": "",
        "checkedAt": "2026-09-09T20:17:55.052759+00:00",
        "contentType": "text/html;charset=utf-8"
      }
    }
  },
  {
    "id": "seatools",
    "name": "SeaTools",
    "developer": "Seagate",
    "description": "Manufacturer drive diagnostics; distinguish read tests from erase and repair functions.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD HDD Seagate"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://www.seagate.com/support/downloads/seatools/",
    "officialDownload": "https://www.seagate.com/support/downloads/seatools/",
    "documentation": "https://www.seagate.com/support/downloads/seatools/",
    "localFolder": "50_FIRMWARE/SSD/Seagate",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.seagate.com/support/downloads/seatools/",
        "status": 200,
        "finalUrl": "https://www.seagate.com/support/downloads/seatools/",
        "title": "SeaTools | Seagate US",
        "checkedAt": "2026-09-09T20:17:57.871611+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.seagate.com/support/downloads/seatools/",
        "status": 200,
        "finalUrl": "https://www.seagate.com/support/downloads/seatools/",
        "title": "SeaTools | Seagate US",
        "checkedAt": "2026-09-09T20:17:57.871611+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "crucial",
    "name": "Crucial Storage Executive",
    "developer": "Micron / Crucial",
    "description": "Supported Crucial SSD monitoring and firmware tools; check model support first.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD Crucial firmware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 250,
    "officialWebsite": "https://www.crucial.com/support/storage-executive",
    "officialDownload": "https://www.crucial.com/support/storage-executive",
    "documentation": "https://www.crucial.com/support/storage-executive",
    "localFolder": "50_FIRMWARE/SSD/Crucial",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": " Official page rejects both direct and web retrieval in this audit. Confirm current utility and model support before downloading.",
    "sourceStatus": "Manual source check needed",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.crucial.com/support/storage-executive",
        "status": 200,
        "finalUrl": "https://www.crucial.com/support/storage-executive",
        "title": "Request Rejected",
        "checkedAt": "2026-09-09T20:17:55.089341+00:00",
        "contentType": "text/plain"
      },
      "download": {
        "url": "https://www.crucial.com/support/storage-executive",
        "status": 200,
        "finalUrl": "https://www.crucial.com/support/storage-executive",
        "title": "Request Rejected",
        "checkedAt": "2026-09-09T20:17:55.089341+00:00",
        "contentType": "text/plain"
      }
    }
  },
  {
    "id": "solidigm",
    "name": "Solidigm Storage Tool",
    "developer": "Solidigm",
    "description": "Model-specific SSD management and firmware resources.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD firmware Solidigm"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.solidigm.com/support-page/drivers-downloads.html",
    "officialDownload": "https://www.solidigm.com/support-page/drivers-downloads.html",
    "documentation": "https://www.solidigm.com/support-page/drivers-downloads.html",
    "localFolder": "50_FIRMWARE/SSD/Solidigm",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.solidigm.com/support-page/drivers-downloads.html",
        "status": 200,
        "finalUrl": "https://www.solidigm.com/support/drivers-downloads.html",
        "title": "Drivers & Downloads",
        "checkedAt": "2026-09-09T20:17:58.600002+00:00",
        "contentType": "text/html;charset=utf-8"
      },
      "download": {
        "url": "https://www.solidigm.com/support-page/drivers-downloads.html",
        "status": 200,
        "finalUrl": "https://www.solidigm.com/support/drivers-downloads.html",
        "title": "Drivers & Downloads",
        "checkedAt": "2026-09-09T20:17:58.600002+00:00",
        "contentType": "text/html;charset=utf-8"
      }
    }
  },
  {
    "id": "kingston",
    "name": "Kingston SSD Manager",
    "developer": "Kingston",
    "description": "Supported Kingston SSD health and firmware maintenance.",
    "categories": [
      "Storage Diagnostics"
    ],
    "tags": [
      "SSD Kingston firmware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 60,
    "officialWebsite": "https://www.kingston.com/en/support/technical/ssdmanager",
    "officialDownload": "https://www.kingston.com/en/support/technical/ssdmanager",
    "documentation": "https://www.kingston.com/en/support/technical/ssdmanager",
    "localFolder": "50_FIRMWARE/SSD/Kingston",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kingston.com/en/support/technical/ssdmanager",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:55.823954+00:00"
      },
      "download": {
        "url": "https://www.kingston.com/en/support/technical/ssdmanager",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:55.823954+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "hwinfo",
    "name": "HWiNFO",
    "developer": "REALiX",
    "description": "Detailed hardware inventory, sensors and logging for thermal and stability diagnosis.",
    "categories": [
      "Hardware Diagnostics",
      "Gaming"
    ],
    "tags": [
      "GPU CPU temperatures crash"
    ],
    "useCases": [
      "GPU troubleshooting",
      "GPU crash"
    ],
    "priority": "P1",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 25,
    "officialWebsite": "https://www.hwinfo.com/download/",
    "officialDownload": "https://www.hwinfo.com/download/",
    "documentation": "https://www.hwinfo.com/download/",
    "localFolder": "20_PORTABLE_APPS/Misc/HWiNFO",
    "localExecutable": "20_PORTABLE_APPS/Misc/HWiNFO/HWiNFO64.exe",
    "inventoryPatterns": [
      "HWiNFO64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.hwinfo.com/download/",
        "status": 200,
        "finalUrl": "https://www.hwinfo.com/download/",
        "title": "Free Download HWiNFO Sofware | Installer & Portable for Windows, DOS",
        "checkedAt": "2026-09-09T20:17:56.156087+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.hwinfo.com/download/",
        "status": 200,
        "finalUrl": "https://www.hwinfo.com/download/",
        "title": "Free Download HWiNFO Sofware | Installer & Portable for Windows, DOS",
        "checkedAt": "2026-09-09T20:17:56.156087+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "cpuz",
    "name": "CPU-Z",
    "developer": "CPUID",
    "description": "Identify CPU, mainboard and RAM timings; compare configured memory speed.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "CPU RAM motherboard"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.cpuid.com/softwares/cpu-z.html",
    "officialDownload": "https://www.cpuid.com/softwares/cpu-z.html",
    "documentation": "https://www.cpuid.com/softwares/cpu-z.html",
    "localFolder": "20_PORTABLE_APPS/Misc/CPU-Z",
    "localExecutable": "20_PORTABLE_APPS/Misc/CPU-Z/cpuz_x64.exe",
    "inventoryPatterns": [
      "cpuz_x64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.cpuid.com/softwares/cpu-z.html",
        "status": 200,
        "finalUrl": "https://www.cpuid.com/softwares/cpu-z.html",
        "title": "CPU-Z | Softwares | CPUID",
        "checkedAt": "2026-09-09T20:17:56.159097+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.cpuid.com/softwares/cpu-z.html",
        "status": 200,
        "finalUrl": "https://www.cpuid.com/softwares/cpu-z.html",
        "title": "CPU-Z | Softwares | CPUID",
        "checkedAt": "2026-09-09T20:17:56.159097+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "gpuz",
    "name": "GPU-Z",
    "developer": "TechPowerUp",
    "description": "Identify GPU, video BIOS and sensors; log behavior during crashes.",
    "categories": [
      "Hardware Diagnostics",
      "Gaming"
    ],
    "tags": [
      "GPU crash graphics"
    ],
    "useCases": [
      "GPU troubleshooting",
      "GPU crash"
    ],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.techpowerup.com/gpuz/",
    "officialDownload": "https://www.techpowerup.com/gpuz/",
    "documentation": "https://www.techpowerup.com/gpuz/",
    "localFolder": "20_PORTABLE_APPS/Misc/GPU-Z",
    "localExecutable": "",
    "inventoryPatterns": [
      "GPU-Z*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.techpowerup.com/gpuz/",
        "status": 200,
        "finalUrl": "https://www.techpowerup.com/gpuz/",
        "title": "GPU-Z Graphics Card GPU Information Utility",
        "checkedAt": "2026-09-09T20:17:58.901035+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.techpowerup.com/gpuz/",
        "status": 200,
        "finalUrl": "https://www.techpowerup.com/gpuz/",
        "title": "GPU-Z Graphics Card GPU Information Utility",
        "checkedAt": "2026-09-09T20:17:58.901035+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "occt",
    "name": "OCCT",
    "developer": "OCBASE",
    "description": "CPU, GPU, memory and power stability tests; choose one subsystem at a time.",
    "categories": [
      "Hardware Diagnostics",
      "Gaming"
    ],
    "tags": [
      "GPU CPU stress temperatures"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 250,
    "officialWebsite": "https://www.ocbase.com/download",
    "officialDownload": "https://www.ocbase.com/download",
    "documentation": "https://www.ocbase.com/download",
    "localFolder": "20_PORTABLE_APPS/Misc/OCCT",
    "localExecutable": "",
    "inventoryPatterns": [
      "OCCT*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ocbase.com/download",
        "status": 200,
        "finalUrl": "https://www.ocbase.com/download-personal",
        "title": "OCCT Personal Download - OCBASE/OCCT",
        "checkedAt": "2026-09-09T20:17:58.907065+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.ocbase.com/download",
        "status": 200,
        "finalUrl": "https://www.ocbase.com/download-personal",
        "title": "OCCT Personal Download - OCBASE/OCCT",
        "checkedAt": "2026-09-09T20:17:58.907065+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "prime95",
    "name": "Prime95",
    "developer": "GIMPS",
    "description": "CPU and memory stress testing with different FFT workloads; stop on errors or overheating.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "CPU RAM stress"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.mersenne.org/download/",
    "officialDownload": "https://www.mersenne.org/download/",
    "documentation": "https://www.mersenne.org/download/",
    "localFolder": "20_PORTABLE_APPS/Misc/Prime95",
    "localExecutable": "20_PORTABLE_APPS/Misc/Prime95/prime95.exe",
    "inventoryPatterns": [
      "prime95.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.mersenne.org/download/",
        "status": 200,
        "finalUrl": "https://www.mersenne.org/download/",
        "title": "GIMPS - Free Prime95 software downloads - PrimeNet",
        "checkedAt": "2026-09-09T20:17:56.078654+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.mersenne.org/download/",
        "status": 200,
        "finalUrl": "https://www.mersenne.org/download/",
        "title": "GIMPS - Free Prime95 software downloads - PrimeNet",
        "checkedAt": "2026-09-09T20:17:56.078654+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "furmark",
    "name": "FurMark",
    "developer": "Geeks3D",
    "description": "Heavy graphics stress workload to expose cooling and stability issues.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "GPU stress"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://geeks3d.com/furmark/",
    "officialDownload": "https://geeks3d.com/furmark/",
    "documentation": "https://geeks3d.com/furmark/",
    "localFolder": "20_PORTABLE_APPS/Misc/FurMark",
    "localExecutable": "",
    "inventoryPatterns": [
      "FurMark*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://geeks3d.com/furmark/",
        "status": 200,
        "finalUrl": "https://geeks3d.com/furmark/",
        "title": "FurMark Homepage",
        "checkedAt": "2026-09-09T20:17:51.805662+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://geeks3d.com/furmark/",
        "status": 200,
        "finalUrl": "https://geeks3d.com/furmark/",
        "title": "FurMark Homepage",
        "checkedAt": "2026-09-09T20:17:51.805662+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "cinebench",
    "name": "Cinebench",
    "developer": "Maxon",
    "description": "Repeatable rendering benchmark for CPU performance and thermal comparison.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "CPU benchmark stress"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.maxon.net/en/cinebench",
    "officialDownload": "https://www.maxon.net/en/cinebench",
    "documentation": "https://www.maxon.net/en/cinebench",
    "localFolder": "40_INSTALLERS/Utilities/Cinebench",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Monitor temperatures before and during stress testing. Use stable power, save work, stop on errors or overheating; do not stress damaged hardware.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.maxon.net/en/cinebench",
        "status": 200,
        "finalUrl": "https://www.maxon.net/en/cinebench",
        "title": "Evaluate your computer's hardware capabilities | Cinebench from Maxon",
        "checkedAt": "2026-09-09T20:17:57.374569+00:00",
        "contentType": "text/html;charset=utf-8"
      },
      "download": {
        "url": "https://www.maxon.net/en/cinebench",
        "status": 200,
        "finalUrl": "https://www.maxon.net/en/cinebench",
        "title": "Evaluate your computer's hardware capabilities | Cinebench from Maxon",
        "checkedAt": "2026-09-09T20:17:57.374569+00:00",
        "contentType": "text/html;charset=utf-8"
      }
    }
  },
  {
    "id": "hwmonitor",
    "name": "HWMonitor",
    "developer": "CPUID",
    "description": "Simple voltage, fan and temperature overview as an alternative sensor view.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "temperature"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.cpuid.com/softwares/hwmonitor.html",
    "officialDownload": "https://www.cpuid.com/softwares/hwmonitor.html",
    "documentation": "https://www.cpuid.com/softwares/hwmonitor.html",
    "localFolder": "20_PORTABLE_APPS/Misc/HWMonitor",
    "localExecutable": "20_PORTABLE_APPS/Misc/HWMonitor/HWMonitor_x64.exe",
    "inventoryPatterns": [
      "HWMonitor_x64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.cpuid.com/softwares/hwmonitor.html",
        "status": 200,
        "finalUrl": "https://www.cpuid.com/softwares/hwmonitor.html",
        "title": "HWMONITOR | Softwares | CPUID",
        "checkedAt": "2026-09-09T20:17:55.941695+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.cpuid.com/softwares/hwmonitor.html",
        "status": 200,
        "finalUrl": "https://www.cpuid.com/softwares/hwmonitor.html",
        "title": "HWMONITOR | Softwares | CPUID",
        "checkedAt": "2026-09-09T20:17:55.941695+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "coretemp",
    "name": "Core Temp",
    "developer": "ALCPU",
    "description": "Per-core CPU temperature monitoring; review installer options carefully.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "CPU temperature"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.alcpu.com/CoreTemp/",
    "officialDownload": "https://www.alcpu.com/CoreTemp/",
    "documentation": "https://www.alcpu.com/CoreTemp/",
    "localFolder": "20_PORTABLE_APPS/Misc/CoreTemp",
    "localExecutable": "20_PORTABLE_APPS/Misc/CoreTemp/Core Temp.exe",
    "inventoryPatterns": [
      "Core Temp.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.alcpu.com/CoreTemp/",
        "status": 200,
        "finalUrl": "https://www.alcpu.com/CoreTemp/",
        "title": "Core Temp",
        "checkedAt": "2026-09-09T20:17:55.011561+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.alcpu.com/CoreTemp/",
        "status": 200,
        "finalUrl": "https://www.alcpu.com/CoreTemp/",
        "title": "Core Temp",
        "checkedAt": "2026-09-09T20:17:55.011561+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "latencymon",
    "name": "LatencyMon",
    "developer": "Resplendence",
    "description": "Analyze DPC/ISR latency associated with audio dropouts and driver issues.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "audio driver latency"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.resplendence.com/latencymon",
    "officialDownload": "https://www.resplendence.com/latencymon",
    "documentation": "https://www.resplendence.com/latencymon",
    "localFolder": "40_INSTALLERS/Utilities/LatencyMon",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.resplendence.com/latencymon",
        "status": 200,
        "finalUrl": "https://www.resplendence.com/latencymon",
        "title": "Resplendence Software - LatencyMon: suitability checker for real-time audio and other tasks",
        "checkedAt": "2026-09-09T20:17:58.319466+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.resplendence.com/latencymon",
        "status": 200,
        "finalUrl": "https://www.resplendence.com/latencymon",
        "title": "Resplendence Software - LatencyMon: suitability checker for real-time audio and other tasks",
        "checkedAt": "2026-09-09T20:17:58.319466+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "ddu",
    "name": "Display Driver Uninstaller",
    "developer": "Wagnardsoft",
    "description": "Remove graphics driver remnants, preferably in Safe Mode; stage replacement drivers first.",
    "categories": [
      "Drivers",
      "Gaming"
    ],
    "tags": [
      "GPU crash NVIDIA AMD Intel"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
    "officialDownload": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
    "documentation": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
    "localFolder": "10_WINDOWS_TOOLBOX/14_Specialty/DDU",
    "localExecutable": "10_WINDOWS_TOOLBOX/14_Specialty/DDU/Display Driver Uninstaller.exe",
    "inventoryPatterns": [
      "Display Driver Uninstaller.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
        "status": 200,
        "finalUrl": "https://www.wagnardsoft.com/display-driver-uninstaller-ddu",
        "title": "Download Display Driver Uninstaller (DDU) Official Latest Version | Wagnardsoft",
        "checkedAt": "2026-09-09T20:17:59.273487+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.wagnardsoft.com/display-driver-uninstaller-DDU-",
        "status": 200,
        "finalUrl": "https://www.wagnardsoft.com/display-driver-uninstaller-ddu",
        "title": "Download Display Driver Uninstaller (DDU) Official Latest Version | Wagnardsoft",
        "checkedAt": "2026-09-09T20:17:59.273487+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "sdio",
    "name": "Snappy Driver Installer Origin",
    "developer": "SDIO project",
    "description": "Offline driver pack library; stage network packs first and verify hardware IDs before installation.",
    "categories": [
      "Drivers",
      "Hardware Diagnostics"
    ],
    "tags": [
      "no Wi-Fi no network offline drivers"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 80000,
    "officialWebsite": "https://www.snappy-driver-installer.org/",
    "officialDownload": "https://www.snappy-driver-installer.org/",
    "documentation": "https://www.snappy-driver-installer.org/",
    "localFolder": "30_DRIVERS/SDIO",
    "localExecutable": "",
    "inventoryPatterns": [
      "SDIO_x64*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Executable detection does not prove the full offline pack library exists. Preserve indexes and driver packs; inspect package coverage within SDIO before visiting a disconnected PC.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.snappy-driver-installer.org/",
        "status": 200,
        "finalUrl": "https://www.snappy-driver-installer.org/",
        "title": "Snappy Driver Installer Origin – The original driver installation tool for Windows.",
        "checkedAt": "2026-09-09T20:17:58.510676+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.snappy-driver-installer.org/",
        "status": 200,
        "finalUrl": "https://www.snappy-driver-installer.org/",
        "title": "Snappy Driver Installer Origin – The original driver installation tool for Windows.",
        "checkedAt": "2026-09-09T20:17:58.510676+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "wireshark",
    "name": "Wireshark",
    "developer": "Wireshark Foundation",
    "description": "Packet capture and protocol analysis. Live capture on Windows requires a capture driver.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "packet loss DNS DHCP"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://www.wireshark.org/download.html",
    "officialDownload": "https://www.wireshark.org/download.html",
    "documentation": "https://www.wireshark.org/download.html",
    "localFolder": "20_PORTABLE_APPS/Misc/Wireshark",
    "localExecutable": "20_PORTABLE_APPS/Misc/Wireshark/Wireshark.exe",
    "inventoryPatterns": [
      "Wireshark.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.wireshark.org/download.html",
        "status": 200,
        "finalUrl": "https://www.wireshark.org/download.html",
        "title": "Wireshark • Go Deep | Download",
        "checkedAt": "2026-09-09T20:17:58.801670+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.wireshark.org/download.html",
        "status": 200,
        "finalUrl": "https://www.wireshark.org/download.html",
        "title": "Wireshark • Go Deep | Download",
        "checkedAt": "2026-09-09T20:17:58.801670+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "nmap",
    "name": "Nmap",
    "developer": "Nmap project",
    "description": "Authorized host discovery and service checks; review Npcap and commercial redistribution terms.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "LAN discovery port scan"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://nmap.org/download.html",
    "officialDownload": "https://nmap.org/download.html",
    "documentation": "https://nmap.org/download.html",
    "localFolder": "40_INSTALLERS/Utilities/Nmap",
    "localExecutable": "",
    "inventoryPatterns": [
      "nmap*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://nmap.org/download.html",
        "status": 200,
        "finalUrl": "https://nmap.org/download.html",
        "title": "Download the Free Nmap Security Scanner for Linux/Mac/Windows",
        "checkedAt": "2026-09-09T20:17:53.835079+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://nmap.org/download.html",
        "status": 200,
        "finalUrl": "https://nmap.org/download.html",
        "title": "Download the Free Nmap Security Scanner for Linux/Mac/Windows",
        "checkedAt": "2026-09-09T20:17:53.835079+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "angryip",
    "name": "Angry IP Scanner",
    "developer": "Angry IP Scanner project",
    "description": "Quick authorized LAN host discovery; Java runtime may be required.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "LAN discovery"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://angryip.org/download/",
    "officialDownload": "https://angryip.org/download/",
    "documentation": "https://angryip.org/download/",
    "localFolder": "20_PORTABLE_APPS/Misc/AngryIP",
    "localExecutable": "",
    "inventoryPatterns": [
      "ipscan*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://angryip.org/download/",
        "status": 200,
        "finalUrl": "https://angryip.org/download/",
        "title": "Angry IP Scanner - Download for Windows, Mac or Linux",
        "checkedAt": "2026-09-09T20:17:51.192186+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://angryip.org/download/",
        "status": 200,
        "finalUrl": "https://angryip.org/download/",
        "title": "Angry IP Scanner - Download for Windows, Mac or Linux",
        "checkedAt": "2026-09-09T20:17:51.192186+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "advancedip",
    "name": "Advanced IP Scanner",
    "developer": "Famatech",
    "description": "Optional Windows LAN discovery interface; scan only networks you administer.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "LAN discovery"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://www.advanced-ip-scanner.com/",
    "officialDownload": "https://www.advanced-ip-scanner.com/",
    "documentation": "https://www.advanced-ip-scanner.com/",
    "localFolder": "40_INSTALLERS/Utilities/AdvancedIP",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.advanced-ip-scanner.com/",
        "status": 200,
        "finalUrl": "https://www.advanced-ip-scanner.com/",
        "title": "Advanced IP Scanner - Download Free Network Scanner",
        "checkedAt": "2026-09-09T20:17:55.647042+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.advanced-ip-scanner.com/",
        "status": 200,
        "finalUrl": "https://www.advanced-ip-scanner.com/",
        "title": "Advanced IP Scanner - Download Free Network Scanner",
        "checkedAt": "2026-09-09T20:17:55.647042+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "iperf3",
    "name": "iperf3",
    "developer": "ESnet",
    "description": "Measure LAN throughput between two endpoints. Upstream supports Unix; Windows builds are not supplied here.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "slow Ethernet slow Wi-Fi throughput"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://software.es.net/iperf/obtaining.html",
    "officialDownload": "https://software.es.net/iperf/obtaining.html",
    "documentation": "https://software.es.net/iperf/obtaining.html",
    "localFolder": "20_PORTABLE_APPS/Misc/iperf3",
    "localExecutable": "20_PORTABLE_APPS/Misc/iperf3/iperf3",
    "inventoryPatterns": [
      "iperf3"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://software.es.net/iperf/obtaining.html",
        "status": 200,
        "finalUrl": "https://software.es.net/iperf/obtaining.html",
        "title": "Obtaining iperf3 — iperf3 3.21 documentation",
        "checkedAt": "2026-09-09T20:17:54.093349+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://software.es.net/iperf/obtaining.html",
        "status": 200,
        "finalUrl": "https://software.es.net/iperf/obtaining.html",
        "title": "Obtaining iperf3 — iperf3 3.21 documentation",
        "checkedAt": "2026-09-09T20:17:54.093349+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "putty",
    "name": "PuTTY",
    "developer": "Simon Tatham",
    "description": "SSH and serial terminal for authorized servers and network equipment.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "SSH serial homelab"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
    "officialDownload": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
    "documentation": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
    "localFolder": "20_PORTABLE_APPS/Misc/PuTTY",
    "localExecutable": "20_PORTABLE_APPS/Misc/PuTTY/putty.exe",
    "inventoryPatterns": [
      "putty.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "0.85",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
        "status": 200,
        "finalUrl": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
        "title": "Download PuTTY: latest release (0.85)",
        "checkedAt": "2026-09-09T20:17:55.519250+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
        "status": 200,
        "finalUrl": "https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html",
        "title": "Download PuTTY: latest release (0.85)",
        "checkedAt": "2026-09-09T20:17:55.519250+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "winscp",
    "name": "WinSCP",
    "developer": "WinSCP project",
    "description": "SFTP/SCP file transfer; validate host keys and avoid saving customer credentials.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "SFTP SSH"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 25,
    "officialWebsite": "https://winscp.net/eng/downloads.php",
    "officialDownload": "https://winscp.net/eng/downloads.php",
    "documentation": "https://winscp.net/eng/downloads.php",
    "localFolder": "20_PORTABLE_APPS/Misc/WinSCP",
    "localExecutable": "20_PORTABLE_APPS/Misc/WinSCP/WinSCP.exe",
    "inventoryPatterns": [
      "WinSCP.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://winscp.net/eng/downloads.php",
        "status": 200,
        "finalUrl": "https://winscp.net/eng/downloads.php",
        "title": "All Downloads :: WinSCP",
        "checkedAt": "2026-09-09T20:17:55.315799+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://winscp.net/eng/downloads.php",
        "status": 200,
        "finalUrl": "https://winscp.net/eng/downloads.php",
        "title": "All Downloads :: WinSCP",
        "checkedAt": "2026-09-09T20:17:55.315799+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "rustdesk",
    "name": "RustDesk",
    "developer": "RustDesk project",
    "description": "Attended portable remote support; service installation enables different access behavior.",
    "categories": [
      "Remote Support"
    ],
    "tags": [
      "remote attended"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://rustdesk.com/",
    "officialDownload": "https://rustdesk.com/",
    "documentation": "https://rustdesk.com/",
    "localFolder": "40_INSTALLERS/Remote-Support/RustDesk",
    "localExecutable": "",
    "inventoryPatterns": [
      "rustdesk*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Attended access only by default. Unattended service installation and enrollment must be separately authorized. Portable behavior depends on the downloaded build; do not install the service or enable unattended access automatically.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://rustdesk.com/",
        "status": 200,
        "finalUrl": "https://rustdesk.com/",
        "title": "RustDesk: Open-Source Remote Desktop with Self-Hosted Server Solutions",
        "checkedAt": "2026-09-09T20:17:54.164054+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://rustdesk.com/",
        "status": 200,
        "finalUrl": "https://rustdesk.com/",
        "title": "RustDesk: Open-Source Remote Desktop with Self-Hosted Server Solutions",
        "checkedAt": "2026-09-09T20:17:54.164054+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "anydesk",
    "name": "AnyDesk",
    "developer": "AnyDesk Software",
    "description": "Attended remote client; commercial support requires appropriate licensing.",
    "categories": [
      "Remote Support"
    ],
    "tags": [
      "remote attended"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://anydesk.com/en/downloads/windows",
    "officialDownload": "https://anydesk.com/en/downloads/windows",
    "documentation": "https://anydesk.com/en/downloads/windows",
    "localFolder": "40_INSTALLERS/Remote-Support/AnyDesk",
    "localExecutable": "40_INSTALLERS/Remote-Support/AnyDesk/AnyDesk.exe",
    "inventoryPatterns": [
      "AnyDesk.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "9.7.15",
    "currentVersion": "",
    "lastChecked": "2026-09-09",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Attended access only by default. Unattended service installation and enrollment must be separately authorized.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://anydesk.com/en/downloads/windows",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:51.239282+00:00"
      },
      "download": {
        "url": "https://anydesk.com/en/downloads/windows",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:51.239282+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "tailscale",
    "name": "Tailscale",
    "developer": "Tailscale",
    "description": "Installed private-network agent; enrollment and access policies are separate from remote desktop.",
    "categories": [
      "Remote Support"
    ],
    "tags": [
      "VPN homelab agent"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 60,
    "officialWebsite": "https://tailscale.com/download/windows",
    "officialDownload": "https://tailscale.com/download/windows",
    "documentation": "https://tailscale.com/download/windows",
    "localFolder": "40_INSTALLERS/Remote-Support/Tailscale",
    "localExecutable": "",
    "inventoryPatterns": [
      "tailscale*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Attended access only by default. Unattended service installation and enrollment must be separately authorized.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://tailscale.com/download/windows",
        "status": 200,
        "finalUrl": "https://tailscale.com/download/windows",
        "title": "Download | Tailscale",
        "checkedAt": "2026-09-09T20:17:54.547609+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://tailscale.com/download/windows",
        "status": 200,
        "finalUrl": "https://tailscale.com/download/windows",
        "title": "Download | Tailscale",
        "checkedAt": "2026-09-09T20:17:54.547609+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "safetyscanner",
    "name": "Microsoft Safety Scanner",
    "developer": "Microsoft",
    "description": "On-demand defensive malware scan. DOWNLOAD FRESH COPY; expires 10 days after download.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "malware scan"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
    "officialDownload": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
    "documentation": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
    "localFolder": "20_PORTABLE_APPS/Misc/SafetyScanner",
    "localExecutable": "20_PORTABLE_APPS/Misc/SafetyScanner/msert.exe",
    "inventoryPatterns": [
      "msert.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": true,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
        "title": "Microsoft Safety Scanner Download - Microsoft Defender for Endpoint | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.653572+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/defender-endpoint/safety-scanner-download",
        "title": "Microsoft Safety Scanner Download - Microsoft Defender for Endpoint | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.653572+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "eek",
    "name": "Emsisoft Emergency Kit",
    "developer": "Emsisoft",
    "description": "Portable second-opinion scanner; refresh definitions and check technician licensing.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "malware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 500,
    "officialWebsite": "https://www.emsisoft.com/en/emergency-kit/",
    "officialDownload": "https://www.emsisoft.com/en/emergency-kit/",
    "documentation": "https://www.emsisoft.com/en/emergency-kit/",
    "localFolder": "20_PORTABLE_APPS/Misc/Emsisoft",
    "localExecutable": "20_PORTABLE_APPS/Misc/Emsisoft/Start Emergency Kit Scanner.exe",
    "inventoryPatterns": [
      "Start Emergency Kit Scanner.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": true,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.emsisoft.com/en/emergency-kit/",
        "status": 200,
        "finalUrl": "https://www.emsisoft.com/en/emergency-kit/",
        "title": "Emsisoft Emergency Kit: Free Portable Malware & Virus Scanner",
        "checkedAt": "2026-09-09T20:17:56.602708+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.emsisoft.com/en/emergency-kit/",
        "status": 200,
        "finalUrl": "https://www.emsisoft.com/en/emergency-kit/",
        "title": "Emsisoft Emergency Kit: Free Portable Malware & Virus Scanner",
        "checkedAt": "2026-09-09T20:17:56.602708+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "malwarebytes",
    "name": "Malwarebytes",
    "developer": "Malwarebytes",
    "description": "Installed second-opinion scanner; service work and business use need suitable terms.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "malware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://www.malwarebytes.com/mwb-download",
    "officialDownload": "https://www.malwarebytes.com/mwb-download",
    "documentation": "https://www.malwarebytes.com/mwb-download",
    "localFolder": "40_INSTALLERS/Utilities/Malwarebytes",
    "localExecutable": "",
    "inventoryPatterns": [
      "MBSetup*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.malwarebytes.com/mwb-download",
        "status": 200,
        "finalUrl": "https://www.malwarebytes.com/mwb-download",
        "title": "Malwarebytes Free: Free Antivirus 2026 | 100% Free & Easy Install",
        "checkedAt": "2026-09-09T20:17:55.969749+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.malwarebytes.com/mwb-download",
        "status": 200,
        "finalUrl": "https://www.malwarebytes.com/mwb-download",
        "title": "Malwarebytes Free: Free Antivirus 2026 | 100% Free & Easy Install",
        "checkedAt": "2026-09-09T20:17:55.969749+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "adwcleaner",
    "name": "AdwCleaner",
    "developer": "Malwarebytes",
    "description": "Portable adware and potentially unwanted program scanner.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "adware malware browser"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://www.malwarebytes.com/adwcleaner",
    "officialDownload": "https://www.malwarebytes.com/adwcleaner",
    "documentation": "https://www.malwarebytes.com/adwcleaner",
    "localFolder": "20_PORTABLE_APPS/Misc/AdwCleaner",
    "localExecutable": "",
    "inventoryPatterns": [
      "adwcleaner*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": true,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.malwarebytes.com/adwcleaner",
        "status": 200,
        "finalUrl": "https://www.malwarebytes.com/adwcleaner",
        "title": "AdwCleaner: Free Adware Removal & Cleaner Tool",
        "checkedAt": "2026-09-09T20:17:55.915145+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.malwarebytes.com/adwcleaner",
        "status": 200,
        "finalUrl": "https://www.malwarebytes.com/adwcleaner",
        "title": "AdwCleaner: Free Adware Removal & Cleaner Tool",
        "checkedAt": "2026-09-09T20:17:55.915145+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "firefox",
    "name": "Firefox Portable",
    "developer": "Mozilla / PortableApps.com",
    "description": "Portable browser package published by PortableApps.com; web browsing needs connectivity.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "browser"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 250,
    "officialWebsite": "https://portableapps.com/apps/internet/firefox_portable",
    "officialDownload": "https://portableapps.com/apps/internet/firefox_portable",
    "documentation": "https://portableapps.com/apps/internet/firefox_portable",
    "localFolder": "20_PORTABLE_APPS/Browsers/Firefox",
    "localExecutable": "20_PORTABLE_APPS/Browsers/Firefox/FirefoxPortable.exe",
    "inventoryPatterns": [
      "FirefoxPortable.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://portableapps.com/apps/internet/firefox_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/internet/firefox_portable",
        "title": "Mozilla Firefox, Portable Edition | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.640842+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://portableapps.com/apps/internet/firefox_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/internet/firefox_portable",
        "title": "Mozilla Firefox, Portable Edition | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.640842+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "chrome",
    "name": "Google Chrome installer",
    "developer": "Google",
    "description": "Official browser installer; choose an offline enterprise package when needed.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "browser"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://chromeenterprise.google/download/",
    "officialDownload": "https://chromeenterprise.google/download/",
    "documentation": "https://chromeenterprise.google/download/",
    "localFolder": "40_INSTALLERS/Browsers/Chrome",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.msi"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://chromeenterprise.google/download/",
        "status": 200,
        "finalUrl": "https://chromeenterprise.google/download/",
        "title": "Enterprise Browser Download for Windows & Mac - Chrome Enterprise",
        "checkedAt": "2026-09-09T20:17:51.389132+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://chromeenterprise.google/download/",
        "status": 200,
        "finalUrl": "https://chromeenterprise.google/download/",
        "title": "Enterprise Browser Download for Windows & Mac - Chrome Enterprise",
        "checkedAt": "2026-09-09T20:17:51.389132+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "edge",
    "name": "Microsoft Edge installer",
    "developer": "Microsoft",
    "description": "Official Edge for Business offline installer selection.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "browser"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 180,
    "officialWebsite": "https://www.microsoft.com/en-us/edge/business/download",
    "officialDownload": "https://www.microsoft.com/en-us/edge/business/download",
    "documentation": "https://www.microsoft.com/en-us/edge/business/download",
    "localFolder": "40_INSTALLERS/Browsers/Edge",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.msi"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.microsoft.com/en-us/edge/business/download",
        "status": 200,
        "finalUrl": "https://explore.microsoft.com/en-us/edge/business/download?form=MA13FJ",
        "title": "Download and Deploy Microsoft Edge for Business",
        "checkedAt": "2026-09-09T20:18:00.132104+00:00",
        "contentType": "text/html;charset=utf-8"
      },
      "download": {
        "url": "https://www.microsoft.com/en-us/edge/business/download",
        "status": 200,
        "finalUrl": "https://explore.microsoft.com/en-us/edge/business/download?form=MA13FJ",
        "title": "Download and Deploy Microsoft Edge for Business",
        "checkedAt": "2026-09-09T20:18:00.132104+00:00",
        "contentType": "text/html;charset=utf-8"
      }
    }
  },
  {
    "id": "7zip",
    "name": "7-Zip",
    "developer": "Igor Pavlov",
    "description": "Archive extraction and creation; official standalone console packages are also available.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "zip archive"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.7-zip.org/download.html",
    "officialDownload": "https://www.7-zip.org/download.html",
    "documentation": "https://www.7-zip.org/download.html",
    "localFolder": "20_PORTABLE_APPS/Archive/7-Zip",
    "localExecutable": "",
    "inventoryPatterns": [
      "7z.exe",
      "7za.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "For the full GUI, install/extract the official package appropriately. The standalone 7-Zip Extra console package contains 7za.exe; both console names are recognized.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.7-zip.org/download.html",
        "status": 200,
        "finalUrl": "https://www.7-zip.org/download.html",
        "title": "Download",
        "checkedAt": "2026-09-09T20:17:55.295770+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.7-zip.org/download.html",
        "status": 200,
        "finalUrl": "https://www.7-zip.org/download.html",
        "title": "Download",
        "checkedAt": "2026-09-09T20:17:55.295770+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "nanazip",
    "name": "NanaZip",
    "developer": "M2-Team",
    "description": "Modern Windows archive integration; MSIX installation is required.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "archive"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://github.com/M2Team/NanaZip",
    "officialDownload": "https://github.com/M2Team/NanaZip/releases",
    "documentation": "https://github.com/M2Team/NanaZip",
    "localFolder": "40_INSTALLERS/Utilities/NanaZip",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.msixbundle"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "githubRepo": "M2Team/NanaZip",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/M2Team/NanaZip",
        "status": 200,
        "finalUrl": "https://github.com/M2Team/NanaZip",
        "title": "GitHub - M2Team/NanaZip: The 7-Zip derivative intended for the modern Windows experience · GitHub",
        "checkedAt": "2026-09-09T20:17:52.356294+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/M2Team/NanaZip/releases",
        "status": 200,
        "finalUrl": "https://github.com/M2Team/NanaZip/releases",
        "title": "Releases · M2Team/NanaZip · GitHub",
        "checkedAt": "2026-09-09T20:17:52.448588+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "notepad",
    "name": "Notepad++",
    "developer": "Notepad++ project",
    "description": "Lightweight portable editor for logs, configuration and scripts.",
    "categories": [
      "Developer Tools",
      "Portable Apps"
    ],
    "tags": [
      "text editor"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://notepad-plus-plus.org/downloads/",
    "officialDownload": "https://notepad-plus-plus.org/downloads/",
    "documentation": "https://notepad-plus-plus.org/downloads/",
    "localFolder": "20_PORTABLE_APPS/Text-Editors/Notepad++",
    "localExecutable": "20_PORTABLE_APPS/Text-Editors/Notepad++/notepad++.exe",
    "inventoryPatterns": [
      "notepad++.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://notepad-plus-plus.org/downloads/",
        "status": 200,
        "finalUrl": "https://notepad-plus-plus.org/downloads/",
        "title": "Downloads | Notepad++",
        "checkedAt": "2026-09-09T20:17:54.579181+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://notepad-plus-plus.org/downloads/",
        "status": 200,
        "finalUrl": "https://notepad-plus-plus.org/downloads/",
        "title": "Downloads | Notepad++",
        "checkedAt": "2026-09-09T20:17:54.579181+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "vscode",
    "name": "Visual Studio Code Portable",
    "developer": "Microsoft",
    "description": "Extract the ZIP and create a data folder beside Code.exe to enable portable mode.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "code editor"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 500,
    "officialWebsite": "https://code.visualstudio.com/docs/setup/portable",
    "officialDownload": "https://code.visualstudio.com/docs/setup/portable",
    "documentation": "https://code.visualstudio.com/docs/setup/portable",
    "localFolder": "20_PORTABLE_APPS/Text-Editors/VSCode",
    "localExecutable": "20_PORTABLE_APPS/Text-Editors/VSCode/Code.exe",
    "inventoryPatterns": [
      "Code.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://code.visualstudio.com/docs/setup/portable",
        "status": 200,
        "finalUrl": "https://code.visualstudio.com/docs/setup/portable",
        "title": "Portable mode",
        "checkedAt": "2026-09-09T20:17:51.490880+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://code.visualstudio.com/docs/setup/portable",
        "status": 200,
        "finalUrl": "https://code.visualstudio.com/docs/setup/portable",
        "title": "Portable mode",
        "checkedAt": "2026-09-09T20:17:51.490880+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "winmerge",
    "name": "WinMerge",
    "developer": "WinMerge project",
    "description": "Compare text files and directories; inspect differences before merging.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "diff compare"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://winmerge.org/downloads/",
    "officialDownload": "https://winmerge.org/downloads/",
    "documentation": "https://winmerge.org/downloads/",
    "localFolder": "20_PORTABLE_APPS/Text-Editors/WinMerge",
    "localExecutable": "20_PORTABLE_APPS/Text-Editors/WinMerge/WinMergeU.exe",
    "inventoryPatterns": [
      "WinMergeU.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://winmerge.org/downloads/",
        "status": 200,
        "finalUrl": "https://winmerge.org/downloads/",
        "title": "Download WinMerge - WinMerge",
        "checkedAt": "2026-09-09T20:17:54.856733+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://winmerge.org/downloads/",
        "status": 200,
        "finalUrl": "https://winmerge.org/downloads/",
        "title": "Download WinMerge - WinMerge",
        "checkedAt": "2026-09-09T20:17:54.856733+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "everything",
    "name": "Everything",
    "developer": "voidtools",
    "description": "Fast NTFS filename search; indexing may require elevation or its service.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "search files"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://www.voidtools.com/downloads/",
    "officialDownload": "https://www.voidtools.com/downloads/",
    "documentation": "https://www.voidtools.com/downloads/",
    "localFolder": "20_PORTABLE_APPS/Misc/Everything",
    "localExecutable": "20_PORTABLE_APPS/Misc/Everything/Everything.exe",
    "inventoryPatterns": [
      "Everything.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.voidtools.com/downloads/",
        "status": 200,
        "finalUrl": "https://www.voidtools.com/downloads/",
        "title": "Downloads - voidtools",
        "checkedAt": "2026-09-09T20:17:59.070885+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.voidtools.com/downloads/",
        "status": 200,
        "finalUrl": "https://www.voidtools.com/downloads/",
        "title": "Downloads - voidtools",
        "checkedAt": "2026-09-09T20:17:59.070885+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "wiztree",
    "name": "WizTree",
    "developer": "Antibody Software",
    "description": "Fast disk usage mapping to locate space consumers; commercial use requires a license.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "disk space Windows slow"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://diskanalyzer.com/download",
    "officialDownload": "https://diskanalyzer.com/download",
    "documentation": "https://diskanalyzer.com/download",
    "localFolder": "20_PORTABLE_APPS/Misc/WizTree",
    "localExecutable": "20_PORTABLE_APPS/Misc/WizTree/WizTree64.exe",
    "inventoryPatterns": [
      "WizTree64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://diskanalyzer.com/download",
        "status": 200,
        "finalUrl": "https://diskanalyzer.com/download",
        "title": "Download WizTree",
        "checkedAt": "2026-09-09T20:17:51.543019+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://diskanalyzer.com/download",
        "status": 200,
        "finalUrl": "https://diskanalyzer.com/download",
        "title": "Download WizTree",
        "checkedAt": "2026-09-09T20:17:51.543019+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "treesize",
    "name": "TreeSize Free",
    "developer": "JAM Software",
    "description": "Alternative directory size view; check allowed use and supported features.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "disk space"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.jam-software.com/treesize_free",
    "officialDownload": "https://www.jam-software.com/treesize_free",
    "documentation": "https://www.jam-software.com/treesize_free",
    "localFolder": "20_PORTABLE_APPS/Misc/TreeSize",
    "localExecutable": "20_PORTABLE_APPS/Misc/TreeSize/TreeSizeFree.exe",
    "inventoryPatterns": [
      "TreeSizeFree.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.jam-software.com/treesize_free",
        "status": 200,
        "finalUrl": "https://www.jam-software.com/treesize",
        "title": "TreeSize – Official Free Download",
        "checkedAt": "2026-09-09T20:17:58.315469+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.jam-software.com/treesize_free",
        "status": 200,
        "finalUrl": "https://www.jam-software.com/treesize",
        "title": "TreeSize – Official Free Download",
        "checkedAt": "2026-09-09T20:17:58.315469+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "fastcopy",
    "name": "FastCopy",
    "developer": "FastCopy Lab",
    "description": "High-throughput copy with verification options; sync/delete modes can remove files.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "copy migration"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://fastcopy.jp/",
    "officialDownload": "https://fastcopy.jp/",
    "documentation": "https://fastcopy.jp/",
    "localFolder": "20_PORTABLE_APPS/Misc/FastCopy",
    "localExecutable": "20_PORTABLE_APPS/Misc/FastCopy/FastCopy.exe",
    "inventoryPatterns": [
      "FastCopy.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://fastcopy.jp/",
        "status": 200,
        "finalUrl": "https://fastcopy.jp/",
        "title": "FastCopy",
        "checkedAt": "2026-09-09T20:17:51.736451+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://fastcopy.jp/",
        "status": 200,
        "finalUrl": "https://fastcopy.jp/",
        "title": "FastCopy",
        "checkedAt": "2026-09-09T20:17:51.736451+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "freefilesync",
    "name": "FreeFileSync",
    "developer": "FreeFileSync project",
    "description": "Compare and synchronize folders; preview deletion directions before syncing.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "backup sync migration"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://freefilesync.org/download.php",
    "officialDownload": "https://freefilesync.org/download.php",
    "documentation": "https://freefilesync.org/download.php",
    "localFolder": "20_PORTABLE_APPS/Misc/FreeFileSync",
    "localExecutable": "20_PORTABLE_APPS/Misc/FreeFileSync/FreeFileSync.exe",
    "inventoryPatterns": [
      "FreeFileSync.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Standard edition is installed. Portable deployment availability depends on the selected edition; check vendor terms.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://freefilesync.org/download.php",
        "status": 200,
        "finalUrl": "https://freefilesync.org/download.php",
        "title": "Download the Latest Version - FreeFileSync",
        "checkedAt": "2026-09-09T20:17:51.617205+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://freefilesync.org/download.php",
        "status": 200,
        "finalUrl": "https://freefilesync.org/download.php",
        "title": "Download the Latest Version - FreeFileSync",
        "checkedAt": "2026-09-09T20:17:51.617205+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "sumatra",
    "name": "SumatraPDF",
    "developer": "Krzysztof Kowalczyk",
    "description": "Compact portable PDF and ebook reader for field documentation.",
    "categories": [
      "Office & PDF",
      "Portable Apps"
    ],
    "tags": [
      "PDF"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
    "officialDownload": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
    "documentation": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
    "localFolder": "20_PORTABLE_APPS/PDF/SumatraPDF",
    "localExecutable": "",
    "inventoryPatterns": [
      "SumatraPDF*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
        "status": 200,
        "finalUrl": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
        "title": "Sumatra PDF reader download page",
        "checkedAt": "2026-09-09T20:17:58.659324+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
        "status": 200,
        "finalUrl": "https://www.sumatrapdfreader.org/download-free-pdf-viewer",
        "title": "Sumatra PDF reader download page",
        "checkedAt": "2026-09-09T20:17:58.659324+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "pdfarranger",
    "name": "PDF Arranger",
    "developer": "PDF Arranger project",
    "description": "Reorder, merge and split PDF pages locally.",
    "categories": [
      "Office & PDF"
    ],
    "tags": [
      "PDF"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://github.com/pdfarranger/pdfarranger",
    "officialDownload": "https://github.com/pdfarranger/pdfarranger/releases",
    "documentation": "https://github.com/pdfarranger/pdfarranger",
    "localFolder": "20_PORTABLE_APPS/PDF/PDF-Arranger",
    "localExecutable": "20_PORTABLE_APPS/PDF/PDF-Arranger/pdfarranger.exe",
    "inventoryPatterns": [
      "pdfarranger.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "githubRepo": "pdfarranger/pdfarranger",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/pdfarranger/pdfarranger",
        "status": 200,
        "finalUrl": "https://github.com/pdfarranger/pdfarranger",
        "title": "GitHub - pdfarranger/pdfarranger: Small python-gtk application, which helps the user to merge or split PDF documents and rotate, crop and rearrange their pages using an interactive and intuitive graphical interface. · GitHub",
        "checkedAt": "2026-09-09T20:17:52.922293+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/pdfarranger/pdfarranger/releases",
        "status": 200,
        "finalUrl": "https://github.com/pdfarranger/pdfarranger/releases",
        "title": "Releases · pdfarranger/pdfarranger · GitHub",
        "checkedAt": "2026-09-09T20:17:52.751312+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "libreoffice",
    "name": "LibreOffice Portable",
    "developer": "The Document Foundation / PortableApps.com",
    "description": "Offline document, spreadsheet and presentation suite packaged by PortableApps.com.",
    "categories": [
      "Office & PDF",
      "Portable Apps"
    ],
    "tags": [
      "office documents"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1200,
    "officialWebsite": "https://portableapps.com/apps/office/libreoffice_portable",
    "officialDownload": "https://portableapps.com/apps/office/libreoffice_portable",
    "documentation": "https://portableapps.com/apps/office/libreoffice_portable",
    "localFolder": "20_PORTABLE_APPS/Office/LibreOffice",
    "localExecutable": "20_PORTABLE_APPS/Office/LibreOffice/LibreOfficePortable.exe",
    "inventoryPatterns": [
      "LibreOfficePortable.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://portableapps.com/apps/office/libreoffice_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/office/libreoffice_portable",
        "title": "LibreOffice Portable Stable | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.405224+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://portableapps.com/apps/office/libreoffice_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/office/libreoffice_portable",
        "title": "LibreOffice Portable Stable | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.405224+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "onlyoffice",
    "name": "ONLYOFFICE Desktop Editors",
    "developer": "Ascensio System",
    "description": "Optional installed offline office suite with OOXML-focused editing.",
    "categories": [
      "Office & PDF"
    ],
    "tags": [
      "office"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 800,
    "officialWebsite": "https://www.onlyoffice.com/download-desktop.aspx",
    "officialDownload": "https://www.onlyoffice.com/download-desktop.aspx",
    "documentation": "https://www.onlyoffice.com/download-desktop.aspx",
    "localFolder": "40_INSTALLERS/Office/ONLYOFFICE",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.onlyoffice.com/download-desktop.aspx",
        "status": 200,
        "finalUrl": "https://www.onlyoffice.com/download-desktop",
        "title": "ONLYOFFICE desktop and mobile apps | ONLYOFFICE",
        "checkedAt": "2026-09-09T20:17:57.071511+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.onlyoffice.com/download-desktop.aspx",
        "status": 200,
        "finalUrl": "https://www.onlyoffice.com/download-desktop",
        "title": "ONLYOFFICE desktop and mobile apps | ONLYOFFICE",
        "checkedAt": "2026-09-09T20:17:57.071511+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "vlc",
    "name": "VLC Portable",
    "developer": "VideoLAN / PortableApps.com",
    "description": "Offline media playback in a portable package.",
    "categories": [
      "Media",
      "Portable Apps"
    ],
    "tags": [
      "video audio"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://portableapps.com/apps/music_video/vlc_portable",
    "officialDownload": "https://portableapps.com/apps/music_video/vlc_portable",
    "documentation": "https://portableapps.com/apps/music_video/vlc_portable",
    "localFolder": "20_PORTABLE_APPS/Media/VLC",
    "localExecutable": "20_PORTABLE_APPS/Media/VLC/VLCPortable.exe",
    "inventoryPatterns": [
      "VLCPortable.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://portableapps.com/apps/music_video/vlc_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/music_video/vlc_portable",
        "title": "VLC Media Player Portable | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.305933+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://portableapps.com/apps/music_video/vlc_portable",
        "status": 200,
        "finalUrl": "https://portableapps.com/apps/music_video/vlc_portable",
        "title": "VLC Media Player Portable | PortableApps.com",
        "checkedAt": "2026-09-09T20:17:54.305933+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "mediainfo",
    "name": "MediaInfo",
    "developer": "MediaArea",
    "description": "Inspect audio/video codecs, metadata and container details.",
    "categories": [
      "Media"
    ],
    "tags": [
      "codec"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://mediaarea.net/en/MediaInfo/Download/Windows",
    "officialDownload": "https://mediaarea.net/en/MediaInfo/Download/Windows",
    "documentation": "https://mediaarea.net/en/MediaInfo/Download/Windows",
    "localFolder": "20_PORTABLE_APPS/Media/MediaInfo",
    "localExecutable": "20_PORTABLE_APPS/Media/MediaInfo/MediaInfo.exe",
    "inventoryPatterns": [
      "MediaInfo.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://mediaarea.net/en/MediaInfo/Download/Windows",
        "status": 200,
        "finalUrl": "https://mediaarea.net/en/MediaInfo/Download/Windows",
        "title": "MediaInfo - Download MediaInfo for Microsoft Windows",
        "checkedAt": "2026-09-09T20:17:53.885220+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://mediaarea.net/en/MediaInfo/Download/Windows",
        "status": 200,
        "finalUrl": "https://mediaarea.net/en/MediaInfo/Download/Windows",
        "title": "MediaInfo - Download MediaInfo for Microsoft Windows",
        "checkedAt": "2026-09-09T20:17:53.885220+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "handbrake",
    "name": "HandBrake",
    "developer": "HandBrake team",
    "description": "Offline video transcoding; sustained encodes can heavily load the CPU/GPU.",
    "categories": [
      "Media"
    ],
    "tags": [
      "video encode"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://handbrake.fr/downloads.php",
    "officialDownload": "https://handbrake.fr/downloads.php",
    "documentation": "https://handbrake.fr/downloads.php",
    "localFolder": "40_INSTALLERS/Media/HandBrake",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://handbrake.fr/downloads.php",
        "status": 200,
        "finalUrl": "https://handbrake.fr/downloads.php",
        "title": "HandBrake: Downloads",
        "checkedAt": "2026-09-09T20:17:53.151057+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://handbrake.fr/downloads.php",
        "status": 200,
        "finalUrl": "https://handbrake.fr/downloads.php",
        "title": "HandBrake: Downloads",
        "checkedAt": "2026-09-09T20:17:53.151057+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "audacity",
    "name": "Audacity",
    "developer": "Audacity team",
    "description": "Offline audio recording and editing for device checks and simple repairs.",
    "categories": [
      "Media"
    ],
    "tags": [
      "audio"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://www.audacityteam.org/download/windows/",
    "officialDownload": "https://www.audacityteam.org/download/windows/",
    "documentation": "https://www.audacityteam.org/download/windows/",
    "localFolder": "20_PORTABLE_APPS/Media/Audacity",
    "localExecutable": "20_PORTABLE_APPS/Media/Audacity/Audacity.exe",
    "inventoryPatterns": [
      "Audacity.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.audacityteam.org/download/windows/",
        "status": 200,
        "finalUrl": "https://www.audacityteam.org/download/windows/",
        "title": "Audacity ® | Download for Windows",
        "checkedAt": "2026-09-09T20:17:54.948400+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.audacityteam.org/download/windows/",
        "status": 200,
        "finalUrl": "https://www.audacityteam.org/download/windows/",
        "title": "Audacity ® | Download for Windows",
        "checkedAt": "2026-09-09T20:17:54.948400+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "irfanview",
    "name": "IrfanView",
    "developer": "Irfan Skiljan",
    "description": "Fast image viewer; commercial use requires registration.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "graphics images"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Personal free",
    "personalLicenseNotes": "Free personal-use offering; commercial/service rights are separate.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://www.irfanview.com/",
    "officialDownload": "https://www.irfanview.com/",
    "documentation": "https://www.irfanview.com/",
    "localFolder": "20_PORTABLE_APPS/Graphics/IrfanView",
    "localExecutable": "20_PORTABLE_APPS/Graphics/IrfanView/i_view64.exe",
    "inventoryPatterns": [
      "i_view64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.irfanview.com/",
        "status": 200,
        "finalUrl": "https://www.irfanview.com/",
        "title": "IrfanView - Official Homepage - One of the Most Popular Viewers Worldwide",
        "checkedAt": "2026-09-09T20:17:56.239772+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.irfanview.com/",
        "status": 200,
        "finalUrl": "https://www.irfanview.com/",
        "title": "IrfanView - Official Homepage - One of the Most Popular Viewers Worldwide",
        "checkedAt": "2026-09-09T20:17:56.239772+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "gimp",
    "name": "GIMP",
    "developer": "GIMP project",
    "description": "Offline image editing for screenshots and service documentation.",
    "categories": [
      "Portable Apps"
    ],
    "tags": [
      "graphics"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 500,
    "officialWebsite": "https://www.gimp.org/downloads/",
    "officialDownload": "https://www.gimp.org/downloads/",
    "documentation": "https://www.gimp.org/downloads/",
    "localFolder": "40_INSTALLERS/Utilities/GIMP",
    "localExecutable": "",
    "inventoryPatterns": [
      "gimp*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.gimp.org/downloads/",
        "status": 200,
        "finalUrl": "https://www.gimp.org/downloads/",
        "title": "GIMP - Downloads",
        "checkedAt": "2026-09-09T20:17:55.363412+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.gimp.org/downloads/",
        "status": 200,
        "finalUrl": "https://www.gimp.org/downloads/",
        "title": "GIMP - Downloads",
        "checkedAt": "2026-09-09T20:17:55.363412+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "powershell",
    "name": "PowerShell 7",
    "developer": "Microsoft",
    "description": "Current cross-platform shell; ZIP edition can be staged without installation.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "scripts shell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 300,
    "officialWebsite": "https://github.com/PowerShell/PowerShell",
    "officialDownload": "https://github.com/PowerShell/PowerShell/releases",
    "documentation": "https://github.com/PowerShell/PowerShell",
    "localFolder": "20_PORTABLE_APPS/Misc/PowerShell",
    "localExecutable": "20_PORTABLE_APPS/Misc/PowerShell/pwsh.exe",
    "inventoryPatterns": [
      "pwsh.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "githubRepo": "PowerShell/PowerShell",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/PowerShell/PowerShell",
        "status": 200,
        "finalUrl": "https://github.com/PowerShell/PowerShell",
        "title": "GitHub - PowerShell/PowerShell: PowerShell for every system! · GitHub",
        "checkedAt": "2026-09-09T20:17:52.298158+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/PowerShell/PowerShell/releases",
        "status": 200,
        "finalUrl": "https://github.com/PowerShell/PowerShell/releases",
        "title": "Releases · PowerShell/PowerShell · GitHub",
        "checkedAt": "2026-09-09T20:17:52.579368+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "git",
    "name": "Git Portable",
    "developer": "Git for Windows",
    "description": "Portable Git and shell tools for configuration history and source work.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "version control"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 350,
    "officialWebsite": "https://git-scm.com/downloads/win",
    "officialDownload": "https://git-scm.com/downloads/win",
    "documentation": "https://git-scm.com/downloads/win",
    "localFolder": "20_PORTABLE_APPS/Misc/Git",
    "localExecutable": "20_PORTABLE_APPS/Misc/Git/git.exe",
    "inventoryPatterns": [
      "git.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://git-scm.com/downloads/win",
        "status": 200,
        "finalUrl": "https://git-scm.com/downloads/win",
        "title": "Redirecting…",
        "checkedAt": "2026-09-09T20:17:51.413700+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://git-scm.com/downloads/win",
        "status": 200,
        "finalUrl": "https://git-scm.com/downloads/win",
        "title": "Redirecting…",
        "checkedAt": "2026-09-09T20:17:51.413700+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "python",
    "name": "Python embeddable package",
    "developer": "Python Software Foundation",
    "description": "Minimal Windows embedded runtime; not a normal pip-enabled development installation.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "runtime"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 30,
    "officialWebsite": "https://www.python.org/downloads/windows/",
    "officialDownload": "https://www.python.org/downloads/windows/",
    "documentation": "https://www.python.org/downloads/windows/",
    "localFolder": "20_PORTABLE_APPS/Misc/Python",
    "localExecutable": "20_PORTABLE_APPS/Misc/Python/python.exe",
    "inventoryPatterns": [
      "python.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.python.org/downloads/windows/",
        "status": 200,
        "finalUrl": "https://www.python.org/downloads/windows/",
        "title": "",
        "checkedAt": "2026-09-09T20:17:57.550894+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.python.org/downloads/windows/",
        "status": 200,
        "finalUrl": "https://www.python.org/downloads/windows/",
        "title": "",
        "checkedAt": "2026-09-09T20:17:57.550894+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "curl",
    "name": "curl",
    "developer": "curl project",
    "description": "Transfer URLs and inspect HTTP/TLS; avoid placing secrets in command histories.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "HTTP wget download"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 15,
    "officialWebsite": "https://curl.se/windows/",
    "officialDownload": "https://curl.se/windows/",
    "documentation": "https://curl.se/windows/",
    "localFolder": "20_PORTABLE_APPS/Misc/curl",
    "localExecutable": "20_PORTABLE_APPS/Misc/curl/curl.exe",
    "inventoryPatterns": [
      "curl.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://curl.se/windows/",
        "status": 200,
        "finalUrl": "https://curl.se/windows/",
        "title": "curl for Windows",
        "checkedAt": "2026-09-09T20:17:51.314966+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://curl.se/windows/",
        "status": 200,
        "finalUrl": "https://curl.se/windows/",
        "title": "curl for Windows",
        "checkedAt": "2026-09-09T20:17:51.314966+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "jq",
    "name": "jq",
    "developer": "jqlang project",
    "description": "Command-line JSON inspection and transformation.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "JSON"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://jqlang.org/download/",
    "officialDownload": "https://jqlang.org/download/",
    "documentation": "https://jqlang.org/download/",
    "localFolder": "20_PORTABLE_APPS/Misc/jq",
    "localExecutable": "",
    "inventoryPatterns": [
      "jq*.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://jqlang.org/download/",
        "status": 200,
        "finalUrl": "https://jqlang.org/download/",
        "title": "Download jq",
        "checkedAt": "2026-09-09T20:17:52.685670+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://jqlang.org/download/",
        "status": 200,
        "finalUrl": "https://jqlang.org/download/",
        "title": "Download jq",
        "checkedAt": "2026-09-09T20:17:52.685670+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "sqlite",
    "name": "SQLite tools",
    "developer": "SQLite project",
    "description": "Inspect local SQLite databases; work on a copy of application databases.",
    "categories": [
      "Developer Tools"
    ],
    "tags": [
      "database"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://sqlite.org/download.html",
    "officialDownload": "https://sqlite.org/download.html",
    "documentation": "https://sqlite.org/download.html",
    "localFolder": "20_PORTABLE_APPS/Misc/SQLite",
    "localExecutable": "20_PORTABLE_APPS/Misc/SQLite/sqlite3.exe",
    "inventoryPatterns": [
      "sqlite3.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://sqlite.org/download.html",
        "status": 200,
        "finalUrl": "https://sqlite.org/download.html",
        "title": "SQLite Download Page",
        "checkedAt": "2026-09-09T20:17:54.462399+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://sqlite.org/download.html",
        "status": 200,
        "finalUrl": "https://sqlite.org/download.html",
        "title": "SQLite Download Page",
        "checkedAt": "2026-09-09T20:17:54.462399+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "ventoy",
    "name": "Ventoy installer",
    "developer": "Ventoy project",
    "description": "Prepare or update multiboot media. Initial installation repartitions the selected drive.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "boot ISO USB"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 35,
    "officialWebsite": "https://www.ventoy.net/en/download.html",
    "officialDownload": "https://www.ventoy.net/en/download.html",
    "documentation": "https://www.ventoy.net/en/download.html",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/Ventoy",
    "localExecutable": "10_WINDOWS_TOOLBOX/13_USB/Ventoy/Ventoy2Disk.exe",
    "inventoryPatterns": [
      "Ventoy2Disk.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.ventoy.net/en/download.html",
        "status": 200,
        "finalUrl": "https://www.ventoy.net/en/download.html",
        "title": "Download . Ventoy",
        "checkedAt": "2026-09-09T20:17:59.597408+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.ventoy.net/en/download.html",
        "status": 200,
        "finalUrl": "https://www.ventoy.net/en/download.html",
        "title": "Download . Ventoy",
        "checkedAt": "2026-09-09T20:17:59.597408+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "usbtree",
    "name": "USB Device Tree Viewer",
    "developer": "Uwe Sieber",
    "description": "Inspect USB topology, negotiated speed and device descriptors.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "USB speed adapter"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://www.uwe-sieber.de/usbtreeview_e.html",
    "officialDownload": "https://www.uwe-sieber.de/usbtreeview_e.html",
    "documentation": "https://www.uwe-sieber.de/usbtreeview_e.html",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/USBTreeView",
    "localExecutable": "10_WINDOWS_TOOLBOX/13_USB/USBTreeView/UsbTreeView.exe",
    "inventoryPatterns": [
      "UsbTreeView.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.uwe-sieber.de/usbtreeview_e.html",
        "status": 200,
        "finalUrl": "https://www.uwe-sieber.de/usbtreeview_e.html",
        "title": "USB Device Tree Viewer",
        "checkedAt": "2026-09-09T20:17:59.267967+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.uwe-sieber.de/usbtreeview_e.html",
        "status": 200,
        "finalUrl": "https://www.uwe-sieber.de/usbtreeview_e.html",
        "title": "USB Device Tree Viewer",
        "checkedAt": "2026-09-09T20:17:59.267967+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "usbdeview",
    "name": "USBDeview",
    "developer": "NirSoft",
    "description": "Inspect USB device history; disabling or removing devices changes configuration.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "USB history"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 2,
    "officialWebsite": "https://www.nirsoft.net/utils/usb_devices_view.html",
    "officialDownload": "https://www.nirsoft.net/utils/usb_devices_view.html",
    "documentation": "https://www.nirsoft.net/utils/usb_devices_view.html",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/USBDeview",
    "localExecutable": "10_WINDOWS_TOOLBOX/13_USB/USBDeview/USBDeview.exe",
    "inventoryPatterns": [
      "USBDeview.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.nirsoft.net/utils/usb_devices_view.html",
        "status": 200,
        "finalUrl": "https://www.nirsoft.net/utils/usb_devices_view.html",
        "title": "View any installed/connected USB device on your system",
        "checkedAt": "2026-09-09T20:17:57.376581+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.nirsoft.net/utils/usb_devices_view.html",
        "status": 200,
        "finalUrl": "https://www.nirsoft.net/utils/usb_devices_view.html",
        "title": "View any installed/connected USB device on your system",
        "checkedAt": "2026-09-09T20:17:57.376581+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "mct",
    "name": "Windows Media Creation Tool",
    "developer": "Microsoft",
    "description": "Download and create Windows installation media; requires internet.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "Windows install"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 20,
    "officialWebsite": "https://www.microsoft.com/en-us/software-download/windows11",
    "officialDownload": "https://www.microsoft.com/en-us/software-download/windows11",
    "documentation": "https://www.microsoft.com/en-us/software-download/windows11",
    "localFolder": "10_WINDOWS_TOOLBOX/13_USB/MediaCreation",
    "localExecutable": "",
    "inventoryPatterns": [
      "MediaCreationTool*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.microsoft.com/en-us/software-download/windows11",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/software-download/windows11",
        "title": "Download Windows 11",
        "checkedAt": "2026-09-09T20:17:57.239917+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.microsoft.com/en-us/software-download/windows11",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/software-download/windows11",
        "title": "Download Windows 11",
        "checkedAt": "2026-09-09T20:17:57.239917+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "etcher",
    "name": "balenaEtcher",
    "developer": "balena",
    "description": "Optional image-to-USB writer; overwrites the selected destination.",
    "categories": [
      "USB Tools"
    ],
    "tags": [
      "USB image"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://etcher.balena.io/",
    "officialDownload": "https://etcher.balena.io/",
    "documentation": "https://etcher.balena.io/",
    "localFolder": "40_INSTALLERS/Utilities/Etcher",
    "localExecutable": "",
    "inventoryPatterns": [
      "balenaEtcher*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://etcher.balena.io/",
        "status": 200,
        "finalUrl": "https://etcher.balena.io/",
        "title": "balenaEtcher - Flash OS images to SD cards & USB drives",
        "checkedAt": "2026-09-09T20:17:51.464317+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://etcher.balena.io/",
        "status": 200,
        "finalUrl": "https://etcher.balena.io/",
        "title": "balenaEtcher - Flash OS images to SD cards & USB drives",
        "checkedAt": "2026-09-09T20:17:51.464317+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "unigetui",
    "name": "UniGetUI",
    "developer": "Marti Climent / Devolutions",
    "description": "Graphical frontend for package managers; package actions generally need internet.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget chocolatey scoop software"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 150,
    "officialWebsite": "https://github.com/Devolutions/UniGetUI",
    "officialDownload": "https://github.com/Devolutions/UniGetUI/releases",
    "documentation": "https://github.com/Devolutions/UniGetUI",
    "localFolder": "10_WINDOWS_TOOLBOX/09_Package-Managers/UniGetUI",
    "localExecutable": "",
    "inventoryPatterns": [
      "UniGetUI*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": false,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Project ownership now resolves to Devolutions/UniGetUI.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "githubRepo": "Devolutions/UniGetUI",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://github.com/Devolutions/UniGetUI",
        "status": 200,
        "finalUrl": "https://github.com/Devolutions/UniGetUI",
        "title": "GitHub - Devolutions/UniGetUI: UniGetUI: The Graphical Interface for your package managers. Could be terribly described as a package manager manager to manage your package managers · GitHub",
        "checkedAt": "2026-09-09T20:17:52.380847+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://github.com/Devolutions/UniGetUI/releases",
        "status": 200,
        "finalUrl": "https://github.com/Devolutions/UniGetUI/releases",
        "title": "Releases · Devolutions/UniGetUI · GitHub",
        "checkedAt": "2026-09-09T20:17:52.490186+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "chocolatey",
    "name": "Chocolatey",
    "developer": "Chocolatey Software",
    "description": "Windows package manager; audit package sources and scripts before installing.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "packages"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Freemium",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Commercial/technician use may require a separate paid license. A personal or trial edition does not establish service rights.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://chocolatey.org/install",
    "officialDownload": "https://chocolatey.org/install",
    "documentation": "https://chocolatey.org/install",
    "localFolder": "10_WINDOWS_TOOLBOX/09_Package-Managers/Chocolatey",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Online",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://chocolatey.org/install",
        "status": 200,
        "finalUrl": "https://chocolatey.org/install",
        "title": "Chocolatey Software | Installing Chocolatey",
        "checkedAt": "2026-09-09T20:17:51.290904+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://chocolatey.org/install",
        "status": 200,
        "finalUrl": "https://chocolatey.org/install",
        "title": "Chocolatey Software | Installing Chocolatey",
        "checkedAt": "2026-09-09T20:17:51.290904+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "scoop",
    "name": "Scoop",
    "developer": "ScoopInstaller project",
    "description": "User-level package manager; inspect buckets and manifests.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "packages"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://scoop.sh/",
    "officialDownload": "https://scoop.sh/",
    "documentation": "https://scoop.sh/",
    "localFolder": "10_WINDOWS_TOOLBOX/09_Package-Managers/Scoop",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Online",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://scoop.sh/",
        "status": 200,
        "finalUrl": "https://scoop.sh/",
        "title": "",
        "checkedAt": "2026-09-09T20:17:54.126937+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://scoop.sh/",
        "status": 200,
        "finalUrl": "https://scoop.sh/",
        "title": "",
        "checkedAt": "2026-09-09T20:17:54.126937+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "proxmox",
    "name": "Proxmox VE ISO",
    "developer": "Proxmox",
    "description": "Homelab hypervisor installer and rescue entry points; installer overwrites target storage.",
    "categories": [
      "Homelab / Linux",
      "Boot & Recovery"
    ],
    "tags": [
      "server virtualization"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1600,
    "officialWebsite": "https://www.proxmox.com/en/downloads",
    "officialDownload": "https://www.proxmox.com/en/downloads",
    "documentation": "https://www.proxmox.com/en/downloads",
    "localFolder": "00_BOOT/Linux-Rescue/Proxmox",
    "localExecutable": "",
    "inventoryPatterns": [
      "proxmox-ve*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.proxmox.com/en/downloads",
        "status": 200,
        "finalUrl": "https://www.proxmox.com/en/downloads",
        "title": "Download Proxmox software, datasheets, agreements",
        "checkedAt": "2026-09-09T20:17:58.243917+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.proxmox.com/en/downloads",
        "status": 200,
        "finalUrl": "https://www.proxmox.com/en/downloads",
        "title": "Download Proxmox software, datasheets, agreements",
        "checkedAt": "2026-09-09T20:17:58.243917+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "debian",
    "name": "Debian Live",
    "developer": "Debian project",
    "description": "General-purpose Linux rescue and compatibility environment.",
    "categories": [
      "Homelab / Linux",
      "Boot & Recovery"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": true,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 3500,
    "officialWebsite": "https://www.debian.org/CD/live/",
    "officialDownload": "https://www.debian.org/CD/live/",
    "documentation": "https://www.debian.org/CD/live/",
    "localFolder": "00_BOOT/Linux-Rescue/Debian",
    "localExecutable": "",
    "inventoryPatterns": [
      "debian-live*.iso"
    ],
    "kind": "Boot ISO",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.debian.org/CD/live/",
        "status": 200,
        "finalUrl": "https://www.debian.org/CD/live/",
        "title": "Debian -- Live install images",
        "checkedAt": "2026-09-09T20:17:55.169491+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.debian.org/CD/live/",
        "status": 200,
        "finalUrl": "https://www.debian.org/CD/live/",
        "title": "Debian -- Live install images",
        "checkedAt": "2026-09-09T20:17:55.169491+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "vcredist",
    "name": "Microsoft Visual C++ Redistributables",
    "developer": "Microsoft",
    "description": "Stage supported x64 and x86 packages for games and desktop applications.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "runtime DLL"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
    "officialDownload": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
    "documentation": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
    "localFolder": "40_INSTALLERS/Runtimes/Visual-Cpp",
    "localExecutable": "",
    "inventoryPatterns": [
      "vc_redist*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170",
        "title": "Latest Supported Visual C++ Redistributable Downloads | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.985979+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170",
        "title": "Latest Supported Visual C++ Redistributable Downloads | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.985979+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "dotnet",
    "name": ".NET Desktop Runtime",
    "developer": "Microsoft",
    "description": "Install the runtime major version and architecture required by the application.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "runtime"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://dotnet.microsoft.com/en-us/download/dotnet",
    "officialDownload": "https://dotnet.microsoft.com/en-us/download/dotnet",
    "documentation": "https://dotnet.microsoft.com/en-us/download/dotnet",
    "localFolder": "40_INSTALLERS/Runtimes/DotNet",
    "localExecutable": "",
    "inventoryPatterns": [
      "windowsdesktop-runtime*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://dotnet.microsoft.com/en-us/download/dotnet",
        "status": 200,
        "finalUrl": "https://dotnet.microsoft.com/en-us/download/dotnet",
        "title": "Browse all .NET versions to download | .NET",
        "checkedAt": "2026-09-09T20:17:51.241788+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://dotnet.microsoft.com/en-us/download/dotnet",
        "status": 200,
        "finalUrl": "https://dotnet.microsoft.com/en-us/download/dotnet",
        "title": "Browse all .NET versions to download | .NET",
        "checkedAt": "2026-09-09T20:17:51.241788+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "directx",
    "name": "DirectX End-User Runtimes",
    "developer": "Microsoft",
    "description": "Legacy side-by-side D3DX/XAudio libraries for older games; not a replacement for modern DirectX.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "legacy runtime"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 100,
    "officialWebsite": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
    "officialDownload": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
    "documentation": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
    "localFolder": "40_INSTALLERS/Runtimes/DirectX",
    "localExecutable": "",
    "inventoryPatterns": [
      "directx*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
        "title": "Download DirectX End-User Runtimes (June 2010) from Official Microsoft Download Center",
        "checkedAt": "2026-09-09T20:18:06.625398+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
        "status": 200,
        "finalUrl": "https://www.microsoft.com/en-us/download/details.aspx?id=8109",
        "title": "Download DirectX End-User Runtimes (June 2010) from Official Microsoft Download Center",
        "checkedAt": "2026-09-09T20:18:06.625398+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "steam",
    "name": "Steam",
    "developer": "Valve",
    "description": "Optional gaming client; account login and game downloads require internet.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "launcher"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://store.steampowered.com/about/",
    "officialDownload": "https://store.steampowered.com/about/",
    "documentation": "https://store.steampowered.com/about/",
    "localFolder": "40_INSTALLERS/Gaming/Steam",
    "localExecutable": "40_INSTALLERS/Gaming/Steam/SteamSetup.exe",
    "inventoryPatterns": [
      "SteamSetup.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://store.steampowered.com/about/",
        "status": 200,
        "finalUrl": "https://store.steampowered.com/about/",
        "title": "Steam, The Ultimate Online Game Platform",
        "checkedAt": "2026-09-09T20:17:54.372627+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://store.steampowered.com/about/",
        "status": 200,
        "finalUrl": "https://store.steampowered.com/about/",
        "title": "Steam, The Ultimate Online Game Platform",
        "checkedAt": "2026-09-09T20:17:54.372627+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "epic",
    "name": "Epic Games Launcher",
    "developer": "Epic Games",
    "description": "Optional gaming installer; do not retain customer credentials.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "launcher"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 180,
    "officialWebsite": "https://store.epicgames.com/en-US/download",
    "officialDownload": "https://store.epicgames.com/en-US/download",
    "documentation": "https://store.epicgames.com/en-US/download",
    "localFolder": "40_INSTALLERS/Gaming/Epic",
    "localExecutable": "",
    "inventoryPatterns": [
      "EpicInstaller*.msi"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://store.epicgames.com/en-US/download",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.065202+00:00"
      },
      "download": {
        "url": "https://store.epicgames.com/en-US/download",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.065202+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "battlenet",
    "name": "Battle.net",
    "developer": "Blizzard",
    "description": "Optional gaming client with internet and account requirements.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "launcher"
    ],
    "useCases": [],
    "priority": "P4",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 10,
    "officialWebsite": "https://download.battle.net/",
    "officialDownload": "https://download.battle.net/",
    "documentation": "https://download.battle.net/",
    "localFolder": "40_INSTALLERS/Gaming/BattleNet",
    "localExecutable": "",
    "inventoryPatterns": [
      "Battle.net*.exe"
    ],
    "kind": "Installer",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://download.battle.net/",
        "status": 200,
        "finalUrl": "https://download.battle.net/en-us/",
        "title": "Download Battle.net | Battle.net",
        "checkedAt": "2026-09-09T20:17:52.421533+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://download.battle.net/",
        "status": 200,
        "finalUrl": "https://download.battle.net/en-us/",
        "title": "Download Battle.net | Battle.net",
        "checkedAt": "2026-09-09T20:17:52.421533+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "intel-network",
    "name": "Intel Ethernet / Wi-Fi / Bluetooth",
    "developer": "Intel",
    "description": "Stage Ethernet, Wi-Fi and Bluetooth packages matched to hardware IDs.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "officialDownload": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "documentation": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "localFolder": "30_DRIVERS/Intel/Network",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      },
      "download": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "intel-chipset",
    "name": "Intel Chipset Device Software",
    "developer": "Intel",
    "description": "Chipset identification packages; prefer the PC vendor for OEM platforms.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "officialDownload": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "documentation": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "localFolder": "30_DRIVERS/Intel/Chipset",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      },
      "download": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "intel-gpu",
    "name": "Intel Graphics / Arc drivers",
    "developer": "Intel",
    "description": "Graphics driver packages matched to GPU generation and OS.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "officialDownload": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "documentation": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "localFolder": "30_DRIVERS/Intel/Graphics",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      },
      "download": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "amd-chipset",
    "name": "AMD chipset drivers",
    "developer": "AMD",
    "description": "Platform chipset support; distinguish desktop and mobile OEM systems.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.amd.com/en/support/download/drivers.html",
    "officialDownload": "https://www.amd.com/en/support/download/drivers.html",
    "documentation": "https://www.amd.com/en/support/download/drivers.html",
    "localFolder": "30_DRIVERS/AMD/Chipset",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "amd-gpu",
    "name": "AMD Software: Adrenalin Edition",
    "developer": "AMD",
    "description": "Radeon GPU driver library; select the correct supported GPU.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.amd.com/en/support/download/drivers.html",
    "officialDownload": "https://www.amd.com/en/support/download/drivers.html",
    "documentation": "https://www.amd.com/en/support/download/drivers.html",
    "localFolder": "30_DRIVERS/AMD/Graphics",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "nvidia",
    "name": "NVIDIA graphics drivers",
    "developer": "NVIDIA",
    "description": "Game Ready or Studio driver matched to GPU and OS.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.nvidia.com/en-us/drivers/",
    "officialDownload": "https://www.nvidia.com/en-us/drivers/",
    "documentation": "https://www.nvidia.com/en-us/drivers/",
    "localFolder": "30_DRIVERS/NVIDIA",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.nvidia.com/en-us/drivers/",
        "status": 200,
        "finalUrl": "https://www.nvidia.com/en-us/drivers/",
        "title": "Download The Official NVIDIA Drivers | NVIDIA",
        "checkedAt": "2026-09-09T20:17:56.868563+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.nvidia.com/en-us/drivers/",
        "status": 200,
        "finalUrl": "https://www.nvidia.com/en-us/drivers/",
        "title": "Download The Official NVIDIA Drivers | NVIDIA",
        "checkedAt": "2026-09-09T20:17:56.868563+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "realtek",
    "name": "Realtek network / audio drivers",
    "developer": "Realtek",
    "description": "Prefer OEM audio customizations; stage matching Ethernet and Wi-Fi packages.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.realtek.com/Download/List",
    "officialDownload": "https://www.realtek.com/Download/List",
    "documentation": "https://www.realtek.com/Download/List",
    "localFolder": "30_DRIVERS/Realtek",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.realtek.com/Download/List",
        "status": 200,
        "finalUrl": "https://www.realtek.com/Download/List",
        "title": "Realtek",
        "checkedAt": "2026-09-09T20:17:58.334569+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.realtek.com/Download/List",
        "status": 200,
        "finalUrl": "https://www.realtek.com/Download/List",
        "title": "Realtek",
        "checkedAt": "2026-09-09T20:17:58.334569+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "hpia",
    "name": "HP Image Assistant",
    "developer": "HP",
    "description": "Commercial HP platform driver analysis; stage supported SoftPaqs for offline work.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
    "officialDownload": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
    "documentation": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
    "localFolder": "30_DRIVERS/HP",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
        "status": 200,
        "finalUrl": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
        "title": "HP Image Assistant | HP Client Management Solutions",
        "checkedAt": "2026-09-09T20:17:51.363576+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
        "status": 200,
        "finalUrl": "https://ftp.ext.hp.com/pub/caps-softpaq/cmit/HPIA.html",
        "title": "HP Image Assistant | HP Client Management Solutions",
        "checkedAt": "2026-09-09T20:17:51.363576+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "dell",
    "name": "Dell Command Update",
    "developer": "Dell",
    "description": "Installed Dell commercial platform updater; requires supported model and source access.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
    "officialDownload": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
    "documentation": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
    "localFolder": "30_DRIVERS/Dell",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
        "status": 200,
        "finalUrl": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
        "title": "Dell Command | Update | Dell US",
        "checkedAt": "2026-09-09T20:17:55.569855+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
        "status": 200,
        "finalUrl": "https://www.dell.com/support/kbdoc/en-us/000177325/dell-command-update",
        "title": "Dell Command | Update | Dell US",
        "checkedAt": "2026-09-09T20:17:55.569855+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "lenovo",
    "name": "Lenovo System Update",
    "developer": "Lenovo",
    "description": "Supported Lenovo model driver updates; store downloaded model packages.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://support.lenovo.com/us/en/solutions/ht003029",
    "officialDownload": "https://support.lenovo.com/us/en/solutions/ht003029",
    "documentation": "https://support.lenovo.com/us/en/solutions/ht003029",
    "localFolder": "30_DRIVERS/Lenovo",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://support.lenovo.com/us/en/solutions/ht003029",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.269819+00:00"
      },
      "download": {
        "url": "https://support.lenovo.com/us/en/solutions/ht003029",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.269819+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "surface",
    "name": "Microsoft Surface driver / firmware packs",
    "developer": "Microsoft",
    "description": "MSI bundles must match the Surface model and supported Windows build.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "no Wi-Fi no network Ethernet GPU crash driver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 1500,
    "officialWebsite": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
    "officialDownload": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
    "documentation": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
    "localFolder": "30_DRIVERS/Microsoft-Surface",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Driver",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "An offline installer is usable only on matching hardware. Web bootstrap installers need internet.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
        "title": "Manage & deploy Surface driver & firmware updates - Surface | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.716237+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/surface/manage-surface-driver-and-firmware-updates",
        "title": "Manage & deploy Surface driver & firmware updates - Surface | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.716237+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "firmware-hp",
    "name": "HP firmware / BIOS support",
    "developer": "HP",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "HP BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://support.hp.com/us-en/drivers",
    "officialDownload": "https://support.hp.com/us-en/drivers",
    "documentation": "https://support.hp.com/us-en/drivers",
    "localFolder": "50_FIRMWARE/HP",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://support.hp.com/us-en/drivers",
        "status": 200,
        "finalUrl": "https://support.hp.com/us-en/drivers",
        "title": "",
        "checkedAt": "2026-09-09T20:17:54.407221+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://support.hp.com/us-en/drivers",
        "status": 200,
        "finalUrl": "https://support.hp.com/us-en/drivers",
        "title": "",
        "checkedAt": "2026-09-09T20:17:54.407221+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "firmware-dell",
    "name": "Dell firmware / BIOS support",
    "developer": "Dell",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Dell BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.dell.com/support/home/en-us?app=drivers",
    "officialDownload": "https://www.dell.com/support/home/en-us?app=drivers",
    "documentation": "https://www.dell.com/support/home/en-us?app=drivers",
    "localFolder": "50_FIRMWARE/Dell",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.dell.com/support/home/en-us?app=drivers",
        "status": 200,
        "finalUrl": "https://www.dell.com/support/home/en-us?app=drivers",
        "title": "Drivers & Downloads | Dell US",
        "checkedAt": "2026-09-09T20:17:55.452614+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.dell.com/support/home/en-us?app=drivers",
        "status": 200,
        "finalUrl": "https://www.dell.com/support/home/en-us?app=drivers",
        "title": "Drivers & Downloads | Dell US",
        "checkedAt": "2026-09-09T20:17:55.452614+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "firmware-lenovo",
    "name": "Lenovo firmware / BIOS support",
    "developer": "Lenovo",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Lenovo BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://support.lenovo.com/",
    "officialDownload": "https://support.lenovo.com/",
    "documentation": "https://support.lenovo.com/",
    "localFolder": "50_FIRMWARE/Lenovo",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://support.lenovo.com/",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.303938+00:00"
      },
      "download": {
        "url": "https://support.lenovo.com/",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:54.303938+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "firmware-asus",
    "name": "ASUS firmware / BIOS support",
    "developer": "ASUS",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "ASUS BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.asus.com/support/download-center/",
    "officialDownload": "https://www.asus.com/support/download-center/",
    "documentation": "https://www.asus.com/support/download-center/",
    "localFolder": "50_FIRMWARE/BIOS/ASUS",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.asus.com/support/download-center/",
        "status": 200,
        "finalUrl": "https://www.asus.com/support/download-center/",
        "title": "Download Center | Official Support | ASUS Global",
        "checkedAt": "2026-09-09T20:17:54.835696+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.asus.com/support/download-center/",
        "status": 200,
        "finalUrl": "https://www.asus.com/support/download-center/",
        "title": "Download Center | Official Support | ASUS Global",
        "checkedAt": "2026-09-09T20:17:54.835696+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "firmware-acer",
    "name": "Acer firmware / BIOS support",
    "developer": "Acer",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Acer BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.acer.com/us-en/support/drivers-and-manuals",
    "officialDownload": "https://www.acer.com/us-en/support/drivers-and-manuals",
    "documentation": "https://www.acer.com/us-en/support/drivers-and-manuals",
    "localFolder": "50_FIRMWARE/BIOS/Acer",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.acer.com/us-en/support/drivers-and-manuals",
        "status": "unconfirmed",
        "error": "The read operation timed out",
        "checkedAt": "2026-09-09T20:18:19.720693+00:00"
      },
      "download": {
        "url": "https://www.acer.com/us-en/support/drivers-and-manuals",
        "status": "unconfirmed",
        "error": "The read operation timed out",
        "checkedAt": "2026-09-09T20:18:19.720693+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "firmware-msi",
    "name": "MSI firmware / BIOS support",
    "developer": "MSI",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "MSI BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.msi.com/support/download",
    "officialDownload": "https://www.msi.com/support/download",
    "documentation": "https://www.msi.com/support/download",
    "localFolder": "50_FIRMWARE/BIOS/MSI",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.msi.com/support/download",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:56.489148+00:00"
      },
      "download": {
        "url": "https://www.msi.com/support/download",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:56.489148+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "firmware-gigabyte",
    "name": "Gigabyte firmware / BIOS support",
    "developer": "Gigabyte",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Gigabyte BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.gigabyte.com/Support",
    "officialDownload": "https://www.gigabyte.com/Support",
    "documentation": "https://www.gigabyte.com/Support",
    "localFolder": "50_FIRMWARE/BIOS/Gigabyte",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.gigabyte.com/Support",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:55.362405+00:00"
      },
      "download": {
        "url": "https://www.gigabyte.com/Support",
        "status": "unconfirmed",
        "error": "HTTP Error 403: Forbidden",
        "checkedAt": "2026-09-09T20:17:55.362405+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "firmware-intel",
    "name": "Intel firmware / BIOS support",
    "developer": "Intel",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "Intel BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "officialDownload": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "documentation": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "localFolder": "50_FIRMWARE/Intel",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      },
      "download": {
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "status": "unconfirmed",
        "error": "<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1016)>",
        "checkedAt": "2026-09-09T20:17:55.592407+00:00"
      }
    },
    "sourceReviewNotes": "Primary page reviewed through web retrieval on 2026-09-09; direct HTTP checks may be blocked."
  },
  {
    "id": "firmware-amd",
    "name": "AMD firmware / BIOS support",
    "developer": "AMD",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "AMD BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.amd.com/en/support/download/drivers.html",
    "officialDownload": "https://www.amd.com/en/support/download/drivers.html",
    "documentation": "https://www.amd.com/en/support/download/drivers.html",
    "localFolder": "50_FIRMWARE/AMD",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.amd.com/en/support/download/drivers.html",
        "status": 200,
        "finalUrl": "https://www.amd.com/en/support/download/drivers.html",
        "title": "Drivers and Support for Processors and Graphics",
        "checkedAt": "2026-09-09T20:17:54.990020+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "firmware-nvidia",
    "name": "NVIDIA firmware / BIOS support",
    "developer": "NVIDIA",
    "description": "Find firmware for the exact model and hardware revision. Read prerequisites and rollback instructions.",
    "categories": [
      "Firmware"
    ],
    "tags": [
      "NVIDIA BIOS firmware"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 50,
    "officialWebsite": "https://www.nvidia.com/en-us/drivers/",
    "officialDownload": "https://www.nvidia.com/en-us/drivers/",
    "documentation": "https://www.nvidia.com/en-us/drivers/",
    "localFolder": "50_FIRMWARE/BIOS/NVIDIA",
    "localExecutable": "",
    "inventoryPatterns": [
      "*.exe",
      "*.msi",
      "*.zip",
      "*.cab",
      "*.inf",
      "*.bin",
      "*.cap"
    ],
    "kind": "Firmware",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "Ensure stable power and correct model/firmware before flashing. Record BitLocker recovery-key access and follow vendor suspension instructions. Never interrupt a flash.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.nvidia.com/en-us/drivers/",
        "status": 200,
        "finalUrl": "https://www.nvidia.com/en-us/drivers/",
        "title": "Download The Official NVIDIA Drivers | NVIDIA",
        "checkedAt": "2026-09-09T20:17:56.868563+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://www.nvidia.com/en-us/drivers/",
        "status": 200,
        "finalUrl": "https://www.nvidia.com/en-us/drivers/",
        "title": "Download The Official NVIDIA Drivers | NVIDIA",
        "checkedAt": "2026-09-09T20:17:56.868563+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "sysinternals",
    "name": "Sysinternals Suite",
    "developer": "Microsoft",
    "description": "Core portable Windows diagnostics, process inspection and administration suite. Individual tools are searchable below.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "Sysinternals suite"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 200,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/procexp64.exe",
    "inventoryPatterns": [
      "procexp64.exe",
      "Autoruns64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " The entire official suite is the parent archive; individual records highlight frequently used members. Parent detection requires configured marker files, not every suite member.",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": true,
    "inventoryMatch": "all",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
        "title": "Sysinternals Suite - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.326785+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sysinternals-suite",
        "title": "Sysinternals Suite - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.326785+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "autoruns",
    "name": "Autoruns",
    "developer": "Microsoft Sysinternals",
    "description": "Inspect startup persistence and scheduled launch points. Disable selectively after recording originals.",
    "categories": [
      "Startup & Processes",
      "Malware & Security"
    ],
    "tags": [
      "malware Windows slow"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/autoruns64.exe",
    "inventoryPatterns": [
      "autoruns64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
        "title": "Autoruns - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.811989+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns",
        "title": "Autoruns - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.811989+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "process-explorer",
    "name": "Process Explorer",
    "developer": "Microsoft Sysinternals",
    "description": "Inspect processes, handles and loaded modules; use signatures to support investigation.",
    "categories": [
      "Startup & Processes",
      "Malware & Security"
    ],
    "tags": [
      "Windows slow malware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/procexp64.exe",
    "inventoryPatterns": [
      "procexp64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
        "title": "Process Explorer - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.847580+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/process-explorer",
        "title": "Process Explorer - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.847580+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "procmon",
    "name": "Process Monitor",
    "developer": "Microsoft Sysinternals",
    "description": "Trace file, registry and process activity with filters; logs may contain private paths.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "Windows repair"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/Procmon64.exe",
    "inventoryPatterns": [
      "Procmon64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
        "title": "Process Monitor - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.069848+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/procmon",
        "title": "Process Monitor - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.069848+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "tcpview",
    "name": "TCPView",
    "developer": "Microsoft Sysinternals",
    "description": "Map live TCP/UDP connections to owning processes.",
    "categories": [
      "Startup & Processes",
      "Networking",
      "Malware & Security"
    ],
    "tags": [
      "network malware"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/tcpview64.exe",
    "inventoryPatterns": [
      "tcpview64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
        "title": "TCPView for Windows - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.327784+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/tcpview",
        "title": "TCPView for Windows - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.327784+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "rammap",
    "name": "RAMMap",
    "developer": "Microsoft Sysinternals",
    "description": "Understand physical memory use and file cache; avoid treating cache as wasted RAM.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "RAM memory"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/RAMMap64.exe",
    "inventoryPatterns": [
      "RAMMap64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
        "title": "RAMMap - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.069848+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/rammap",
        "title": "RAMMap - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.069848+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "disk2vhd",
    "name": "Disk2vhd",
    "developer": "Microsoft Sysinternals",
    "description": "Capture Windows volumes into virtual disks; use consistent snapshots and a separate destination.",
    "categories": [
      "Startup & Processes",
      "Imaging & Cloning"
    ],
    "tags": [
      "SSD clone imaging"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/disk2vhd64.exe",
    "inventoryPatterns": [
      "disk2vhd64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
        "title": "Disk2vhd - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.752323+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/disk2vhd",
        "title": "Disk2vhd - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.752323+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "sigcheck",
    "name": "Sigcheck",
    "developer": "Microsoft Sysinternals",
    "description": "Inspect file signatures and hashes; online reputation options transmit data.",
    "categories": [
      "Startup & Processes",
      "Malware & Security"
    ],
    "tags": [
      "malware signature"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/sigcheck64.exe",
    "inventoryPatterns": [
      "sigcheck64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
        "title": "Sigcheck - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.420190+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sigcheck",
        "title": "Sigcheck - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.420190+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "pstools",
    "name": "PsTools",
    "developer": "Microsoft Sysinternals",
    "description": "Administrative command-line suite; remote execution requires explicit authorization.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "remote administration"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/PsInfo64.exe",
    "inventoryPatterns": [
      "PsInfo64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
        "title": "PsTools - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.072367+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/pstools",
        "title": "PsTools - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.072367+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "procdump",
    "name": "ProcDump",
    "developer": "Microsoft Sysinternals",
    "description": "Capture process dumps for crash analysis. Dumps may contain sensitive memory.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "BSOD crash"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/procdump64.exe",
    "inventoryPatterns": [
      "procdump64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
        "title": "ProcDump - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.809473+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/procdump",
        "title": "ProcDump - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:52.809473+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "handle",
    "name": "Handle",
    "developer": "Microsoft Sysinternals",
    "description": "Identify processes holding file handles; avoid forced handle closure.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "locked file"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/handle64.exe",
    "inventoryPatterns": [
      "handle64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
        "title": "Handle - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.014554+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/handle",
        "title": "Handle - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.014554+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "strings",
    "name": "Strings",
    "developer": "Microsoft Sysinternals",
    "description": "Extract printable strings from files for offline inspection.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "text binaries"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/strings64.exe",
    "inventoryPatterns": [
      "strings64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
        "title": "Strings - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.220255+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/strings",
        "title": "Strings - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.220255+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "sdelete",
    "name": "SDelete",
    "developer": "Microsoft Sysinternals",
    "description": "Secure deletion utility. SSD wear leveling means file overwrite is not a guaranteed media sanitization method.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "erase delete"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/sdelete64.exe",
    "inventoryPatterns": [
      "sdelete64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
        "title": "SDelete - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.189679+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/sdelete",
        "title": "SDelete - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.189679+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "zoomit",
    "name": "ZoomIt",
    "developer": "Microsoft Sysinternals",
    "description": "Screen zoom and annotation for support demonstrations.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "presentation"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/ZoomIt64.exe",
    "inventoryPatterns": [
      "ZoomIt64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
        "title": "ZoomIt - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.377090+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/zoomit",
        "title": "ZoomIt - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.377090+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "psping",
    "name": "PsPing",
    "developer": "Microsoft Sysinternals",
    "description": "Measure ICMP/TCP connectivity and latency on authorized systems.",
    "categories": [
      "Startup & Processes",
      "Networking"
    ],
    "tags": [
      "packet loss port test"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": true,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 5,
    "officialWebsite": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
    "officialDownload": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
    "documentation": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
    "localFolder": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals",
    "localExecutable": "10_WINDOWS_TOOLBOX/05_Startup-Processes/Sysinternals/psping64.exe",
    "inventoryPatterns": [
      "psping64.exe"
    ],
    "kind": "Portable",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
        "title": "PsPing - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.015556+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/sysinternals/downloads/psping",
        "title": "PsPing - Sysinternals | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.015556+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "sfc",
    "name": "System File Checker",
    "developer": "Microsoft",
    "description": "Checks and repairs protected Windows files; run elevated and review CBS logs.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "sfc /scannow"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "sfc /scannow",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
        "title": "sfc | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:54.787105+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/sfc",
        "title": "sfc | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:54.787105+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "dism",
    "name": "DISM component store repair",
    "developer": "Microsoft",
    "description": "Repairs the running Windows component store. May require internet or a matching local repair source.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "DISM /Online /Cleanup-Image /RestoreHealth"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "DISM /Online /Cleanup-Image /RestoreHealth",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism?view=windows-11",
        "title": "DISM Overview | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.703748+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/what-is-dism?view=windows-11",
        "title": "DISM Overview | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.703748+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "chkdsk",
    "name": "CHKDSK read-only check",
    "developer": "Microsoft",
    "description": "Reports filesystem errors without /f or /r. Image a failing drive before repair or extensive scans.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "chkdsk C:"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "chkdsk C:",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#diskpart",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
        "title": "chkdsk | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.421701+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/chkdsk",
        "title": "chkdsk | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.421701+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "msconfig",
    "name": "System Configuration",
    "developer": "Microsoft",
    "description": "Review startup options. Persistent Safe Boot can strand a system; record changes.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "msconfig"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "msconfig",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "msinfo32",
    "name": "System Information",
    "developer": "Microsoft",
    "description": "Inspect hardware, BIOS mode, Secure Boot and Windows details.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "msinfo32"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "msinfo32",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
        "title": "msinfo32 | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.451061+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/msinfo32",
        "title": "msinfo32 | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.451061+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "dxdiag",
    "name": "DirectX Diagnostic Tool",
    "developer": "Microsoft",
    "description": "Collect graphics/audio information for GPU troubleshooting.",
    "categories": [
      "Gaming"
    ],
    "tags": [
      "dxdiag"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "dxdiag",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "eventvwr",
    "name": "Event Viewer",
    "developer": "Microsoft",
    "description": "Correlate errors by timestamp; an event alone does not prove the root cause.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "eventvwr.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "eventvwr.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "perfmon",
    "name": "Performance Monitor",
    "developer": "Microsoft",
    "description": "Track system performance counters over time.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "perfmon"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "perfmon",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "reliability",
    "name": "Reliability Monitor",
    "developer": "Microsoft",
    "description": "Review crashes and update history on a timeline.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "perfmon /rel",
      "BSOD",
      "blue screen",
      "crash"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "perfmon /rel",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "resmon",
    "name": "Resource Monitor",
    "developer": "Microsoft",
    "description": "Inspect CPU, disk, memory and network activity.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "resmon"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "resmon",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "taskmgr",
    "name": "Task Manager",
    "developer": "Microsoft",
    "description": "Inspect running processes and startup impact; ending tasks can lose work.",
    "categories": [
      "Startup & Processes"
    ],
    "tags": [
      "taskmgr"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "taskmgr",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "services",
    "name": "Services console",
    "developer": "Microsoft",
    "description": "Review service status and dependencies; do not arbitrarily disable services.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "services.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "services.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "devmgmt",
    "name": "Device Manager",
    "developer": "Microsoft",
    "description": "Inspect device error codes, hardware IDs and driver rollback options.",
    "categories": [
      "Drivers"
    ],
    "tags": [
      "devmgmt.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "devmgmt.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "diskmgmt",
    "name": "Disk Management",
    "developer": "Microsoft",
    "description": "View disk layout. Initializing, formatting and deleting volumes destroy data.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "diskmgmt.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "diskmgmt.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#diskpart",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "diskpart",
    "name": "DiskPart inventory",
    "developer": "Microsoft",
    "description": "Inventory only. CLEAN, FORMAT and DELETE are destructive; no erase commands are provided here.",
    "categories": [
      "Disk & Partition"
    ],
    "tags": [
      "diskpart list disk list volume exit"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "diskpart\nlist disk\nlist volume\nexit",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#diskpart",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
        "title": "diskpart | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.566388+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/diskpart",
        "title": "diskpart | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.566388+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "compmgmt",
    "name": "Computer Management",
    "developer": "Microsoft",
    "description": "Administrative consoles for events, disks and local accounts; edition support varies.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "compmgmt.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "compmgmt.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "regedit",
    "name": "Registry Editor",
    "developer": "Microsoft",
    "description": "Export the specific key before editing; avoid registry cleaners.",
    "categories": [
      "Windows Tweaks"
    ],
    "tags": [
      "regedit"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "regedit",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "gpedit",
    "name": "Local Group Policy Editor",
    "developer": "Microsoft",
    "description": "Review supported local policies; unavailable on Home editions. Managed policy can override changes.",
    "categories": [
      "Windows Privacy"
    ],
    "tags": [
      "gpedit.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "gpedit.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "secpol",
    "name": "Local Security Policy",
    "developer": "Microsoft",
    "description": "Review local security policy on supported Windows editions.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "secpol.msc"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "secpol.msc",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#bitlocker",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "netplwiz",
    "name": "User Accounts",
    "developer": "Microsoft",
    "description": "Authorized local account administration; do not configure insecure automatic sign-in.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "netplwiz"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "netplwiz",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#bitlocker",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "cleanmgr",
    "name": "Disk Cleanup",
    "developer": "Microsoft",
    "description": "Review selected cleanup categories; previous installations may be needed for rollback.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "cleanmgr"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "cleanmgr",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "mrt",
    "name": "Malicious Software Removal Tool",
    "developer": "Microsoft",
    "description": "Windows malware removal tool for a limited threat set; not a complete antivirus replacement.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "mrt"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "mrt",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "optionalfeatures",
    "name": "Windows Features",
    "developer": "Microsoft",
    "description": "Review optional components; enabling features may require installation sources.",
    "categories": [
      "Windows Tweaks"
    ],
    "tags": [
      "optionalfeatures"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "optionalfeatures",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "appwiz",
    "name": "Programs and Features",
    "developer": "Microsoft",
    "description": "Use the vendor uninstall path before forced leftover cleanup.",
    "categories": [
      "Uninstallers"
    ],
    "tags": [
      "appwiz.cpl"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "appwiz.cpl",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "ncpa",
    "name": "Network Connections",
    "developer": "Microsoft",
    "description": "Inspect adapter properties; changing bindings can interrupt access.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "ncpa.cpl"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "ncpa.cpl",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "powercfg",
    "name": "Power configuration report",
    "developer": "Microsoft",
    "description": "List available sleep states before diagnosing power behavior.",
    "categories": [
      "Hardware Diagnostics"
    ],
    "tags": [
      "powercfg /a"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reviewed (web)",
    "command": "powercfg /a",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "reviewedUrl": "https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/powercfg-command-line-options",
      "checkedAt": "2026-09-09",
      "method": "web retrieval"
    }
  },
  {
    "id": "winget",
    "name": "WinGet package manager",
    "developer": "Microsoft",
    "description": "List installed packages. Availability depends on App Installer and Windows edition.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget list"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "winget list",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "winget-upgrade",
    "name": "WinGet upgrade preview",
    "developer": "Microsoft",
    "description": "List packages with available upgrades without installing them; requires source access.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget upgrade"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "winget upgrade",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "winget-export",
    "name": "Export package list",
    "developer": "Microsoft",
    "description": "Creates a package inventory in the current directory; review before sharing.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget export -o packages.json"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "winget export -o packages.json",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "winget-install",
    "name": "Install common software with WinGet",
    "developer": "Microsoft",
    "description": "Installs 7-Zip after reviewing source and installer prompts; needs internet.",
    "categories": [
      "Software Installers"
    ],
    "tags": [
      "winget install --id 7zip.7zip --exact"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "winget install --id 7zip.7zip --exact",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "robocopy",
    "name": "Robocopy copy preview",
    "developer": "Microsoft",
    "description": "Replace paths; /L previews. /MIR and /PURGE can delete destination files and are intentionally omitted.",
    "categories": [
      "Data Recovery"
    ],
    "tags": [
      "robocopy \"SOURCE\" \"DESTINATION\" /E /L /R:1 /W:1"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "robocopy \"SOURCE\" \"DESTINATION\" /E /L /R:1 /W:1",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
        "title": "Robocopy | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.773919+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/robocopy",
        "title": "Robocopy | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.773919+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "cipher",
    "name": "EFS encryption information",
    "developer": "Microsoft",
    "description": "Replace FILE to inspect EFS encryption. EFS certificate recovery is different from BitLocker recovery.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "cipher /c \"FILE\""
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "cipher /c \"FILE\"",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#bitlocker",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
        "title": "cipher | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.529281+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/cipher",
        "title": "cipher | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.529281+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "manage-bde",
    "name": "BitLocker status",
    "developer": "Microsoft",
    "description": "Read volume encryption state. Authorized systems only; no encryption bypass exists here.",
    "categories": [
      "Account & OOBE"
    ],
    "tags": [
      "manage-bde -status"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "manage-bde -status",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#bitlocker",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
        "title": "manage-bde | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.565389+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/manage-bde",
        "title": "manage-bde | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.565389+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "reagentc",
    "name": "Windows RE status",
    "developer": "Microsoft",
    "description": "Inspect WinRE configuration from an elevated terminal.",
    "categories": [
      "Boot & Recovery"
    ],
    "tags": [
      "reagentc /info"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "reagentc /info",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "bcdedit",
    "name": "BCD inspection",
    "developer": "Microsoft",
    "description": "Elevated read of boot entries. BCD edits can make a machine unbootable.",
    "categories": [
      "Boot & Recovery"
    ],
    "tags": [
      "bcdedit /enum all"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "bcdedit /enum all",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
        "title": "bcdedit | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.704749+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/bcdedit",
        "title": "bcdedit | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.704749+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "ipconfig",
    "name": "IP configuration",
    "developer": "Microsoft",
    "description": "Inspect addressing, DNS servers and DHCP state. APIPA suggests no DHCP lease.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "ipconfig /all"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "ipconfig /all",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
        "title": "ipconfig | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.505223+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
        "title": "ipconfig | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.505223+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "dns",
    "name": "DNS lookup",
    "developer": "Microsoft",
    "description": "Compare lookup results against expected DNS; external names need internet.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "nslookup example.com"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "nslookup example.com",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
        "title": "nslookup | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.648594+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/nslookup",
        "title": "nslookup | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.648594+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "tracert",
    "name": "Route trace",
    "developer": "Microsoft",
    "description": "Trace route without reverse DNS. Missing hops can be filtering rather than failure.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "tracert -d example.com"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "tracert -d example.com",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
        "title": "tracert | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.804496+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/tracert",
        "title": "tracert | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.804496+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "porttest",
    "name": "TCP port test",
    "developer": "Microsoft",
    "description": "PowerShell connectivity test. Replace host and port with an authorized endpoint.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "Test-NetConnection example.com -Port 443"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Test-NetConnection example.com -Port 443",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "netadapter",
    "name": "Network adapter status",
    "developer": "Microsoft",
    "description": "PowerShell adapter status and negotiated link speed.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "Get-NetAdapter ",
      " Format-Table Name, Status, LinkSpeed"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Get-NetAdapter | Format-Table Name, Status, LinkSpeed",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "netip",
    "name": "PowerShell IP configuration",
    "developer": "Microsoft",
    "description": "Inspect interfaces, gateways and DNS settings.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "Get-NetIPConfiguration"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Get-NetIPConfiguration",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "flushdns",
    "name": "Flush DNS cache",
    "developer": "Microsoft",
    "description": "Clear cached resolver results after correcting DNS configuration.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "ipconfig /flushdns"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "ipconfig /flushdns",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "winsock",
    "name": "Winsock reset",
    "developer": "Microsoft",
    "description": "Elevated reset; may affect VPN/security software and requires restart. Record current settings first.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "netsh winsock reset"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "netsh winsock reset",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "ping",
    "name": "Packet loss sample",
    "developer": "Microsoft",
    "description": "Compare gateway and external host tests. ICMP may be filtered.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "ping -n 20 example.com"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "ping -n 20 example.com",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
        "title": "ping | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.649592+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ping",
        "title": "ping | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.649592+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "wlan",
    "name": "Wi-Fi interface details",
    "developer": "Microsoft",
    "description": "Inspect SSID, radio and signal details; avoid exporting credentials.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "netsh wlan show interfaces"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "netsh wlan show interfaces",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "arp",
    "name": "Neighbor / duplicate IP inspection",
    "developer": "Microsoft",
    "description": "Compare IP-to-MAC observations with DHCP records; investigate changes before assigning addresses.",
    "categories": [
      "Networking"
    ],
    "tags": [
      "arp -a"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "arp -a",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#networking",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
        "title": "arp | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.296213+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/arp",
        "title": "arp | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.296213+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "restore",
    "name": "System Restore",
    "developer": "Microsoft",
    "description": "Review available restore points; affected applications may need reinstalling.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "rstrui.exe"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "rstrui.exe",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "installer",
    "name": "Windows Installer service check",
    "developer": "Microsoft",
    "description": "PowerShell service inspection. A stopped demand-start service alone is not a fault.",
    "categories": [
      "Windows Repair"
    ],
    "tags": [
      "Get-Service msiserver"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Get-Service msiserver",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "quickassist",
    "name": "Windows Quick Assist",
    "developer": "Microsoft",
    "description": "Attended support with a one-time code; app availability and internet are required.",
    "categories": [
      "Remote Support"
    ],
    "tags": [
      "quickassist"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": false,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": " Attended access only by default. Unattended service installation and enrollment must be separately authorized.",
    "sourceStatus": "Official page reachable",
    "command": "quickassist",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "defenderoffline",
    "name": "Microsoft Defender Offline",
    "developer": "Microsoft",
    "description": "Elevated PowerShell starts an offline scan and restarts the PC. Save work and confirm recovery-key access first.",
    "categories": [
      "Malware & Security"
    ],
    "tags": [
      "Start-MpWDOScan"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included with OS",
    "personalLicenseNotes": "Review the selected edition's current terms.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "officialDownload": "",
    "documentation": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "",
    "sourceStatus": "Official page reachable",
    "command": "Start-MpWDOScan",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#windows-recovery",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "status": 200,
        "finalUrl": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/windows-commands",
        "title": "Windows commands | Microsoft Learn",
        "checkedAt": "2026-09-09T20:17:53.837080+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "ddrescue",
    "name": "GNU ddrescue",
    "developer": "GNU / Linux community",
    "description": "Image failing media with a mapfile to resume. Identify source and a healthy destination; follow the local recovery guide.",
    "categories": [
      "Homelab / Linux",
      "Data Recovery",
      "Imaging & Cloning"
    ],
    "tags": [
      "Linux rescue SSD recover files"
    ],
    "useCases": [],
    "priority": "P1",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.gnu.org/software/ddrescue/",
    "officialDownload": "",
    "documentation": "https://www.gnu.org/software/ddrescue/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding. Never save recovered files to the damaged source. Image failing media first; preserve the original.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "ddrescue --help",
    "defaultFavorite": true,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.gnu.org/software/ddrescue/",
        "status": 200,
        "finalUrl": "https://www.gnu.org/software/ddrescue/",
        "title": "Ddrescue - GNU Project - Free Software Foundation (FSF)",
        "checkedAt": "2026-09-09T20:17:55.671088+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.gnu.org/software/ddrescue/",
        "status": 200,
        "finalUrl": "https://www.gnu.org/software/ddrescue/",
        "title": "Ddrescue - GNU Project - Free Software Foundation (FSF)",
        "checkedAt": "2026-09-09T20:17:55.671088+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "dd",
    "name": "dd",
    "developer": "GNU / Linux community",
    "description": "Raw block copying for healthy sources only. A reversed output device overwrites the wrong disk. Prefer a guided cloning tool.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
    "officialDownload": "",
    "documentation": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "dd --help",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
        "status": 200,
        "finalUrl": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
        "title": "dd invocation (GNU Coreutils 9.11)",
        "checkedAt": "2026-09-09T20:17:55.702162+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
        "status": 200,
        "finalUrl": "https://www.gnu.org/software/coreutils/manual/html_node/dd-invocation.html",
        "title": "dd invocation (GNU Coreutils 9.11)",
        "checkedAt": "2026-09-09T20:17:55.702162+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "ssh",
    "name": "OpenSSH client",
    "developer": "GNU / Linux community",
    "description": "Authorized remote shell; verify host key through a trusted channel.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.openssh.com/manual.html",
    "officialDownload": "",
    "documentation": "https://www.openssh.com/manual.html",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "ssh user@HOST",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.openssh.com/manual.html",
        "status": 200,
        "finalUrl": "https://www.openssh.org/manual.html",
        "title": "OpenSSH: Manual Pages",
        "checkedAt": "2026-09-09T20:17:57.725982+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://www.openssh.com/manual.html",
        "status": 200,
        "finalUrl": "https://www.openssh.org/manual.html",
        "title": "OpenSSH: Manual Pages",
        "checkedAt": "2026-09-09T20:17:57.725982+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "mdadm",
    "name": "Linux software RAID",
    "developer": "GNU / Linux community",
    "description": "Read RAID state first; do not create or force-assemble arrays on original recovery media.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://docs.kernel.org/admin-guide/md.html",
    "officialDownload": "",
    "documentation": "https://docs.kernel.org/admin-guide/md.html",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "cat /proc/mdstat",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://docs.kernel.org/admin-guide/md.html",
        "status": 200,
        "finalUrl": "https://docs.kernel.org/admin-guide/md.html",
        "title": "RAID arrays — The Linux Kernel documentation",
        "checkedAt": "2026-09-09T20:17:51.159597+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://docs.kernel.org/admin-guide/md.html",
        "status": 200,
        "finalUrl": "https://docs.kernel.org/admin-guide/md.html",
        "title": "RAID arrays — The Linux Kernel documentation",
        "checkedAt": "2026-09-09T20:17:51.159597+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "lvm",
    "name": "LVM inventory",
    "developer": "GNU / Linux community",
    "description": "List physical volumes, groups and logical volumes. Activation can permit writes.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://sourceware.org/lvm2/",
    "officialDownload": "",
    "documentation": "https://sourceware.org/lvm2/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "pvs; vgs; lvs",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://sourceware.org/lvm2/",
        "status": 200,
        "finalUrl": "https://sourceware.org/lvm2/",
        "title": "LVM2 Resource Page",
        "checkedAt": "2026-09-09T20:17:54.502509+00:00",
        "contentType": "text/html; charset=UTF-8"
      },
      "download": {
        "url": "https://sourceware.org/lvm2/",
        "status": 200,
        "finalUrl": "https://sourceware.org/lvm2/",
        "title": "LVM2 Resource Page",
        "checkedAt": "2026-09-09T20:17:54.502509+00:00",
        "contentType": "text/html; charset=UTF-8"
      }
    }
  },
  {
    "id": "zfs",
    "name": "ZFS pool status",
    "developer": "GNU / Linux community",
    "description": "Inspect imported pools. Never create a new pool over a recovery target.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://openzfs.github.io/openzfs-docs/",
    "officialDownload": "",
    "documentation": "https://openzfs.github.io/openzfs-docs/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "zpool status",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://openzfs.github.io/openzfs-docs/",
        "status": 200,
        "finalUrl": "https://openzfs.github.io/openzfs-docs/",
        "title": "OpenZFS Documentation — OpenZFS documentation",
        "checkedAt": "2026-09-09T20:17:53.919791+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://openzfs.github.io/openzfs-docs/",
        "status": 200,
        "finalUrl": "https://openzfs.github.io/openzfs-docs/",
        "title": "OpenZFS Documentation — OpenZFS documentation",
        "checkedAt": "2026-09-09T20:17:53.919791+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "lsblk",
    "name": "Linux block device inventory",
    "developer": "GNU / Linux community",
    "description": "Match disks by serial and capacity before mounting or imaging.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "officialDownload": "",
    "documentation": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "lsblk -o NAME,SIZE,MODEL,SERIAL,FSTYPE,MOUNTPOINTS",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "mount",
    "name": "Read-only filesystem mounting",
    "developer": "GNU / Linux community",
    "description": "Inspect existing mounts first. Filesystem-specific no-replay options are in the local guide.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "officialDownload": "",
    "documentation": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "findmnt",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "rsync",
    "name": "rsync dry run",
    "developer": "GNU / Linux community",
    "description": "Preview a file copy. Trailing slashes matter; avoid --delete for initial recovery.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://rsync.samba.org/",
    "officialDownload": "",
    "documentation": "https://rsync.samba.org/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "Review selected changes and record the original configuration. Back up important data first.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "rsync -avhn /SOURCE/ /DESTINATION/",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://rsync.samba.org/",
        "status": 200,
        "finalUrl": "https://rsync.samba.org/",
        "title": "rsync",
        "checkedAt": "2026-09-09T20:17:54.580181+00:00",
        "contentType": "text/html"
      },
      "download": {
        "url": "https://rsync.samba.org/",
        "status": 200,
        "finalUrl": "https://rsync.samba.org/",
        "title": "rsync",
        "checkedAt": "2026-09-09T20:17:54.580181+00:00",
        "contentType": "text/html"
      }
    }
  },
  {
    "id": "fsck",
    "name": "Filesystem check planning",
    "developer": "GNU / Linux community",
    "description": "Identify filesystem and unmount before any checker. Image failing media first; use filesystem-specific tools.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "officialDownload": "",
    "documentation": "https://www.kernel.org/pub/linux/utils/util-linux/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "HIGH RISK",
    "caution": "May overwrite data or make the system unbootable. Verify the target and a recoverable backup before proceeding.",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "lsblk -f",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/util-linux/",
        "title": "Index of /pub/linux/utils/util-linux/",
        "checkedAt": "2026-09-09T20:17:55.728219+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "ip-linux",
    "name": "Linux network inventory",
    "developer": "GNU / Linux community",
    "description": "Inspect addresses and routing before modifying interfaces.",
    "categories": [
      "Homelab / Linux"
    ],
    "tags": [
      "Linux server"
    ],
    "useCases": [],
    "priority": "P3",
    "license": "Free",
    "personalLicenseNotes": "Free offering at the listed project/publisher; review bundled components and the selected edition.",
    "technicianLicenseNotes": "Review vendor terms for commercial service work and redistribution.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Linux"
    ],
    "architecture": [
      "x64; other builds vary"
    ],
    "estimatedSizeMB": 0,
    "officialWebsite": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
    "officialDownload": "",
    "documentation": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
    "localFolder": "",
    "localExecutable": "",
    "inventoryPatterns": [],
    "kind": "Built-in",
    "localVersion": "",
    "latestVersion": "",
    "currentVersion": "",
    "lastChecked": "",
    "updateStatus": "unknown",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "Requires the command in the booted Linux environment; the dashboard does not check host packages.",
    "sourceStatus": "Official page reachable",
    "command": "ip address; ip route",
    "defaultFavorite": false,
    "localReference": "70_DOCUMENTATION/reference.html#linux-rescue",
    "sourceCheckedAt": "2026-09-09",
    "sourceEvidence": {
      "website": {
        "url": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
        "title": "Index of /pub/linux/utils/net/iproute2/",
        "checkedAt": "2026-09-09T20:17:55.775338+00:00",
        "contentType": "text/html; charset=utf-8"
      },
      "download": {
        "url": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
        "status": 200,
        "finalUrl": "https://www.kernel.org/pub/linux/utils/net/iproute2/",
        "title": "Index of /pub/linux/utils/net/iproute2/",
        "checkedAt": "2026-09-09T20:17:55.775338+00:00",
        "contentType": "text/html; charset=utf-8"
      }
    }
  },
  {
    "id": "unattend",
    "name": "Windows unattended language template",
    "developer": "Neighbor Circuit Toolkit",
    "description": "Language-only template for Windows Setup. No account bypass, credentials or disk operations. Validate against the exact image.",
    "categories": [
      "Account & OOBE",
      "Documentation"
    ],
    "tags": [
      "offline",
      "reference"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "Architecture independent"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "",
    "localFolder": "10_WINDOWS_TOOLBOX/06_Account-OOBE/Unattended",
    "localExecutable": "10_WINDOWS_TOOLBOX/06_Account-OOBE/Unattended/autounattend.xml",
    "inventoryPatterns": [
      "autounattend.xml"
    ],
    "kind": "Documentation",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html"
  },
  {
    "id": "reference",
    "name": "Offline technician reference",
    "developer": "Neighbor Circuit Toolkit",
    "description": "24 local cheat sheets covering recovery, BitLocker, boot keys, networking, Linux and privacy.",
    "categories": [
      "Documentation"
    ],
    "tags": [
      "offline",
      "reference"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows",
      "Linux"
    ],
    "architecture": [
      "Architecture independent"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "",
    "localFolder": "70_DOCUMENTATION",
    "localExecutable": "70_DOCUMENTATION/reference.html",
    "inventoryPatterns": [
      "reference.html"
    ],
    "kind": "Documentation",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "SAFE",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html"
  },
  {
    "id": "inventory-script",
    "name": "Update toolkit inventory",
    "developer": "Neighbor Circuit Toolkit",
    "description": "Scan expected files and record local availability without executing tools.",
    "categories": [
      "Technician Scripts"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "",
    "localFolder": "60_SCRIPTS/Inventory",
    "localExecutable": "60_SCRIPTS/Inventory/Update-ToolkitInventory.ps1",
    "inventoryPatterns": [
      "Update-ToolkitInventory.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Inventory\\Update-ToolkitInventory.ps1",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html"
  },
  {
    "id": "metadata-script",
    "name": "Update toolkit metadata",
    "developer": "Neighbor Circuit Toolkit",
    "description": "Optional online official-source and release checks; no software replacement.",
    "categories": [
      "Technician Scripts"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "",
    "localFolder": "60_SCRIPTS/Inventory",
    "localExecutable": "60_SCRIPTS/Inventory/Update-ToolkitMetadata.ps1",
    "inventoryPatterns": [
      "Update-ToolkitMetadata.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Inventory\\Update-ToolkitMetadata.ps1",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html"
  },
  {
    "id": "download-script",
    "name": "Preview / download reviewed tools",
    "developer": "Neighbor Circuit Toolkit",
    "description": "Preview the reviewed direct-download subset; explicit confirmation, no execution.",
    "categories": [
      "Technician Scripts"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "",
    "localFolder": "60_SCRIPTS/Inventory",
    "localExecutable": "60_SCRIPTS/Inventory/Download-MissingTools.ps1",
    "inventoryPatterns": [
      "Download-MissingTools.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Inventory\\Download-MissingTools.ps1 -WhatIf",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html"
  },
  {
    "id": "diagnostic-script",
    "name": "Collect PC diagnostics",
    "developer": "Neighbor Circuit Toolkit",
    "description": "Read-only hardware report; requires an explicit new output file. Contains device identifiers.",
    "categories": [
      "Technician Scripts",
      "Hardware Diagnostics"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "",
    "localFolder": "60_SCRIPTS/Diagnostics",
    "localExecutable": "60_SCRIPTS/Diagnostics/Get-PCDiagnostics.ps1",
    "inventoryPatterns": [
      "Get-PCDiagnostics.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": "",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html"
  },
  {
    "id": "network-script",
    "name": "Inspect network configuration",
    "developer": "Neighbor Circuit Toolkit",
    "description": "Read adapter, IP and DNS configuration without resets or scans.",
    "categories": [
      "Technician Scripts",
      "Networking"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "",
    "localFolder": "60_SCRIPTS/Network",
    "localExecutable": "60_SCRIPTS/Network/Get-NetworkDiagnostics.ps1",
    "inventoryPatterns": [
      "Get-NetworkDiagnostics.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Network\\Get-NetworkDiagnostics.ps1",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html"
  },
  {
    "id": "repair-script",
    "name": "Windows system file repair helper",
    "developer": "Neighbor Circuit Toolkit",
    "description": "Check current component-store status by default. Optional elevated repair is confirmed separately.",
    "categories": [
      "Technician Scripts",
      "Windows Repair"
    ],
    "tags": [
      "offline",
      "PowerShell"
    ],
    "useCases": [],
    "priority": "P2",
    "license": "Included",
    "personalLicenseNotes": "Locally authored toolkit material.",
    "technicianLicenseNotes": "Review and adapt to the authorized service task.",
    "portable": false,
    "bootable": false,
    "offline": true,
    "os": [
      "Windows"
    ],
    "architecture": [
      "Windows PowerShell 5.1 / PowerShell 7"
    ],
    "estimatedSizeMB": 1,
    "officialWebsite": "",
    "officialDownload": "",
    "documentation": "",
    "localFolder": "60_SCRIPTS/Windows-Repair",
    "localExecutable": "60_SCRIPTS/Windows-Repair/Repair-WindowsFiles.ps1",
    "inventoryPatterns": [
      "Repair-WindowsFiles.ps1"
    ],
    "kind": "Script",
    "localVersion": "1.0",
    "latestVersion": "1.0",
    "currentVersion": "1.0",
    "lastChecked": "2026-09-09",
    "updateStatus": "current",
    "manualVersionCheck": true,
    "freshDownloadRequired": false,
    "risk": "CAUTION",
    "caution": "",
    "notes": "Included locally; external reference links require internet.",
    "sourceStatus": "Included local resource",
    "command": ".\\60_SCRIPTS\\Windows-Repair\\Repair-WindowsFiles.ps1 -WhatIf",
    "defaultFavorite": false,
    "sourceCheckedAt": "2026-09-09",
    "localReference": "70_DOCUMENTATION/reference.html"
  }
];
